<?php

$connect_string='localhost';
$connect_username='prashant_want';
$connect_password='Pace2012!';
$conect_db='prashant_want';

/*$connect_string='localhost';
$connect_username='root';
$connect_password='';
$conect_db='db_payperclip';*/



mysql_connect($connect_string,$connect_username,$connect_password) or die(mysql_error());
mysql_select_db($conect_db) or die(mysql_error());

	   $want_product = mysql_query("insert into want_product(user_id,item,date)values('".$_REQUEST['userId']."','".$_REQUEST['itemnm']."',NOW())")or die(mysql_error());
	   
	   $new_id = mysql_insert_id();
	   
	   $insert_data = mysql_query("insert into want_items(item_id,user_id,status,date)values('".$new_id."','".$_REQUEST['userId']."',0,NOW())")or die(mysql_error());
		


?>