<?
include("includes/_include.php");
?>
<? include("includes/frontHeader.php");?>
 <script language="JavaScript" type="text/javascript" src="selectbox2.js">
 </script>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="left" height="30"><h2>My Shopping Cart</h2></td>
  </tr>
</table>
<table width="100%" border="1" cellspacing="0" cellpadding="0">
   <tr>
    <td height="30" colspan="11" align="center" style="color:#FF0000"><?=$msg?></td>
  </tr>
  <tr>
    <td width="7%" height="32" align="center" bgcolor="#CCCCCC">SL.</td>
    <!--<td width="10%" align="left" bgcolor="#CCCCCC">Author</td>-->
    <td width="11%" align="center" bgcolor="#CCCCCC">Title</td>
    <td width="8%" align="center" bgcolor="#CCCCCC">Category</td>
    <td width="7%" align="center" bgcolor="#CCCCCC">Item Format</td>
    <td width="7%" align="center" bgcolor="#CCCCCC">Max Days</td>
    <td width="10%" align="center" bgcolor="#CCCCCC">Send Back Address</td>
    <td width="8%" align="center" bgcolor="#CCCCCC">Date Sent by Owner</td>
    <td width="11%" align="center" bgcolor="#CCCCCC">USPS Tracker (Receipt)</td>
    <td width="9%" align="center" bgcolor="#CCCCCC">Date Returned to Owner</td>
    <td width="12%" align="center" bgcolor="#CCCCCC">USPS Tracker (Returned)</td>
  </tr>
   <? if(mysql_num_rows($fetRentResult)==0) { ?>
  <tr height="30" > <td colspan="12" align="center" style="color:#FF0000">No Sale Item Found</td></tr>
  <? } ?>
  <?
  $sl=1;
while($fetData = mysql_fetch_array($fetRentResult)) {
$track=checktrucker($fetData['orderid']);
$trackno=truckerno($fetData['orderid']);
$truckerReturnno=truckerReturnno($fetData['orderid']);
$trackerhiligt=trackerhiligt($fetData['orderid']);
?>
  <tr <? if($track!=0) { ?>style="background:#FFFF00" <? } ?> <? if($trackerhiligt==0) { ?> style="color:#FF0000; font-weight:bold" <? } ?>>
    <td height="37" align="center"><?=$sl?>.</td>
    <!--<td align="center"><?=$fetData['author']?></td>-->
    <td align="center"><?=$fetData['title']?></td>
    <td align="center"><?=$fetData['catname']?></td>
    <td align="center"><?=$fetData['format']?></td>
    <td align="center"><?=$fetData['max_days']?></td>
    <td align="center"><b><?=$fetData['first_name'].' '.$fetData['last_name']?></b><br /><?=$fetData['address_1'].' '.$fetData['address_2'].' '.$fetData['city'].' '.$fetData['state'].' '.$fetData['country'].' '.$fetData['zip_code']?></td>
    <td align="center"><? if($trackno['tracking_send']!="") { ?><?=date('F d,Y ',strtotime($trackno['date_start']))?><? } ?></td>
    <td align="center"><?=$trackno['tracking_send']?></td>
    <td align="center"><? if($truckerReturnno['tracking_return']!="") { ?><?=date('F d,Y ',strtotime($truckerReturnno['date_end']))?><? } ?></td>
    <td align="center"><?=$truckerReturnno['tracking_return']?></td>
  </tr>
  <? 
  $sl++;
   }?>
</table>

<? if(mysql_num_rows($rentItemTrack)!=0) { ?> 
<h2>Select Items under a single tracking number:</h2>
				 
				<form action="" onSubmit="select_all(this);return chkTracking()" method="post">
					<table width="207" border="0">
					 <tr>
					  <td width="100">
						<select name="sel1" size="10" multiple="multiple" style="width: 400px">
                        <? while($item = mysql_fetch_array($rentItemTrack)) { ?>
						<option value="<?=$item['orderid']?>"><?=$item['title']?></option>
                        <? }?>
                       <!-- <option value="77">Create a Board2</option>
                        <option value="78">Create a Board3</option>
                        <option value="79">Create a Board4</option>
                        <option value="80">Create a Board5</option>-->
						</select>
					  </td>
					  <td width="48" align="center" valign="middle">  
						<input type="button" value="--&gt;" onclick="moveOptions(this.form.sel1, this.form.sel2);" />
						<input type="button" value="&lt;--" onclick="moveOptions(this.form.sel2, this.form.sel1);" />
					  </td>
					  <td width="45">
						<select name="sel2[]" size="10" multiple="multiple" id="sel2" style="width: 400px">
						</select>
					  </td>
					  </tr>
					  <tr><td>USPS Tracking #</td><td colspan="2"><input type="text" name="trackingno" id="trackingno"></input></td></tr>
					</table>
				
                
			<div style="padding-left:450px;"><input type="submit" name="submit_track_rent" value="submit" class="button2" /></div>
				</form>
                <? } ?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
    <td align="center" height="30">&nbsp;<br /></td>
  </tr>
  <tr>
    <td align="center" height="30"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a><br /></td>
  </tr>
</table>

<? include("includes/footer.php");?>