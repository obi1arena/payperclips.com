<?
include("includes/_include.php");

 include("includes/frontHeader.php");

if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}

?>
<script type="text/javascript">
function deleteData(id)
 {
 chk=confirm("Are you want to delete this item");
 if(chk==true)
 {
document.inputDelete.id.value=id;
document.inputDelete.submit();
		}
 }
 function Superuserj(id)
 {
 chk=confirm("Are you want to delete this item");
 if(chk==true)
 {
document.Superuser.id.value=id;
document.Superuser.submit();
		}
 
 }
 
 function becomeuser(id)
 {
document.inputBecome.id.value=id;
document.inputBecome.submit();
 }
</script>
<h2>Edit users</h2>
<? if(isset($err)) { ?>
  <table border="0" width="100%">
  <tr><td align="center" style="color:#FF0000"><b><?=$err?></b></td></tr>
  </table>
  <? } ?>
 <form action="" method="post" name="editUser">
 <table border="0">
	<tr>
		<td><b>A portion for the Item Owner(is now):</b></td>
		<td>$<?=dollarval()?>	</td>
	</tr>
	<tr>
		<td>A portion for the Item Owner:</td>
		<td>$<input type="text" name="portion_for_item_owner" size="5" maxlength="5" required></input></td>
	</tr>
	<tr>
		<td>If the renter exceeds the monthly plan:</td>
		<td></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="radio" name="group1" value="no_penalty" > DO NOT PENALIZE</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="radio" name="group1" value="Bumped_up" > BUMPED TO THE HIGHER PLAN for 1 month</td>
	</tr>
	<tr>
		<td></td>
		<td><input type="radio" name="group1" value="penalty" > Charge $<input type="text" name="penaltyAmount" size="5" maxlength="5"></input></td>
	</tr>
	<tr>
        <td colspan="2"><input type="submit" name='penalty_submit' value="Submit" class="button2"></td>
    </tr>
</table>
</form>
</br/>
<hr>
<h2>Create New User</h2>
 <? if(isset($GLOBALS['msg_errh'])) { ?>
  <table border="0" width="100%">
  <tr><td align="center" style="color:#FF0000"><b><?=$GLOBALS['msg_errh']?></b></td></tr>
  </table>
  <? } ?>
  <form name="insert" action="" method="post">
    <table border="0" cellpadding="2" cellspacing="4">
      <tr>
	<td>First name</td>
        <td><input type="text" name="fname" maxlength="13" size="13" value="<?=$_REQUEST['fname']?>" required><br /></td>
      </tr>
      <tr>
	<td>Last name</td>
        <td><input type="text" name="lname" maxlength="13" size="13" value="<?=$_REQUEST['lname']?>" required><br /></td>
      </tr>
      <tr>
        <td>Street address</td>
        <td> <input type="text" name="address1" maxlength="30" size="30" value="<?=$_REQUEST['address1']?>" required><br /></td>
      </tr>
      <tr>
        <td>Street address</td>
        <td> <input type="text" name="address2" maxlength="30"  value="<?=$_REQUEST['address2']?>" size="30" required><br /></td>
      </tr>
      <tr>
	<td>City</td>
        <td><input type="text" name="city" maxlength="13" size="13" value="<?=$_REQUEST['city']?>" required><br /></td>
      </tr>
      <tr>
	<td>State</td>
        <td><select name="state" required>
<option value="">Select a state/province</option>
      <option value="1" <? if($_REQUEST['state']==1) { ?> selected<? } ?>>Alabama</option>
      <option value="2" <? if($_REQUEST['state']==2) { ?> selected<? } ?>>Alaska</option>
      <option value="3" <? if($_REQUEST['state']==3) { ?> selected<? } ?>>Arizona</option>
      <option value="4" <? if($_REQUEST['state']==4) { ?> selected<? } ?>>Arkansas</option>
      <option value="5" <? if($_REQUEST['state']==5) { ?> selected<? } ?>>California</option>
      <option value="6" <? if($_REQUEST['state']==6) { ?> selected<? } ?>>Canada-Alberta</option>
      <option value="7" <? if($_REQUEST['state']==7) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="8" <? if($_REQUEST['state']==8) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="9" <? if($_REQUEST['state']==9) { ?> selected<? } ?>>Canada-British Columbia</option>
      <option value="10" <? if($_REQUEST['state']==10) { ?> selected<? } ?>>Colorado</option>
      <option value="11" <? if($_REQUEST['state']==11) { ?> selected<? } ?>>Connecticut</option>
      <option value="12" <? if($_REQUEST['state']==12) { ?> selected<? } ?>>Delaware</option>
      <option value="13" <? if($_REQUEST['state']==13) { ?> selected<? } ?>>District of Columbia</option>
      <option value="14" <? if($_REQUEST['state']==14) { ?> selected<? } ?>>Florida</option>
      <option value="15" <? if($_REQUEST['state']==15) { ?> selected<? } ?>>Georgia</option>
      <option value="16" <? if($_REQUEST['state']==16) { ?> selected<? } ?>>Hawaii</option>
      <option value="17" <? if($_REQUEST['state']==17) { ?> selected<? } ?>>Idaho</option>
      <option value="18" <? if($_REQUEST['state']==18) { ?> selected<? } ?>>Illinois</option>
      <option value="19" <? if($_REQUEST['state']==19) { ?> selected<? } ?>>Indiana</option>
      <option value="20" <? if($_REQUEST['state']==20) { ?> selected<? } ?>>Iowa</option>
      <option value="21" <? if($_REQUEST['state']==21) { ?> selected<? } ?>>Kansas</option>
      <option value="22" <? if($_REQUEST['state']==22) { ?> selected<? } ?>>Kentucky</option>
      <option value="23" <? if($_REQUEST['state']==23) { ?> selected<? } ?>>Louisiana</option>
      <option value="24" <? if($_REQUEST['state']==24) { ?> selected<? } ?>>Maine</option>
      <option value="25" <? if($_REQUEST['state']==25) { ?> selected<? } ?>>Maryland</option>
      <option value="26" <? if($_REQUEST['state']==26) { ?> selected<? } ?>>Massachusetts</option>
      <option value="27" <? if($_REQUEST['state']==27) { ?> selected<? } ?>>Michigan</option>
      <option value="28" <? if($_REQUEST['state']==28) { ?> selected<? } ?>>Minnesota</option>
      <option value="29" <? if($_REQUEST['state']==29) { ?> selected<? } ?>>Mississippi</option>
      <option value="30" <? if($_REQUEST['state']==30) { ?> selected<? } ?>>Missouri</option>
      <option value="31" <? if($_REQUEST['state']==31) { ?> selected<? } ?>>Montana</option>
      <option value="32" <? if($_REQUEST['state']==32) { ?> selected<? } ?>>Nebraska</option>
      <option value="33" <? if($_REQUEST['state']==33) { ?> selected<? } ?>>Nevada</option>
      <option value="34" <? if($_REQUEST['state']==34) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="35" <? if($_REQUEST['state']==35) { ?> selected<? } ?>>New Hampshire</option>
      <option value="36" <? if($_REQUEST['state']==36) { ?> selected<? } ?>>New Jersey</option>
      <option value="37" <? if($_REQUEST['state']==37) { ?> selected<? } ?>>New Mexico</option>
      <option value="38" <? if($_REQUEST['state']==38) { ?> selected<? } ?>>New York</option>
      <option value="39" <? if($_REQUEST['state']==39) { ?> selected<? } ?>>North Carolina</option>
      <option value="40" <? if($_REQUEST['state']==40) { ?> selected<? } ?>>North Dakota</option>
      <option value="41" <? if($_REQUEST['state']==41) { ?> selected<? } ?>>Ohio</option>
      <option value="42" <? if($_REQUEST['state']==42) { ?> selected<? } ?>>Oklahoma</option>
      <option value="43" <? if($_REQUEST['state']==43) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="44" <? if($_REQUEST['state']==44) { ?> selected<? } ?>>Oregon</option>
      <option value="45" <? if($_REQUEST['state']==45) { ?> selected<? } ?>>Pennsylvania</option>
      <option value="46" <? if($_REQUEST['state']==46) { ?> selected<? } ?>>Rhode Island</option>
      <option value="47" <? if($_REQUEST['state']==47) { ?> selected<? } ?>>South Carolina</option>
      <option value="48" <? if($_REQUEST['state']==48) { ?> selected<? } ?>>South Dakota</option>
      <option value="49" <? if($_REQUEST['state']==49) { ?> selected<? } ?>>Tennessee</option>
      <option value="50" <? if($_REQUEST['state']==50) { ?> selected<? } ?>>Texas</option>
      <option value="51" <? if($_REQUEST['state']==51) { ?> selected<? } ?>>Utah</option>
      <option value="52" <? if($_REQUEST['state']==52) { ?> selected<? } ?>>Vermont</option>
      <option value="53"  <? if($_REQUEST['state']==53) { ?> selected<? } ?>>Virginia</option>
      <option value="54" <? if($_REQUEST['state']==54) { ?> selected<? } ?>>Washington</option>
      <option value="55" <? if($_REQUEST['state']==55) { ?> selected<? } ?>>Washington DC</option>
      <option value="56" <? if($_REQUEST['state']==56) { ?> selected<? } ?>>West Virginia</option>
      <option value="57" <? if($_REQUEST['state']==57) { ?> selected<? } ?>>Wisconsin</option>
      <option value="58" <? if($_REQUEST['state']==58) { ?> selected<? } ?>>Wyoming</option>
                                      </select>
<br></td>
      </tr>
      <tr>
        <td>Zip code</td>
        <td> <input type="text" name="zip_code"  value="<?=$_REQUEST['zip_code']?>" maxlength="5" size="5" required><br></td>
      </tr>
      <tr>
        <td>Telephone</td>
        <td><input type="text" name="telephone"  value="<?=$_REQUEST['telephone']?>" maxlength="10" size="10" ><br /></td>
      </tr>
      <tr>
        <td>Email address</td>
        <td> <input type="email" name="email" maxlength="25"  value="<?=$_REQUEST['email']?>" size="25" required><br></td>
      </tr>
      <tr>
        <td>User name</td>
        <td> <input type="text" name="username" maxlength="15"  value="<?=$_REQUEST['username']?>" size="15" required><br></td>
      </tr>
      <tr>
        <td>Password</td>
        <td> <input type="password" name="password" maxlength="15" size="15" required><br></td>
      </tr>
      <tr>
        <td colspan="2"><input type="submit" name='createUser' value="Create" class="button2"></td>
      </tr>
    </table>
    </form>
 <br/>
  <hr>
<br/>
<h1>Existing Users</h1>

 <table width="80%" border="1"cellpadding="0" cellspacing="0">
 <? if(isset($GLOBALS['msg_err'])) { ?>
 <tr><td colspan="9" style="color:#FF0000" align="center"><?=$GLOBALS['msg_err']?></td></tr>
 <? } ?>
 <tr><td>Sl.</td><td>Username</td><td>FirstName</td><td>LastName</td><td>Email</td><td>Superuser?</td><td>Action</td></tr>
 <? 
 $i=1;
 $itemsql= user_list();
 
 while($rs=mysql_fetch_array($itemsql)) { ?> 	
 
<? //print_r($rs) ?>	
  <tr height="30">
 <td width="5%"> <?=$i?>.</td>
 <td width="12%"><?=$rs['username']?></td>
 <td width="12%"><?=$rs['first_name']?></td>
 <td width="12%"><?=$rs['last_name']?></td>
 <td width="12%"><?=$rs['email']?></td>
 <td width="12%"><?=($rs['god']=='1')?"Yes":"No"?></td>
 
 <td width="35%">&nbsp;<input type='submit' name='delete_awara' value='Delete' onClick="return deleteData(<?=$rs['id']?>)" class="button2">&nbsp;<input type='submit' name='become_awara' value='Become' class="button2" onclick="return becomeuser(<?=$rs['id']?>)">&nbsp;<input type='submit' name='god_awara' value='Make Superuser' onClick="return Superuserj(<?=$rs['id']?>)" class="button2">&nbsp;<input type='button' name='user_info' value='Reg Info' onClick="window.location='home.php?page=edit_info&eId=<?=$rs['id']?>'" class="button2"></td>
 </tr>

  <?
   $i++;
   } ?>
  
 
 
 </table>
 
 <form name="inputDelete" action="" method="post">
 <input type="hidden" name="id" value="" />
  <input type="hidden" name="delete_user_item" value="Delete" />
 </form>
 <form name="inputBecome" action="" method="post">
 <input type="hidden" name="id" value="" />
  <input type="hidden" name="become_user" value="become" />
 </form>
 <form name="Superuser" action="" method="post">
 <input type="hidden" name="id" value="" />
  <input type="hidden" name="make_Superuser" value="Delete" />
 </form>