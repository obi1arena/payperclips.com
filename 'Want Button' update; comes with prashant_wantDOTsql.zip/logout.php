<?php
ob_start();
include("config/config.php");
	
	unset($_SESSION['username']);
	unset($_SESSION['userId']);
	unset($_SESSION['pre_userId']);
	unset($_SESSION['pre_user']);
	unset($_SESSION['userType']);
	unset($_SESSION['become']);
	header('Location:home.php?page=home');
	
?>	