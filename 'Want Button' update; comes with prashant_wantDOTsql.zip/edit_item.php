<? ob_start();
include("includes/_include.php");
?>
 <? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
$item_id=$_REQUEST['item_id'];
if(isset($item_id))
{
	$itemDetails=fetchItem($item_id);
}
?>
 
  <form enctype='multipart/form-data' method="post" action="" id="formID">
  <table >
  <tr>
  <td colspan="2">
  <? if(isset($GLOBALS['item_update'])) { echo $GLOBALS['item_update']; }
  elseif(isset($_REQUEST['msg_del']))
  {
  	echo "Item ".$_REQUEST['msg_del']." was deleted.";
  }
  ?>
  </td>
  </tr>
  <tr>
    <td>Item Title:</td>
    <td><input type="text" name="title" class="validate[required] text-input" value="<?=$itemDetails['title']?>"/></td>
  </tr>
  <tr>
    <td>Item Author:</td>
    <td><input type="text" name="author"  class="validate[required] text-input" value="<?=$itemDetails['author']?>"/></td>
   </tr>
   <tr>
      <td>Category:</td>
      <td>	  
	  <select name="category" class="validate[required] text-input">
      <option value="" selected="selected"></option>
      <!--<option value="" selected="selected">Select A Category</option>-->
 <?
 $fetchCategory=fetchCategory();
 while($category=mysql_fetch_array($fetchCategory)) {?>
 <option value="<?=$category['catid'];?>" <? if($itemDetails['catid']==$category['catid']) {?> selected="selected"<? }?> ><?=$category['catname'];?></option>
<?
}
?>
 </select>
        </td>
   </tr>
   <tr>
      <td>Item Format:</td>
      <td>
<select name="format" class="validate[required] text-input">
<option value="" selected="selected"></option>
<!--<option value="" selected="selected">Select a format</option>--> 
<?
 $fetchItemFormat=fetchItemFormat();
 while($item_format=mysql_fetch_array($fetchItemFormat)) {?>
 <option value="<?=$item_format['format'];?>" <? if($itemDetails['format']==$item_format['format']) {?> selected="selected"<? }?> ><?=$item_format['format'];?></option>
<?
}
?>
 </select>
        </td>
   </tr>
  
   <tr>
     <td>Description:</td>
     <td><textarea rows="3" cols="50" name="description" class="validate[required] text-input"><?=$itemDetails['description'];?></textarea></td>
    </tr>		
     <tr>
      	<td>Upload item picture:</td>
	<td>
    <img src="pics/small_<?=$itemDetails['imgName']?>"  border=0 height = 75 width = 135><br/><br />

		 <input type="file" name="file" id="file">	
	</td>
      </tr>
    <tr>
      <td colspan=2 align=center>
      <input type="hidden" name="item_id" id="item_id" value="<?=$item_id;?>">
                 <input type="submit" value="Update Item" name="btn_edit_item" class="button2">
                
        </form>
         <a href="home.php?page=delete_item&item_id=<?=$item_id;?>" class="button2">Delete Items
</a>
        </td>
                 </td>
      </tr>
     
  </table>
  </form>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
</table>

<? include("includes/footer.php");?>