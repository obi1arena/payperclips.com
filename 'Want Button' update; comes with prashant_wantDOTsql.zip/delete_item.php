<?
include("includes/_include.php");
if(isset($_SESSION['username']))
{
$item_id=$_REQUEST['item_id'];

deleteItem($item_id);
}
else
{
	header('Location:home.php?page=home');
}
?>
