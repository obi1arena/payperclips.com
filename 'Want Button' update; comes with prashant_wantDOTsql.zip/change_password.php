<?

include("includes/_include.php");
?>

  
<? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}

?>

   
<h2>Change details</h2>
   <br />
   <form action="" method="post">
   <table width=100% cellpadding=2 cellspacing=0>
   <tr><td width="15%">Old password:</td>
       <td width="85%"><input type=password name=old_passwd size=50 class="validate[required] text-input"></td>
   </tr>
   <tr><td>New password:</td>
       <td><input type=password name=new_passwd size=50></td>
   </tr>
   <tr><td>Repeat new password:</td>
       <td><input type=password name=new_passwd2 size=50></td>
   </tr>
   <tr><td>First Name</td><td><input name='first_name' value='<?=$userData['first_name'];?>' size="50"></td></tr><tr><td>Last Name</td><td><input name='last_name' value='<?=$userData['last_name'];?>' size="50"></td></tr><tr><td>Address 1</td><td><input name='address_1' value='<?=$userData['address_1'];?>' size="50"></td></tr><tr><td>Address 2</td><td><input name='address_2' value='<?=$userData['address_2'];?>' size="50"></td></tr><tr><td>City</td><td><input name='city' value='<?=$userData['city'];?>' size="50"></td></tr><tr><td>Zip Code</td><td><input name='zip_code' value='<?=$userData['zip_code'];?>' size="50"></td></tr><tr><td>State</td><td><select name="state" class="validate[required] text-input">
      <option value="">Select a state/province</option>
      <option value="1" <? if($userData['state']==1) { ?> selected<? } ?>>Alabama</option>
      <option value="2" <? if($userData['state']==2) { ?> selected<? } ?>>Alaska</option>
      <option value="3" <? if($userData['state']==3) { ?> selected<? } ?>>Arizona</option>
      <option value="4" <? if($userData['state']==4) { ?> selected<? } ?>>Arkansas</option>
      <option value="5" <? if($userData['state']==5) { ?> selected<? } ?>>California</option>
      <option value="6" <? if($userData['state']==6) { ?> selected<? } ?>>Canada-Alberta</option>
      <option value="7" <? if($userData['state']==7) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="8" <? if($userData['state']==8) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="9" <? if($userData['state']==9) { ?> selected<? } ?>>Canada-British Columbia</option>
      <option value="10" <? if($userData['state']==10) { ?> selected<? } ?>>Colorado</option>
      <option value="11" <? if($userData['state']==11) { ?> selected<? } ?>>Connecticut</option>
      <option value="12" <? if($userData['state']==12) { ?> selected<? } ?>>Delaware</option>
      <option value="13" <? if($userData['state']==13) { ?> selected<? } ?>>District of Columbia</option>
      <option value="14" <? if($userData['state']==14) { ?> selected<? } ?>>Florida</option>
      <option value="15" <? if($userData['state']==15) { ?> selected<? } ?>>Georgia</option>
      <option value="16" <? if($userData['state']==16) { ?> selected<? } ?>> Hawaii</option>
      <option value="17" <? if($userData['state']==17) { ?> selected<? } ?>>Idaho</option>
      <option value="18" <? if($userData['state']==18) { ?> selected<? } ?>>Illinois</option>
      <option value="19" <? if($userData['state']==19) { ?> selected<? } ?>>Indiana</option>
      <option value="20" <? if($userData['state']==20) { ?> selected<? } ?>>Iowa</option>
      <option value="21" <? if($userData['state']==21) { ?> selected<? } ?>>Kansas</option>
      <option value="22" <? if($userData['state']==22) { ?> selected<? } ?>>Kentucky</option>
      <option value="23" <? if($userData['state']==23) { ?> selected<? } ?>>Louisiana</option>
      <option value="24" <? if($userData['state']==24) { ?> selected<? } ?>>Maine</option>
      <option value="25" <? if($userData['state']==25) { ?> selected<? } ?>>Maryland</option>
      <option value="26" <? if($userData['state']==26) { ?> selected<? } ?>>Massachusetts</option>
      <option value="27" <? if($userData['state']==27) { ?> selected<? } ?>>Michigan</option>
      <option value="28" <? if($userData['state']==28) { ?> selected<? } ?>>Minnesota</option>
      <option value="29" <? if($userData['state']==29) { ?> selected<? } ?>>Mississippi</option>
      <option value="30" <? if($userData['state']==30) { ?> selected<? } ?>>Missouri</option>
      <option value="31" <? if($userData['state']==31) { ?> selected<? } ?>>Montana</option>
      <option value="32" <? if($userData['state']==32) { ?> selected<? } ?>>Nebraska</option>
      <option value="33" <? if($userData['state']==33) { ?> selected<? } ?>>Nevada</option>
      <option value="34" <? if($userData['state']==34) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="35" <? if($userData['state']==35) { ?> selected<? } ?>>New Hampshire</option>
      <option value="36" <? if($userData['state']==36) { ?> selected<? } ?>>New Jersey</option>
      <option value="37" <? if($userData['state']==37) { ?> selected<? } ?>>New Mexico</option>
      <option value="38" <? if($userData['state']==38) { ?> selected<? } ?>>New York</option>
      <option value="39" <? if($userData['state']==39) { ?> selected<? } ?>>North Carolina</option>
      <option value="40" <? if($userData['state']==40) { ?> selected<? } ?>>North Dakota</option>
      <option value="41" <? if($userData['state']==41) { ?> selected<? } ?>>Ohio</option>
      <option value="42" <? if($userData['state']==42) { ?> selected<? } ?>>Oklahoma</option>
      <option value="43" <? if($userData['state']==43) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="44" <? if($userData['state']==44) { ?> selected<? } ?>>Oregon</option>
      <option value="45" <? if($userData['state']==45) { ?> selected<? } ?>>Pennsylvania</option>
      <option value="46" <? if($userData['state']==46) { ?> selected<? } ?>>Rhode Island</option>
      <option value="47" <? if($userData['state']==47) { ?> selected<? } ?>>South Carolina</option>
      <option value="48" <? if($userData['state']==48) { ?> selected<? } ?>>South Dakota</option>
      <option value="49" <? if($userData['state']==49) { ?> selected<? } ?>>Tennessee</option>
      <option value="50" <? if($userData['state']==50) { ?> selected<? } ?>>Texas</option>
      <option value="51" <? if($userData['state']==51) { ?> selected<? } ?>>Utah</option>
      <option value="52" <? if($userData['state']==52) { ?> selected<? } ?>>Vermont</option>
      <option value="53" <? if($userData['state']==53) { ?> selected<? } ?>>Virginia</option>
      <option value="54" <? if($userData['state']==54) { ?> selected<? } ?>>Washington</option>
      <option value="55" <? if($userData['state']==55) { ?> selected<? } ?>>Washington DC</option>
      <option value="56" <? if($userData['state']==56) { ?> selected<? } ?>>West Virginia</option>
      <option value="57" <? if($userData['state']==57) { ?> selected<? } ?>>Wisconsin</option>
      <option value="58" <? if($userData['state']==58) { ?> selected<? } ?>>Wyoming</option>
    </select></td></tr><tr><td>Telephone</td><td><input name='telephone' value='<?=$userData['telephone'];?>'></td></tr><tr><td>Email</td><td><input name='email' value='<?=$userData['email'];?>' size="50"></td></tr>   <tr><td colspan=2 align=center><input name="btnUpdateDetails" type="submit" value="Change details"  class="button2">
   </td></tr>
   </table>
   <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
</table>

<? include("includes/footer.php");?>
