<?
include("includes/_include.php");

 include("includes/frontHeader.php");

if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
?>
 
 <script type="text/javascript">
 function chk()
 {
document.input.actionAdd.value="1";
document.input.submit();
 }
 function chkd()
 {
document.input.actionAdd.value="";
document.input.submit();
 }
 function deleteData(id)
 {
 chk=confirm("Are you want to delete this item");
 if(chk==true)
 {
document.inputDelete.id.value=id;
document.inputDelete.submit();
		}
 }
 function updateData(id)
 {

 var a= document.getElementById("format"+id).value;
 var b= document.getElementById("price"+id).value;
 var c= document.getElementById("max_days"+id).value;
  var d= document.getElementById("id"+id).value;
 

 document.inputUpdate.id.value=d;
 document.inputUpdate.format.value=a;
  document.inputUpdate.price.value=b;
   document.inputUpdate.max_days.value=c;
 document.inputUpdate.submit();
 
 }
 </script>
 
 
 <table width="60%" border="1"cellpadding="0" cellspacing="0">
 <? if(isset($GLOBALS['msg_err'])) { ?>
 <tr><td colspan="5" style="color:#FF0000" align="center"><?=$GLOBALS['msg_err']?></td></tr>
 <? } ?>
 <tr><td height="30">Sl.</td>
 <td>Item Format</td><td>Price</td><td>Maximum Days</td><td>Action</td></tr>
 <? 
 $i=1;
 $itemsql= formatsaql();
 $count=mysql_num_rows($itemsql)+1;
 while($rs=mysql_fetch_array($itemsql)) { ?> 	 	
  <tr height="30">
 <td height="38"> <?=$i?>.</td>
 <td>

  <input type="hidden" name="id" id="id<?=$rs['id']?>" value="<?=$rs['id']?>" >
  <input type="text" name="format" id="format<?=$rs['id']?>" value="<?=$rs['format']?>"></td><td><input type="text" name="price" id="price<?=$rs['id']?>" value="<?=$rs['price']?>"></td><td><input type="text" name="max_days" id="max_days<?=$rs['id']?>"  value="<?=$rs['max_days']?>"></td><td><input type="button" name="addDelete" value="Delete" onClick="return deleteData(<?=$rs['id']?>);" class="button2">&nbsp;<input type="button" name="Update" value="Update" onClick="updateData(<?=$rs['id']?>)" class="button2"></td></tr>

  <?
   $i++;
   } ?>
  <? if($_REQUEST['actionAdd']==1) { ?>
  <form name="insertForm" action="" method="post">
  <tr height="30"><td height="37"><?=$count?>.</td>
  <td><input type="text" name="format1" value="" required></td><td><input type="text" name="price1" value="" required></td><td><input type="text" name="max_days1"  value="" required></td><td>
 <input type="submit" name="add_manage_format" value="Insert" class="button2">&nbsp; <input type="button" name="Delete" value="Delete" onClick="return chkd();" class="button2"></td></tr>
  </form>
  <? 
 
  } ?>
 <tr height="30"><td height="39" colspan="4">&nbsp;</td>
 <td >&nbsp;<input type="submit" name="Add" value="Add New row" onClick="return chk();" class="button2">&nbsp;<input type="button" name="Back" value="Back" onClick="window.location='home.php?page=myaccount'" class="button2" /></td></tr>
 
 </table>
 <form name="input" action="" method="post">
 <input type="hidden" name="actionAdd" value="" />
 </form>
 <form name="inputDelete" action="" method="post">
 <input type="hidden" name="id" value="" />
  <input type="hidden" name="delete_manage_format" value="Delete" />
 </form>
 <form name="inputUpdate" action="" method="post">
 <input type="hidden" name="id" value="" />
  <input type="hidden" name="format" value="" />
   <input type="hidden" name="price" value="" />
    <input type="hidden" name="max_days" value="" />
  <input type="hidden" name="update_manage_format" value="update" />
 </form>