<?
include("includes/_include.php");
?>

  <script language="JavaScript" type="text/javascript" src="selectbox2.js">
			
</script>
<? include("includes/frontHeader.php");?>
  <form name="frm_login" method="post" action="" id="formID">
  <? if(isset($GLOBALS['msg_login'])) { echo $GLOBALS['msg_login']; }
  elseif(isset($_SESSION['msg_success']))
  {
  	echo $_SESSION['msg_success'];
	unset($_SESSION['msg_success']);
  }
  elseif(isset($_REQUEST['aut']))
  {
  	echo "Please login for access your account.";
  }
  
  
  ?>
  
  <table width="100%" >
   <tr>
     <td width="10%" height="32">Username:</td>
     <td width="90%"><input type="text" name="username" class="validate[required] text-input"></td></tr>
   <tr>
     <td height="37">Password:</td>
     <td><input type="password" name="password" class="validate[required] text-input"></td></tr>
   <tr>
     <td colspan=2 align=left>
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="login" value="Log in" class="button2">&nbsp;&nbsp;
     <input type="button" value="Register" onClick="window.location='home.php?page=registration'" class="button2"></td></tr>
   <tr>
</table></form>