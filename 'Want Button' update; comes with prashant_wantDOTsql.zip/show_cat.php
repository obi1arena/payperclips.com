<?
include("includes/_include.php");
?>
  <? include("includes/frontHeader.php");

$vendor=$_REQUEST['vendor'];
$catid=$_REQUEST['catid'];
$selCategory=fetchSelectCategory($catid);
?>

<h2><?=$selCategory['catname'];?></h2>
<table width = "100%" border = 0>
<? 
$catid=$selCategory['catid'];
$fetchItem=fetchItems($catid,$vendor);

$no=mysql_num_rows($fetchItem);
if($no>0)
{

while($item=mysql_fetch_array($fetchItem)) {?>
<tr><td>&nbsp;</td>
<td>
<a href="home.php?page=show_item&item_id=<?=$item['item_id'];?>&vendor=<?=$vendor;?>&catid=<?=$catid;?>"><?=$item['title'];?> by <?=$item['author'];?></a>
</td>
</tr>
<? }?>
</table>
<? } else {?>
	There are no items.
<? }?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=vendor&userName=<?=$_REQUEST['vendor']?>" class="button2">Continue Shopping</a></td>
  </tr>
</table>