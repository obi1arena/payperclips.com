<?php
include("config/config.php");

// for rebate amount
$date=date('Y/m/d H:i:s');
$date2=date('Y/m/01 00:00:01');
if($date==$date2)
 {
 	$set_value="UPDATE ".MEMBERSHIPFEE." SET rebate_amount='0.00'";
	mysql_query($set_value);
 }
 ?>