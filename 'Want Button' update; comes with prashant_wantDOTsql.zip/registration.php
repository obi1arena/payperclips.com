<?
include("includes/_include.php");
?>

  <script language="JavaScript" type="text/javascript" src="selectbox2.js">
			
</script>
<style type="text/css">
	pre { text-align: left; }
</style>

<script id="demo" type="text/javascript">
</script>

   <? include("includes/frontHeader.php");?>

<script type="text/javascript" src="js/all.js"></script>

<form id="formID" autocomplete="off" method="post" action="">
<div>
<input name="_qf__reg_form" type="hidden" value="" />
<table border="0" cellpadding="4" cellspacing="4" class="content">
  <tr>
    <td style="white-space: nowrap; background-color: #CCCCCC;" align="left" valign="top" colspan="3"><b>Registration </b></td>
  </tr>
  <tr>
    <td width="397" align="right" valign="top"><span style="color: #ff0000">*</span><b>Username</b></td>
    <td width="191" align="left" valign="top"><input maxlength="30" size="30" name="username" type="text" class="validate[required] text-input"  <? if(isset($_REQUEST['username'])) { ?>value=<?=$_REQUEST['username']; }?> /></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Password</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="password" id="password" type="password" class="validate[required] text-input" <? if(isset($_REQUEST['password'])) { ?>value=<?=$_REQUEST['password']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Confirm Password</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="password_confirm" type="password" class="validate[required,equals[password]] text-input" <? if(isset($_REQUEST['password_confirm'])) { ?>value=<?=$_REQUEST['password_confirm']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Email</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="email" type="text" class="validate[required,custom[email]] text-input" <? if(isset($_REQUEST['email'])) { ?>value=<?=$_REQUEST['email']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>First name</b></td>
    <td valign="top" align="left" class="field"><input maxlength="30" size="30" name="firstname" id="firstname" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['firstname'])) { ?>value=<?=$_REQUEST['firstname']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Last name</b></td>
    <td valign="top" align="left" class="field"><input maxlength="30" size="30" name="lastname" id="lastname" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['lastname'])) { ?>value=<?=$_REQUEST['lastname']; }?>/></td>
    <td class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Street address</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="address_1" type="text"class="validate[required] text-input" <? if(isset($_REQUEST['address_1'])) { ?>value=<?=$_REQUEST['address_1']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Street address</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="address_2" type="text" <? if(isset($_REQUEST['address_2'])) { ?>value=<?=$_REQUEST['address_2']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>City</b></td>
    <td valign="top" align="left"><input maxlength="15" size="15" name="city" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['city'])) { ?>value=<?=$_REQUEST['city']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>State</b></td>
    <td width="191" class="status"><select name="state" class="validate[required] text-input">
      <option value="">Select a state/province</option>
      <option value="1">Alabama</option>
      <option value="2">Alaska</option>
      <option value="3">Arizona</option>
      <option value="4">Arkansas</option>
      <option value="5">California</option>
      <option value="6">Canada-Alberta</option>
      <option value="7">Canada-New Brunswick</option>
      <option value="8">Canada-Ontario</option>
      <option value="9">Canada-British Columbia</option>
      <option value="10">Colorado</option>
      <option value="11">Connecticut</option>
      <option value="12">Delaware</option>
      <option value="13">District of Columbia</option>
      <option value="14">Florida</option>
      <option value="15">Georgia</option>
      <option value="16">Hawaii</option>
      <option value="17">Idaho</option>
      <option value="18">Illinois</option>
      <option value="19">Indiana</option>
      <option value="20">Iowa</option>
      <option value="21">Kansas</option>
      <option value="22">Kentucky</option>
      <option value="23">Louisiana</option>
      <option value="24">Maine</option>
      <option value="25">Maryland</option>
      <option value="26">Massachusetts</option>
      <option value="27">Michigan</option>
      <option value="28">Minnesota</option>
      <option value="29">Mississippi</option>
      <option value="30">Missouri</option>
      <option value="31">Montana</option>
      <option value="32">Nebraska</option>
      <option value="33">Nevada</option>
      <option value="34">Canada-New Brunswick</option>
      <option value="35">New Hampshire</option>
      <option value="36">New Jersey</option>
      <option value="37">New Mexico</option>
      <option value="38">New York</option>
      <option value="39">North Carolina</option>
      <option value="40">North Dakota</option>
      <option value="41">Ohio</option>
      <option value="42">Oklahoma</option>
      <option value="43">Canada-Ontario</option>
      <option value="44">Oregon</option>
      <option value="45">Pennsylvania</option>
      <option value="46">Rhode Island</option>
      <option value="47">South Carolina</option>
      <option value="48">South Dakota</option>
      <option value="49">Tennessee</option>
      <option value="50">Texas</option>
      <option value="51">Utah</option>
      <option value="52">Vermont</option>
      <option value="53">Virginia</option>
      <option value="54">Washington</option>
      <option value="55">Washington DC</option>
      <option value="56">West Virginia</option>
      <option value="57">Wisconsin</option>
      <option value="58">Wyoming</option>
    </select></td>
    <td valign="top" align="left">&nbsp;</td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Zip code</b></td>
    <td valign="top" align="left"><input maxlength="5" size="5" name="zip_code" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['zip_code'])) { ?>value=<?=$_REQUEST['zip_code']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Country</b></td>
    <td valign="top" align="left"><input size="15" name="country" type="text"class="validate[required] text-input" <? if(isset($_REQUEST['country'])) { ?>value=<?=$_REQUEST['country']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Monthly Plan(number of items you can
      check out each month)</b></td>
    <td valign="top" align="left">
    <select name="plan">
      <option value="">Select</option>
      <? while($fetRow = mysql_fetch_array($sqlPlan)) {?>
      <option value="<?=$fetRow['items_per_month']?>"><?=$fetRow['items_per_month']?></option>
	  <? }?>
    </select></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Telephone</b></td>
    <td valign="top" align="left"><input id="phone" name="phone" <? if(isset($_REQUEST['password'])) { ?>value=<?=$_REQUEST['password']; }?>/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Cardholder Name</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="card_name" type="text"class="validate[required] text-input" <? if(isset($_REQUEST['card_name'])) { ?>value=<?=$_REQUEST['card_name']; }?>/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Credit/Debit Card Type</b></td>
    <td valign="top" align="left"><select name="card_type" class="validate[required] text-input">
      <option value="">CARD TYPE</option>
      <option value="1">Visa</option>
      <option value="2">MasterCard</option>
      <option value="3">Discover</option>
      <option value="4">American Express</option>
      <option value="5">Diner's Club</option>
    </select></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Credit/Debit Card Number</b></td>
    <td valign="top" align="left"><input maxlength="16" size="20" name="card_number" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['card_number'])) { ?>value=<?=$_REQUEST['card_number']; }?>/>
      &nbsp;Don't put dashes nor spaces</td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Card Expiration Date</b></td>
    <td valign="top" align="left">
        
        <input type="text" name="card_exp_date" id="date" <? if(isset($_REQUEST['card_exp_date'])) { ?>value=<?=$_REQUEST['card_exp_date']; }?>/>
        
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Card Security Code</b></td>
    <td valign="top" align="left"><input maxlength="4" size="4" name="card_sec" type="text" class="validate[required] text-input" <? if(isset($_REQUEST['card_sec'])) { ?>value=<?=$_REQUEST['card_sec']; }?>/>
      &nbsp;It's the 3 digit on the white stripe at the back of the card or the 4 digit on the upper right corner of the American Express card number</td>
      <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
    <td valign="top" align="left">---OR---</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Name on Bank Account</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="acct_name" type="text" <? if(isset($_REQUEST['acct_name'])) { ?>value=<?=$_REQUEST['acct_name']; }?>/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Name of Bank</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="bank_name" type="text"<? if(isset($_REQUEST['bank_name'])) { ?>value=<?=$_REQUEST['bank_name']; }?>/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank ABA Number</b></td>
    <td valign="top" align="left"><input maxlength="9" size="12" name="aba_number" type="text" <? if(isset($_REQUEST['aba_number'])) { ?>value=<?=$_REQUEST['aba_number']; }?>/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Example:</b></td>
    <td valign="top" align="left">123456789 (9 digits total length)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank Account Number</b></td>
    <td valign="top" align="left"><input maxlength="13" size="15" name="acct_num" type="text" <? if(isset($_REQUEST['acct_num'])) { ?>value=<?=$_REQUEST['acct_num']; }?>/>
      &nbsp;(Paying Gas Card directly from bank account can save you more money)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Example:</b></td>
    <td valign="top" align="left">1234567890 (8 to 13 digits total length)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank City</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="bank_city" type="text" <? if(isset($_REQUEST['bank_city'])) { ?>value=<?=$_REQUEST['bank_city']; }?>/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>State</b></td>
    <td valign="top" align="left">
    <select name="bank_state">
      <option value="">Select a state/province</option>
      <option value="1">Alabama</option>
      <option value="2">Alaska</option>
      <option value="3">Arizona</option>
      <option value="4">Arkansas</option>
      <option value="5">California</option>
      <option value="6">Canada-Alberta</option>
      <option value="7">Canada-New Brunswick</option>
      <option value="8">Canada-Ontario</option>
      <option value="9">Canada-British Columbia</option>
      <option value="10">Colorado</option>
      <option value="11">Connecticut</option>
      <option value="12">Delaware</option>
      <option value="13">District of Columbia</option>
      <option value="14">Florida</option>
      <option value="15">Georgia</option>
      <option value="16">Hawaii</option>
      <option value="17">Idaho</option>
      <option value="18">Illinois</option>
      <option value="19">Indiana</option>
      <option value="20">Iowa</option>
      <option value="21">Kansas</option>
      <option value="22">Kentucky</option>
      <option value="23">Louisiana</option>
      <option value="24">Maine</option>
      <option value="25">Maryland</option>
      <option value="26">Massachusetts</option>
      <option value="27">Michigan</option>
      <option value="28">Minnesota</option>
      <option value="29">Mississippi</option>
      <option value="30">Missouri</option>
      <option value="31">Montana</option>
      <option value="32">Nebraska</option>
      <option value="33">Nevada</option>
      <option value="34">Canada-New Brunswick</option>
      <option value="35">New Hampshire</option>
      <option value="36">New Jersey</option>
      <option value="37">New Mexico</option>
      <option value="38">New York</option>
      <option value="39">North Carolina</option>
      <option value="40">North Dakota</option>
      <option value="41">Ohio</option>
      <option value="42">Oklahoma</option>
      <option value="43">Canada-Ontario</option>
      <option value="44">Oregon</option>
      <option value="45">Pennsylvania</option>
      <option value="46">Rhode Island</option>
      <option value="47">South Carolina</option>
      <option value="48">South Dakota</option>
      <option value="49">Tennessee</option>
      <option value="50">Texas</option>
      <option value="51">Utah</option>
      <option value="52">Vermont</option>
      <option value="53">Virginia</option>
      <option value="54">Washington</option>
      <option value="55">Washington DC</option>
      <option value="56">West Virginia</option>
      <option value="57">Wisconsin</option>
      <option value="58">Wyoming</option>
    </select>
    </td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
    <td valign="top" align="left">---OR---</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>PayPal Account</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="paypal_name" type="text" <? if(isset($_REQUEST['paypal_name'])) { ?>value=<?=$_REQUEST['paypal_name']; }?>/>
      &nbsp;Paying with PayPal can save you money by reducing credit card transaction cost</td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Gender</b></td>
    <td valign="top" align="left"><input name="gender" value="m" type="radio" id="qf_2616c7" class="validate[required] text-input" <? if(isset($_REQUEST['gender'])) { ?>value=<?=$_REQUEST['gender']; }?>/>
        <label for="qf_2616c7">Male</label>
      &nbsp;
      <input name="gender" value="f" type="radio" id="qf_97b0a2" class="validate[required] text-input" <? if(isset($_REQUEST['gender'])) { ?>value=<?=$_REQUEST['gender']; }?>/>
      <label for="qf_97b0a2">Female</label></td>
      <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Birthdate</b></td>
    <td valign="top" align="left"><input type="text" id="date1" name="dob" <? if(isset($_REQUEST['dob'])) { ?>value=<?=$_REQUEST['dob']; }?>/>
     </td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Note:</b></td>
    <td valign="top" align="left">You must be at least 18 years old to use some of the services</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
    <td valign="top" align="left" class="field"><input id="signupsubmit" name="signup" type="submit" value="Signup" class="button2" /></td>
  </tr>
  <tr>
    <td></td>
    <td align="left" valign="top">Fields marked * are required</td>
  </tr>
</table>
</div>
</form> 