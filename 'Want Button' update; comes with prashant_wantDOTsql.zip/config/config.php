<?php
ob_start();
if(!isset($_SESSION))
session_start();
$tokenId = md5(uniqid(rand(), true));
//set_magic_quotes_runtime(1);

/*$connect_string='localhost';
$connect_username='root';
$connect_password='';
$conect_db='ezcruizer';
*/
//Server Config


$connect_string='localhost';
$connect_username='prashant_want';
$connect_password='Pace2012!';
$conect_db='prashant_want';

/*$connect_string='localhost';
$connect_username='root';
$connect_password='';
$conect_db='db_payperclip';*/



mysql_connect($connect_string,$connect_username,$connect_password) or die(mysql_error());
mysql_select_db($conect_db) or die(mysql_error());
$prefix = "";
$siteset_arr= mysql_query("select * from ".$prefix ."settings") or die(mysql_error());
$siteset_row = mysql_fetch_array($siteset_arr);
$copyright = "2007 - 2013 Universe Technology";
$url=$_SERVER['REQUEST_URI'];
$lmt = $siteset_row['results'];
$admin_email = $siteset_row['admin_email'];
$paypal_email = $siteset_row['paypal_email'];
$site_name = $siteset_row['site_name'];
$site_url = $siteset_row['site_url'];
$lookRecord = $siteset_row['lookRecord'];
$additionfee = $siteset_row['additionfee'];
$postagefee = $siteset_row['postagefee'];
$username = $siteset_row['username'];
$password = $siteset_row['password'];
$signature = $siteset_row['signature'];
$SmtpServer = $siteset_row['SmtpServer'];
$SmtpPort = $siteset_row['SmtpPort'];
$SmtpUser = $siteset_row['SmtpUser'];
$SmtpPass = $siteset_row['SmtpPass'];
$fromSite = $siteset_row['fromSite'];
$today = date('Y-m-d');



$madatory = "<font color=\"#FF0000\"><strong>*</strong></font>";

define("ADMINMAIL","".$admin_email."");

define("SITETITLE","".$site_name."");

define("SITEURL","".$site_url."");

define("PAYPAL","".$paypal_email."");

define("RECORDPERPAGE","".$lmt."");

define("LOOKRECORDPERPAGE","".$lookRecord."");

define("SCROLL_COLOR","#DADDEC");

define("MANDATORY","".$madatory."");

define("verificationId","".$tokenId."");

define("SMTPSERVER","".$SmtpServer."");

define("SMTPPORT","".$SmtpPort."");

define("SMTPUSER","".$SmtpUser."");

define("SMTPPASS","".$SmtpPass."");

define("FROMSITE","".$fromSite."");



##################### Defining Tables STARTS ###########################  
define("ADMIN", $prefix."admin");
define("CATEGORY", $prefix."categories");
define("SUBCATEGORY", $prefix."sub_category");
define("SUBCATEGORYCAT", $prefix."sub_category_cat");
define("LOOK", $prefix."look");
define("USERSETTINGS", $prefix."tbl_usersettings");
define("LEAVEREASON", $prefix."tbl_leavereason");
define("ITEMFORMAT", $prefix."item_format");
define("ITEMS", $prefix."items");
define("PLAN", $prefix."plan");
define("ORDERITEMS", $prefix."order_items");
define("ODERS", $prefix."orders");
define("ORDERSALE", $prefix."order_sale");
define("PAYOUTS", $prefix." payouts");
define("MEMBERSHIPFEE", $prefix." membership_fee");
define("PORTIONFORITEMOWNER", $prefix." portion_for_item_owner");





##################### Defining Tables ENDS ###########################

?>
