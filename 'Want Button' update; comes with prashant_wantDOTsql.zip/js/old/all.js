/*//<![CDATA[
function validate_reg_form(frm) {
  var value = '';
  var errFlag = new Array();
  _qfMsg = '';

  value = frm.elements['password'].value;
  if (value == '' && !errFlag['password']) {
    errFlag['password'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Password';
    var field = frm.elements['password'];
    field.value = field.defaultValue;
  }

  value = new Array();

  value[0] = frm.elements['password'].value;
  value[1] = frm.elements['confirm_password'].value;
  if ('' != value[0] && !(value[0] == value[1]) && !errFlag['password']) {
    errFlag['password'] = true;
    _qfMsg = _qfMsg + '\n - The passwords do not match';
    var field = frm.elements['password'];
    field.value = field.defaultValue;
    var field = frm.elements['confirm_password'];
    field.value = field.defaultValue;
  }

  value = frm.elements['password'].value;
  if (value != '' && (value.length < 3 || value.length > 16) && !errFlag['password']) {
    errFlag['password'] = true;
    _qfMsg = _qfMsg + '\n - Password can be 3 to 16 charecters length';
    var field = frm.elements['password'];
    field.value = field.defaultValue;
  }

  value = frm.elements['confirm_password'].value;
  if (value == '' && !errFlag['confirm_password']) {
    errFlag['confirm_password'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Confirm Password';
    var field = frm.elements['confirm_password'];
    field.value = field.defaultValue;
  }

  value = frm.elements['email'].value;
  if (value == '' && !errFlag['email']) {
    errFlag['email'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Email';
  }

  value = frm.elements['first_name'].value;
  if (value == '' && !errFlag['first_name']) {
    errFlag['first_name'] = true;
    _qfMsg = _qfMsg + '\n - Fill in First name';
  }

  value = frm.elements['last_name'].value;
  if (value == '' && !errFlag['last_name']) {
    errFlag['last_name'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Last name';
  }

  value = frm.elements['address_1'].value;
  if (value == '' && !errFlag['address_1']) {
    errFlag['address_1'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Street address';
  }

  value = frm.elements['city'].value;
  if (value == '' && !errFlag['city']) {
    errFlag['city'] = true;
    _qfMsg = _qfMsg + '\n - Fill in City';
  }

  value = frm.elements['state'].options[frm.elements['state'].selectedIndex].value;

  if (value == '' && !errFlag['state']) {
    errFlag['state'] = true;
    _qfMsg = _qfMsg + '\n - Fill in State';
  }

  value = frm.elements['zip_code'].value;
  if (value == '' && !errFlag['zip_code']) {
    errFlag['zip_code'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Zip code';
  }

  value = frm.elements['country'].value;

  if (value == '' && !errFlag['country']) {
    errFlag['country'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Country';
  }

  value = frm.elements['plan'].options[frm.elements['plan'].selectedIndex].value;

  if (value == '' && !errFlag['plan']) {
    errFlag['plan'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Monthly Plan(number of items you can\r\ncheck out each month)';
  }

  value = frm.elements['card_name'].value;
  if (value == '' && !errFlag['card_name']) {
    errFlag['card_name'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Cardholder Name';
  }

  value = frm.elements['card_type'].options[frm.elements['card_type'].selectedIndex].value;

  if (value == '' && !errFlag['card_type']) {
    errFlag['card_type'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Credit/Debit Card Type';
  }

  var card_number_groupElements = '::card_number_group[card_number]::card_number_group[card_number_desc]::';
  value = new Array();
  var valueIdx = 0;
  for (var i = 0; i < frm.elements.length; i++) {
    var _element = frm.elements[i];
    if (card_number_groupElements.indexOf('::' + _element.name + '::') >= 0) {
      switch (_element.type) {
        case 'checkbox':
        case 'radio':
          if (_element.checked) {
            value[valueIdx++] = _element.value;
          }
          break;
        case 'select':
          if (-1 != _element.selectedIndex) {
            value[valueIdx++] = _element.options[_element.selectedIndex].value;
          }
          break;
        default:
          value[valueIdx++] = _element.value;
      }
    }
  }

  var res = 0;
  for (var i = 0; i < value.length; i++) {
    if (!(value[i] == '')) {
      res++;
    }
  }
  if (res < 1 && !errFlag['card_number_group']) {
    errFlag['card_number_group'] = true;
    _qfMsg = _qfMsg + '\n - Fill in';
  }

  var card_exp_dateElements = '::card_exp_date[F]::card_exp_date[Y]::';
  value = new Array();
  var valueIdx = 0;
  for (var i = 0; i < frm.elements.length; i++) {
    var _element = frm.elements[i];
    if (card_exp_dateElements.indexOf('::' + _element.name + '::') >= 0) {
      switch (_element.type) {
        case 'checkbox':
        case 'radio':
          if (_element.checked) {
            value[valueIdx++] = _element.value;
          }
          break;
        case 'select':
          if (-1 != _element.selectedIndex) {
            value[valueIdx++] = _element.options[_element.selectedIndex].value;
          }
          break;
        default:
          value[valueIdx++] = _element.value;
      }
    }
  }

  if (value == '' && !errFlag['card_exp_date']) {
    errFlag['card_exp_date'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Card Expiration Date';
  }

  var card_sec_groupElements = '::card_sec_group[card_sec]::card_sec_group[card_sec_desc]::';
  value = new Array();
  var valueIdx = 0;
  for (var i = 0; i < frm.elements.length; i++) {
    var _element = frm.elements[i];
    if (card_sec_groupElements.indexOf('::' + _element.name + '::') >= 0) {
      switch (_element.type) {
        case 'checkbox':
        case 'radio':
          if (_element.checked) {
            value[valueIdx++] = _element.value;
          }
          break;
        case 'select':
          if (-1 != _element.selectedIndex) {
            value[valueIdx++] = _element.options[_element.selectedIndex].value;
          }
          break;
        default:
          value[valueIdx++] = _element.value;
      }
    }
  }

  var res = 0;
  for (var i = 0; i < value.length; i++) {
    if (!(value[i] == '')) {
      res++;
    }
  }
  if (res < 1 && !errFlag['card_sec_group']) {
    errFlag['card_sec_group'] = true;
    _qfMsg = _qfMsg + '\n - Fill in';
  }

  var gender_groupElements = '::gender_group[gender]::gender_group[gender]::';
  value = new Array();
  var valueIdx = 0;
  for (var i = 0; i < frm.elements.length; i++) {
    var _element = frm.elements[i];
    if (gender_groupElements.indexOf('::' + _element.name + '::') >= 0) {
      switch (_element.type) {
        case 'checkbox':
        case 'radio':
          if (_element.checked) {
            value[valueIdx++] = _element.value;
          }
          break;
        case 'select':
          if (-1 != _element.selectedIndex) {
            value[valueIdx++] = _element.options[_element.selectedIndex].value;
          }
          break;
        default:
          value[valueIdx++] = _element.value;
      }
    }
  }

  var res = 0;
  for (var i = 0; i < value.length; i++) {
    if (!(value[i] == '')) {
      res++;
    }
  }
  if (res < 1 && !errFlag['gender_group']) {
    errFlag['gender_group'] = true;
    _qfMsg = _qfMsg + '\n - Fill in';
  }

  var dobElements = '::dob[d]::dob[F]::dob[Y]::';
  value = new Array();
  var valueIdx = 0;
  for (var i = 0; i < frm.elements.length; i++) {
    var _element = frm.elements[i];
    if (dobElements.indexOf('::' + _element.name + '::') >= 0) {
      switch (_element.type) {
        case 'checkbox':
        case 'radio':
          if (_element.checked) {
            value[valueIdx++] = _element.value;
          }
          break;
        case 'select':
          if (-1 != _element.selectedIndex) {
            value[valueIdx++] = _element.options[_element.selectedIndex].value;
          }
          break;
        default:
          value[valueIdx++] = _element.value;
      }
    }
  }

  if (value == '' && !errFlag['dob']) {
    errFlag['dob'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Birthdate';
  }

  value = frm.elements['username'].value;
  if (value == '' && !errFlag['username']) {
    errFlag['username'] = true;
    _qfMsg = _qfMsg + '\n - Fill in Username';
    var field = frm.elements['username'];
    field.value = field.defaultValue;
  }

  value = frm.elements['username'].value;
  var regex = /^[a-z \-_0-9]+$/i;
  if (value != '' && !regex.test(value) && !errFlag['username']) {
    errFlag['username'] = true;
    _qfMsg = _qfMsg + '\n - Username can contain only letters, numbers, spaces, -, _';
  }

  value = frm.elements['username'].value;
  if (value != '' && (value.length < 3 || value.length > 16) && !errFlag['username']) {
    errFlag['username'] = true;
    _qfMsg = _qfMsg + '\n - Username can be 3 to 16 charecters length';
  }

  if (_qfMsg != '') {
    _qfMsg = 'Error' + _qfMsg;
    _qfMsg = _qfMsg + '\n';
    alert(_qfMsg);
    return false;
  }
  return true;
}
//]]>*/

$(document).ready(function() {
	// validate signup form on keyup and submit
	var validator = $("#signupform").validate({
		rules: {
			firstname: "required",
			lastname: "required",
			username: {
				required: true,
				minlength: 2,
				//remote: "users.php"
			},
			password: {
				required: true,
				minlength: 5
			},
			password_confirm: {
				required: true,
				minlength: 5,
				equalTo: "#password"
			},
			email: {
				required: true,
				email: true,
				//remote: "emails.php"
			},
			address_1: "required",
			city	: 	"required",
			state	: 	"required",
			zip_code: 	"required",
			country	: 	"required",
			plan	: 	"required",
			card_name: "required",
			card_type: "required",
			card_number: "required",
			card_exp_date:"required",
			gender	:"required",
			card_sec:"required",
			
			dateformat: "required",
			terms: "required"
		},
		messages: {
			firstname: "Enter your firstname",
			lastname: "Enter your lastname",
			username: {
				required: "Enter a username",
				minlength: jQuery.format("Enter at least {0} characters"),
				remote: jQuery.format("{0} is already in use")
			},
			password: {
				required: "Provide a password",
				rangelength: jQuery.format("Enter at least {0} characters")
			},
			password_confirm: {
				required: "Repeat your password",
				minlength: jQuery.format("Enter at least {0} characters"),
				equalTo: "Enter the same password as above"
			},
			email: {
				required: "Please enter a valid email address",
				minlength: "Please enter a valid email address",
				remote: jQuery.format("{0} is already in use")
			},
			address_1: {
				required: "Please enter address",
				},
				
			city	: 	"Please enter city",
			state	: 	"Please enter state",
			zip_code: 	"Please enter zip_code",
			country	: 	"Please enter country",
			plan	: 	"Please enter the plan",
			card_name: 	"Please enter the card holder name",
			card_type: 	"Please enter the card type",
			card_number: "Please enter the card number",
			card_exp_date: "Please enter the card expiration date",
			card_sec:"Please enter the card security code",
			gender:"Please enter the gender",
			dateformat: "Choose your preferred dateformat",
			terms: " "
		},
		// the errorPlacement has to take the table layout into account
		errorPlacement: function(error, element) {
			if ( element.is(":radio") )
				error.appendTo( element.parent().next().next() );
			else if ( element.is(":checkbox") )
				error.appendTo ( element.next() );
			else
				error.appendTo( element.parent().next() );
		},
		// specifying a submitHandler prevents the default submit, good for the demo
		submitHandler: function() {
			alert("submitted!");
		},
		// set this class to error-labels to indicate valid fields
		success: function(label) {
			// set &nbsp; as text for IE
			label.html("&nbsp;").addClass("checked");
		}
	});
	
	// propose username by combining first- and lastname
	$("#username").focus(function() {
		var firstname = $("#firstname").val();
		var lastname = $("#lastname").val();
		if(firstname && lastname && !this.value) {
			this.value = firstname + "." + lastname;
		}
	});

});


