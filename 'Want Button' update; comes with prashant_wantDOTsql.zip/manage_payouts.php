<?

include("includes/_include.php");
?>

  
<? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
$query="Select * from portion_for_item_owner limit 1";
		$result = @mysql_query($query);
		$portion = mysql_fetch_array($result);
		$dollar= $portion["dollar_amount"];
?>

   
<h2>Manage Payouts</h2>
	 <br />
   <form action="#" method="post" >

   <table border=0 width=100%>
   <tr>
   <td width="40%">
   <table width=100% cellpadding=2 cellspacing=0 border=1>
   <tr>
		<td>Member Name</td>
		<td>Balance</td>
		<td>Credit</td>
		 <td>Debit</td>
         <td>&nbsp;</td>
    </tr>
    <?php
	$i=0;
	while($row=mysql_fetch_array($fetRowPayOutAll)){ ?>
		<tr>
		<td><?=$row['owner_id']?></td>
        <td><?=$row['bal']?></td>
        <td><?=$row['cr']?></td>
        <td><?=$row['deb']?></td>
        <td><a href="home.php?page=managePayouts&owner=<?=$row['owner_id']?>">View details</a></td>
	</tr>
	    <? $i++; }?>
   </table>
   <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="74%">&nbsp;</td>
    <td width="26%">&nbsp;</td>
  </tr>
  <tr>
    <td><h3>Total Payouts:</h3></td>
    <td><strong>$
      <?php  
 // echo $i;
echo number_format($dollarAmount *$i,2)?>
    </strong></td>
  </tr>
</table></td>
   <td  valign="top">
   <? if(isset($_REQUEST['owner'])) {?>
      <div id="details">
       Details of  <b><?php echo $_REQUEST['owner']?></b>
   <table  border=1 width=100% cellpadding=2 cellspacing=0>
   
   <tr>
   <td>Credit</td>
   <td>Debit</td>
   <td>Transaction Date</td>
   <td>Description</td>
   </tr>
   <?
   while($Fetrow=mysql_fetch_array($fetSinglePayData)){
	   $transaction_date1 = explode("-",$Fetrow['transaction_date']);
			$d = $transaction_date1[2];
			$m = $transaction_date1[1];
			$y = $transaction_date1[0];
			$transaction_date = $m."/".$d."/".$y;
   ?>
   <tr>
     <td><?=$Fetrow['credit']?></td>
     <td><?=$Fetrow['debit']?></td>
     <td><?=$transaction_date?></td>
     <td><?=$Fetrow['description']?></td>
   </tr>
   <? }?>
	   </table></div>
       <? }?>
   </td>
   </tr></table>
   </form>
   
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
</table>

<? include("includes/footer.php");?>
