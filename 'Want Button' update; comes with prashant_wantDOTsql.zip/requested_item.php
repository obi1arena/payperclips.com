<?
include("includes/_include.php");
?>
<? include("includes/frontHeader.php");?>
<h3>Requested Item List</h3>
  <ul>
     
	   <?php 
	      $want_product = mysql_query("select * from want_product where status = 0 order by id DESC")or die(mysql_error());
		  while($want_product_result = mysql_fetch_array($want_product))
		  {
	   ?>
         <li><?php echo $want_product_result['item']; ?></li>
	   <?php } ?>
  </table>
<? include("includes/footer.php");?>