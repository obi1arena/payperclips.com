<?
include("includes/_include.php");
?>
  <? include("includes/frontHeader.php");
 
if(!empty($_REQUEST['vendor']))
{
	$userName=$_REQUEST['vendor'];
}
else
{
	$userName=$_REQUEST['userName'];
}
$category=fetchCategoryUser($userName);
$itemCategory=fetchItemCategoryUser($userName);
$itemCount = fetchCategoryUserCount($userName);


?>

<? 



if($itemCount==0)
{
	echo "No items currently available in this category";
}
else
{
?>

<p>Please choose a category:</p><ul>
<? while($fetchCategory=mysql_fetch_array($category)) {

	$catid = $fetchCategory['catid'];

$itemCategory=fetchSelectCategory($catid);
?>
<li><a href="home.php?page=show_cat&vendor=<?=$userName;?>&catid=<?=$fetchCategory['catid']?>"><?=$itemCategory['catname']?></a></li>
<? }
	
	
	
?>
</ul>
<? }?>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=home" class="button2">Continue Shopping</a></td>
  </tr>
</table>