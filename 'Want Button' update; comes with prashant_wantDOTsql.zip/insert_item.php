<? ob_start();
include("includes/_include.php");
?>
 <? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
?>
  
  <form enctype='multipart/form-data' method="post" action="" id="formID">
  <table >
  <tr>
  <td colspan="2">
  <? if(isset($GLOBALS['item_insert'])) { echo $GLOBALS['item_insert']; }?>
  </td>
  </tr>
  <tr>
    <td>Item Title:</td>
    <td><input type="text" name="title" class="validate[required] text-input"/></td>
  </tr>
  <tr>
    <td>Item Author:</td>
    <td><input type="text" name="author"  class="validate[required] text-input"/></td>
   </tr>
   <tr>
      <td>Category:</td>
      <td>	  
	  <select name="category" class="validate[required] text-input">
      <option value="" selected="selected"></option>
      <!--<option value="" selected="selected">Select A Category</option>-->
 <?
 $fetchCategory=fetchCategory();
 while($category=mysql_fetch_array($fetchCategory)) {?>
 <option value="<?=$category['catid'];?>" ><?=$category['catname'];?></option>
<?
}
?>
 </select>
        </td>
   </tr>
   <tr>
      <td>Item Format:</td>
      <td>
<select name="format" class="validate[required] text-input">
<option value="" selected="selected"></option>
<!--<option value="" selected="selected">Select a format</option>--> 
<?
 $fetchItemFormat=fetchItemFormat();
 while($item_format=mysql_fetch_array($fetchItemFormat)) {?>
 <option value="<?=$item_format['format'];?>" ><?=$item_format['format'];?></option>
<?
}
?>
 </select>
        </td>
   </tr>
  
   <tr>
     <td>Description:</td>
     <td><textarea rows="3" cols="50" name="description" class="validate[required] text-input"></textarea></td>
    </tr>		
     <tr>
      	<td>Upload item picture:</td>
	<td>
		 <input type='file' name='file' class="validate[required] text-input">	
	</td>
      </tr>
    <tr>
      <td colspan="2" align="center">
                 <input type="submit" value="Add Item" name="btn_add_item" class="button2">
        </form></td>
                 </td>
      </tr>
     
  </table>
  </form>
  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
</table>

<? include("includes/footer.php");?>