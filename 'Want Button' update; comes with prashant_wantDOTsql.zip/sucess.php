<?
include("includes/_include.php");
?>
  <? include("includes/frontHeader.php");?>
 <?
 
 //for user monthly fees
addPenaltyAmt();
					

$old_sessionid = session_id();
session_regenerate_id();
$new_sessionid = session_id();

//echo "Old Session: $old_sessionid<br />";
//echo "New Session: $new_sessionid<br />";

//print_r($_SESSION);
 ?>
<table width="100%" border="1">
  <tr>
    <td align="center"><h2>Order Confirmed Successfully.</h2></td>
  </tr>
</table>

