<?
include_once("includes/_include.php");
?>
  <? include_once("includes/frontHeader.php");

if($userData['plan']==0)
{
	header('Location:home.php?page=changePlan&plan');
}


$temp_cart=fetchTempItemLogView(); 

?>

<h2>Checkout <? //echo tempCartQntyLog();?></h2>
<table border = 0 width = 100% cellspacing = 0>
        <form action = show_cart.php method = post>
        <tr><th colspan = 1 bgcolor="#cccccc">Item</th>
       <th bgcolor="#cccccc">Quantity</th>
        <th bgcolor="#cccccc"></th></tr>
         <? while($cart=mysql_fetch_array($temp_cart)) {
		
		$itemsDetails=fetchItemsDetails($cart['item_id']);
		$itemPrice=fetchItemsPrice($cart['item_id']);
		?>
        <tr><td align = left><a href = "home.php?page=show_item&item_id=<?=$cart['item_id']?>&type=rented"><?=$itemsDetails['title']?></a> by <?=$itemsDetails['owner']?></td>
        
        <td align = center><?=$cart['quantity'];?></td>
        
        <td align = center>&nbsp;</td></tr>
        <input type="hidden" name="cartSessionId" id="cartSessionId" value="<?=$cart['sesionId'];?>">
         <? }?>
        <tr>
       
          <th colspan = 1 bgcolor="#cccccc">&nbsp;</td>
          <th align = center bgcolor="#cccccc"> 
         
             <? 
				echo tempCartQntyLog();
			 ?>
          </th>
          <th align = center bgcolor="#cccccc">
              </th>
        </tr></form></table>  <br />
  <table border = 0 width = 100% cellspacing = 0>
  <form action=""  method ="post" name="frm_cart" id="frm1">
  <tr><th colspan = 2 bgcolor="#cccccc">Your Details</th></tr>
  <tr>
    <td>Name</td> 	
    <td><input type = text name = name value = "<?=$userData['first_name']." ".$userData['last_name'];?>" maxlength = 40 size = 40></td>
  </tr>
  <tr>
    <td>Address</td> 	
    <td><input type = text name = address value = "<?=$userData['address_1']." ".$userData['address_2']?>" maxlength = 40 size = 40></td>
  </tr>
  <tr>
    <td>City/Suburb</td>
    <td><input type = text name = city value = "<?=$userData['city'];?>" maxlength = 20 size = 40></td>
  </tr>
  <tr>
    <td>State/Province</td>
    <td><input type = text name = state value = "<?=$userData['state'];?>" maxlength = 20 size = 40></td>
  </tr>
  <tr>
    <td>Postal Code or Zip Code</td>
    <td><input type = text name = zip value = "<?=$userData['zip_code'];?>" maxlength = 10 size = 40></td>
  </tr>
  <tr>
    <td>Country</td>
    <td><input type = text name = country value = "<?=$userData['country'];?>" maxlength = 20 size = 40></td>
  </tr>
   <tr>
    
    <td colspan = 2 align = center>
      <b><!--Please press one of the 3 Purchase methods to confirm your purchase,
         or Continue Shopping to add or remove items--></b>
      <input type="submit" name="checkOutSubmit" value="Complete Checkout" class="button2">
     <center>
       <table border=0 cellspacing=0 cellpadding=15>
  	 <tr>
	   <td>
     	    	   </td>
	   <td>
     	    	   </td>
	   <td>
     	    	   </td>
	   <td>
				   </td>
         </tr>
       </table>
     </center>
    </td>
  </tr>
  </form>
  </table><hr />
<table width="100%" cellspacing="2" cellpadding="2">
<tr><td><center><a href="home.php?page=home" class="button2"><img src="images/continue-shopping.gif"
           alt="Continue Shopping" border=0 height = 50 width = 135></a></center><td>
  
  
  </tr></table>

  <? include("includes/footer.php");?>
