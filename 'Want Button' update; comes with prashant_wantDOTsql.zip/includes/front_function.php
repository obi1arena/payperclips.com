<?
$search_sql ="";
	if (isset($_POST['search_mode']) && ($_REQUEST['search_mode']=="ALPHA"))
	{
		if($_SESSION['userId']!='')
		{
		$search_sql .= "SELECT * FROM admin WHERE first_name  like '".$_POST['txt_alpha']."%'"."  ORDER BY first_name";
		}
		else
		{
		$search_sql .= "SELECT * FROM admin WHERE first_name  like '".$_POST['txt_alpha']."%'"." ORDER BY first_name";
		}
	}
	elseif (isset($_POST['search_mode']) && ($_POST['search_mode']=="SEARCH"))
	{
				if($_SESSION['userId']!='')
				{
				$search_sql .= "SELECT * FROM admin WHERE zip_code  like '".$_POST['txt_search']."%'"."  ORDER BY first_name";
				}
				else
				{
				$search_sql .= "SELECT * FROM admin WHERE zip_code  like '".$_POST['txt_search']."%'"." ORDER BY first_name";
				}
	}
	else
	{
		if($_SESSION['userId']!='')
				{
				$search_sql .= "SELECT * FROM admin ORDER BY first_name";
				}
				else
				{
				$search_sql .= "SELECT * FROM admin ORDER BY first_name";
				}
	}
	$total_record = mysql_num_rows(mysql_query($search_sql));
	/*$limit = RECORDPERPAGE;
	if(isset($_REQUEST['page']) && ($_REQUEST['page']))
	{
		$start= ($_REQUEST['page'] - 1) * $limit;
		$page = $_REQUEST['page'];
	}
	else
	{
		$start=0;
		$page = 1;
	}*/
	//$search_sql_new = $search_sql." limit $start,$limit";
	$search_rs = mysql_query($search_sql);
	$count = mysql_num_rows($search_rs);
	//echo $search_sql_new;
	
?>