<?
/***************************************************START FUNCTION FOR FETCH MONTHLY PLAN****************************************************************************/
function monthlyPlanData()
{
	$plan = mysql_query("SELECT * FROM ".PLAN." ORDER BY planID");
	return $plan;
}
/***************************************************START FUNCTION FOR FETCH MONTHLY PLAN****************************************************************************/

?>