<?
include("config/config.php");
include("functions.php");
include("function.php");
include("front_function.php");
include("signup_function.php");
include("login_function.php");
include("admin_function.php");
include("db1.php");


?>
<?
// user id
$userId=$_SESSION['userId'];
$username=$_SESSION['username'];


//Ftech Plan
$sqlPlan = monthlyPlanData();
//user registration
if(isset($_REQUEST['signup']))
{
	signup();
}

//user login
if(isset($_REQUEST['login']))
{
	login();
}

//user insert category
if(isset($_REQUEST['btn_category']))
{
	insertCategory();
}

//user insert item
if(isset($_REQUEST['btn_add_item']))
{	
	insertItem();
}

//user insert item
if(isset($_REQUEST['btn_edit']))
{	
	editUser();
}

// fetch user details
$userData=userData($userId);

// for final checkout
if(isset($_REQUEST['checkOutSubmit']))
{
	userCart();
}

//Data add for manage format
if(isset($_REQUEST['add_manage_format']))
{
$GLOBALS['msg_err']=insertformat();
}
//Data delete for manage format
if(isset($_REQUEST['delete_manage_format']))
{
$GLOBALS['msg_err']=delete_manage_format();
}
//Data update for manage format
if(isset($_REQUEST['update_manage_format']))
{
$GLOBALS['msg_err']=update_manage_format();

}
if(isset($_REQUEST['delete_admin_plan']))
{
$GLOBALS['msg_err']=delete_admin_plan();

}
if(isset($_REQUEST['add_admin_plan']))
{
$GLOBALS['msg_err']=add_admin_plan();

}

if(isset($_REQUEST['update_admin_plan']))
{
$GLOBALS['msg_err']=update_admin_plan();

}
if(isset($_REQUEST['createUser']))
{
$GLOBALS['msg_errh']=createUser();
}
if(isset($_REQUEST['delete_user_item']))
{
$GLOBALS['msg_err']=delete_user_item();
}
if(isset($_REQUEST['become_user']))
{
$GLOBALS['msg_err']=become_user();
}
if(isset($_REQUEST['make_Superuser']))
{
$GLOBALS['msg_err']=make_Superuser();
}
if(isset($_REQUEST['AlleditUser']))
{
$GLOBALS['msg_err']=AlleditUser();
}
if(isset($_REQUEST['submit_track'])) {  
$msg=ordersaletrackSubmit();
 } 
 if(isset($_REQUEST['submit_track_rent'])) {  
$msg=submit_track_rent();
 }
//fetch rent result
if($_REQUEST['page']=="rentedItems")
{
$fetRentResult = rentResultgp($userId);
$rentItemTrack = rentItemTrackgp($userId);
}
if($_REQUEST['page']=="saleResult")
{
$fetsaleResult = saleResult($_SESSION['username']);
$fetitemId = saleitemtrack($_SESSION['username']);
}
if($_REQUEST['penalty_submit'])
{

$err=penalty_submit();
}
//Monthly Plan Charge
$planID = $userData['plan'];
$monthlyPlanCharge = planCharge($planID);
//rebate amount
$username=$_SESSION['username'];
$rb = rebateAmt($username);
//update userinfo

if(isset($_REQUEST['btnUpdateDetails']))
{
	userInfo($userId);
}
//update Plan
if(isset($_REQUEST['btnChangePlan']))
{
	updatePlan($userId);
}
//Payout Info for all record
$fetRowPayOutAll = payoutList();
//Payout for one User
$owner = $_REQUEST['owner'];
$fetSinglePayData = payoutData($owner);
$dollarAmount = dollarAmount();

// for item edit
if(isset($_REQUEST['btn_edit_item']))
{
	editItem();
}
 


// for shopping cart
if($_REQUEST['page']=='shopping_cart')
{
 $item_id=$_REQUEST['item_id'];
 $catid=$_REQUEST['catid'];
 	if(isset($item_id))
 	{
		$itemTemp=tempCart($item_id);
	}
}
// for logged user shopping item count
if(!empty($_SESSION['userId'])) 
{
	if(($_REQUEST['page']=='shopping_cart') || ($_REQUEST['page']=='checkout'))
	{
		fetchTempItemLog();
	}
}
//for count item in view shopping cart
 $total = tempCartQntyLog();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome to PayPerClips</title>
<link rel="stylesheet" type="text/css" href="css/button.css" media="all" />
<link rel="stylesheet" href="css/validationEngine.jquery.css" type="text/css"/>
	<link rel="stylesheet" href="css/template.css" type="text/css"/>
	<script src="js/jquery-1.8.2.min.js" type="text/javascript">
	</script>
	<script src="js/languages/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8">
	</script>
	<script src="js/jquery.validationEngine.js" type="text/javascript" charset="utf-8">
	</script>
	<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			jQuery("#formID").validationEngine({autoHidePrompt:true});
		});

		/**
		*
		* @param {jqObject} the field where the validation applies
		* @param {Array[String]} validation rules for this field
		* @param {int} rule index
		* @param {Map} form options
		* @return an error string if validation failed
		*/
		function checkHELLO(field, rules, i, options){
			if (field.val() != "HELLO") {
				// this allows to use i18 for the error msgs
				return options.allrules.validate2fields.alertText;
			}
		}
	</script>
    <!--phono no-->

<script src="js/jquery.maskedinput.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function() {
        $.mask.definitions['~'] = "[+-]";
        $("#date").mask("99/99/9999",{completed:function(){}});
        $("#phone").mask("999-999-9999");
        $("#phoneExt").mask("(999) 999-9999? x99999");
        $("#iphone").mask("+33 999 999 999");
        $("#tin").mask("99-9999999");
        $("#ssn").mask("999-99-9999");
        $("#product").mask("a*-999-a999", { placeholder: " " });
        $("#eyescript").mask("~9.99 ~9.99 999");
        $("#po").mask("PO: aaa-999-***");
		$("#pct").mask("99%");

        $("input").blur(function() {
            $("#info").html("Unmasked value: " + $(this).mask());
        }).dblclick(function() {
            $(this).unmask();
        });
    });
	
</script>
<!--phono no-->

	<!--for date-->
    
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"></script>
    <script type="text/javascript">
    $(function() {
        $("#date")
				.datepicker({ nextText: "", prevText: "", changeMonth: true, changeYear: true })
				.mask("99/99/9999");
				$("#date1")
				.datepicker({ nextText: "", prevText: "", changeMonth: true, changeYear: true })
				.mask("99/99/9999");
				
    });
	
</script>

	<link type="text/css" rel="stylesheet" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/redmond/jquery-ui.css" />

<!--for date-->

</head>

<body>