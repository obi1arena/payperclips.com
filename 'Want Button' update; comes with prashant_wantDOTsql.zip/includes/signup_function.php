<?
/**********************************************************Start for user registration**************************/
function signup()
{
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$password_confirm=$_REQUEST['password_confirm'];
$email=$_REQUEST['email'];
$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$address_1=$_REQUEST['address_1'];
$address_2=$_REQUEST['address_2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$zip_code=$_REQUEST['zip_code'];
$country=$_REQUEST['country'];
$plan=$_REQUEST['plan'];
$phone=$_REQUEST['phone'];
$card_name=$_REQUEST['card_name'];
$card_type=$_REQUEST['card_type'];
$card_number=$_REQUEST['card_number'];
$date=explode("/",$_REQUEST['card_exp_date']);
	$m=$date[0];
	$d=$date[1];
	$y=$date[2];
	$card_exp_date=$y."-".$m."-".$d;


$card_sec=$_REQUEST['card_sec'];
$acct_name=$_REQUEST['acct_name'];
$bank_name=$_REQUEST['bank_name'];
$aba_number=$_REQUEST['aba_number'];
$acct_num=$_REQUEST['acct_num'];
$bank_city=$_REQUEST['bank_city'];
$bank_state=$_REQUEST['bank_state'];
$paypal_name=$_REQUEST['paypal_name'];
$gender=$_REQUEST['gender'];

$date1=explode("/",$_REQUEST['dob']);
	$m1=$date[0];
	$d1=$date[1];
	$y1=$date[2];
	$dob=$y1."-".$m1."-".$d1;

	if($username=='' || $password=='' || $email=='' || $firstname=='' || $lastname=='' || $address_1=='' || $city=='' || $state=='' || $zip_code=='' || $country=='' || $plan=='' || $card_name=='' || $card_type=='' || $card_number=='' || $card_exp_date=='' || $card_sec=='' || $gender=='' || $dob=='' )
	{
		header('Location:home.php?page=registration');
		//exit;
	}
	else
	{
	
	$value="
	username		=	'".$username."'
	,password		=	'".$password."'
	,god			=	''
	,first_name		=	'".$firstname."'
	,last_name		=	'".$lastname."'
	,address_1		=	'".$address_1."'
	,address_2		=	'".$address_2."'
	,city			=	'".$city."'
	,state			=	'".$state."'
	,zip_code		=	'".$zip_code."'
	,telephone		=	'".$phone."'
	,email			=	'".$email."'
	,gas_pas		=	'".$email."'
	,card_name		=	'".$card_name."'
	,card_type		=	'".$card_type."'
	,card_number	=	'".$card_number."'
	,card_exp_date	=	'".$card_exp_date."'
	,card_sec		=	'".$card_sec."'
	,acct_name		=	'".$acct_name."'
	,bank_name		=	'".$bank_name."'
	,aba_number		=	'".$aba_number."'
	,acct_num		=	'".$acct_num."'
	,bank_city		=	'".$bank_city."'
	,bank_state		=	'".$bank_state."'
	,paypal_name	=	'".$paypal_name."'
	,vehicle_mnfct	=	''
	,vehicle_model	=	''
	,vehicle_year	=	''
	,gender			=	'".$gender."'
	,dob			=	'".$dob."'
	,country		=	'".$country."'
	,plan			=	'".$plan."'
	";
		
		
		//echo $value;
		//exit;
		$fetch_user_login=mysql_num_rows(mysql_query("SELECT * FROM ".ADMIN." WHERE username='".$username."' OR email='".$email."' "));
		if($fetch_user_login>0)
		{
			$GLOBALS['msg_err']='Username or email already exists.';
		}
		else
		{
			if(Insert_Qry(ADMIN,$value))
			{
		
				$userId=mysql_insert_id();
				$fetch_user=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$userId."' "));
				$userName=$fetch_user['username'];
				$plan=$fetch_user['plan'];
				
				$fetch_plan_fee=mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$plan."' "));
				$planFee=$fetch_plan_fee['monthly_fee'];
				
				$value2="
				membership_fee	=	'".$planFee."'
				,rebate_amount	=	''
				,period			=	'1 Month'
				,description	=	''
				,owner			=	'".$userName."'
				,station		=	''
				";
				
				if(Insert_Qry(MEMBERSHIPFEE,$value2))
				{
					$_SESSION['msg_success']="You have successfully registered.";	
					header('Location:home.php?page=login');
				}
				else
				{
					$GLOBALS['msg_err']="Sorry there some error please try again.";	
				}
			
			}
			else
				{
					$GLOBALS['msg_err']="Sorry there some error please try again.";	
				}
		}
	}
}
/**********************************************************Start for user registration**************************/

?>