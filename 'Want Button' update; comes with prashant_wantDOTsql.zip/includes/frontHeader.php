<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td width="16%" align="left"><a href="home.php?page=home" class="button2">PayPerClips</a></td>
    <?php if(isset($_SESSION['userId'])) {
    ?>
    <td width="22%" align="right">Total Items: <?
	 if(tempCartQntyLog()!='') {echo tempCartQntyLog();} else { echo '0';}?></td>
     <td width="13%" align="right">

<a href="home.php?page=viewShoppingCart" class="button2"></a>

<a href="home.php?page=rentedItems" class="button2">


View Your Shopping Cart</a></td>
    <td width="8%" align="right"><a href="home.php?page=myaccount" class="button2">My Account</a></td>
    <td width="8%" align="right"><a href="#" class="button2">View Your Wishlist</a></td>
    <td width="8%" align="right"><a href="home.php?page=logout" class="button2">Logout</a></td>
    <td width="14%" align="right">Wellcome <?=$_SESSION['username'];?></a></td>
	<? } else
	{?>
    <td width="5%" align="right"><a href="home.php?page=login" class="button2">Login</a></td>
    <td width="6%" align="right"><a href="home.php?page=registration" class="button2">Register</a></td>
  <? }?>
  </tr>
  <tr>
    <td colspan="5">&nbsp;</td>
  </tr>
</table>
<? if($_SESSION['username']!='') {?>
<h1>Welcome, <?=$_SESSION['username'];?> </h1>
<? } else {?>
<h1>Welcome, Guest</h1>
<? }?>