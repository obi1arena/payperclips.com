<?php
function getValue($TableName,$ID,$ID_Name,$FieldNames)
{
	$sql_getValue = "Select ".$FieldNames." from ".$TableName." where ".$ID_Name."='".$ID."'";
	
	$query_getValue = mysql_query($sql_getValue);
	$rs_getValue = mysql_fetch_array($query_getValue);
	
	if (mysql_num_rows($query_getValue) > 0) return $rs_getValue[0];
	else return "";
	
	mysql_free_result($query_getValue);
}

function getContent($TableName,$FieldNames)
{
	$sql_getValue = "Select ".$FieldNames." from ".$TableName." where 1";
	//echo $sql_getValue;
	$query_getValue = mysql_query($sql_getValue);
	$rs_getValue = mysql_fetch_array($query_getValue);
	
	if (mysql_num_rows($query_getValue) > 0) return $rs_getValue[0];
	else return "";
	
	mysql_free_result($query_getValue);
}

function thumbnail($filethumb,$file,$Twidth,$Theight,$tag)
{

list($width,$height,$type,$attr)=getimagesize($file);


switch($type)
{
case 1:
$img = ImageCreateFromGIF($file);
break;
case 2:
$img=ImageCreateFromJPEG($file);
break;
case 3:
$img=ImageCreateFromPNG($file);
break;
}
if($tag == "width") //width contraint
{
$Theight=round(($height/$width)*$Twidth);
}
elseif($tag == "height") //height constraint
{
$Twidth=round(($width/$height)*$Theight);
}
else
{
if($width > $height)
$Theight=round(($height/$width)*$Twidth);
else
$Twidth=round(($width/$height)*$Theight);
}

$thumb=imagecreatetruecolor($Twidth,$Theight);
if(imagecopyresampled($thumb,$img,0,0,0,0,$Twidth,$Theight,$width,$height))
{

switch($type)
{
case 1:
ImageGIF($thumb,$filethumb);
break;
case 2:
ImageJPEG($thumb,$filethumb);
break;
case 3:
ImagePNG($thumb,$filethumb);
break;
}
return true;
}
}

function upload_file($file,$dir,$new_filename,$thumb_width)
{
if($_FILES[$file]['name']!="")
{ 
$exp=explode('.',$_FILES[$file]['name']); 
$file_name = $new_filename.".".$exp[1];
$dir_thumb = $dir."/thumb/"; //Thumb directory
$dir_normal = $dir."/normal/"; //Normal Directory where photo will stay
list($width, $height, $type, $attr)=getimagesize($_FILES[$file]['tmp_name']);
if($width > $thumb_width) //Checking the width of image
{
$Twidth = $thumb_width;
}
else
{
$Twidth = $width;
}
$Theight = $height;
$tag = 'width';
if (file_exists($dir_normal.$file_name)) 
{
unlink($dir_normal.$file_name);
}
$result=move_uploaded_file($_FILES[$file]['tmp_name'],$dir_normal.$file_name);
//umask(0);
chmod($dir_normal.$file_name,777); // Image will go to normal directory
if($result)
{
if (file_exists($dir_thumb.$file_name)) 
{
unlink($dir_thumb.$file_name);
}
thumbnail($dir_thumb.$file_name,$dir_normal.$file_name,$Twidth,$Theight,$tag);
}
return $file_name;

}
else
{
return false;
}
}


function gettotaluser()
{
	$totuserROW = mysql_fetch_array(mysql_query("SELECT count(*) FROM ".USER.""));
	return $totuserROW[0];
}


function lastParticipate()
{
	$totuserROW = mysql_fetch_array(mysql_query("SELECT * FROM ".RESULT." ORDER BY participate_date desc limit 0,1"));
	$user=mysql_fetch_array(mysql_query("SELECT * FROM ".USER." where userId='".$totuserROW['userId']."'"));
	return $user;
}
function lastjoinuser()
{
	$totuserROW = mysql_fetch_array(mysql_query("SELECT * FROM ".USER." ORDER BY userId desc limit 0,1"));
	return $totuserROW;
}

////////////////////////////////////////////////// Pagination with Search - Starts //////////////////////////////////
function paging($frmName,$start,$page,$total_record,$limit)
{
?>
<script language="JavaScript">
	function frm_sub(page)
	{
	
		document.<?=$frmName?>.action="<?=$_SERVER['PHP_SELF']?>";
		document.<?=$frmName?>.page.value = page;
		<?php if(isset($_REQUEST['Keyword'])&&isset($_REQUEST['categoryId'])){?>
		document.<?=$frmName?>.Keyword.value = '<?php echo $_REQUEST['Keyword'];?>';
		document.<?=$frmName?>.categoryId.value = '<?php echo $_REQUEST['categoryId'];?>';
		<?php }?>
		document.<?=$frmName?>.submit();
	}
</script>
<?php
	$adjacents = 3;
	//$limit = 5;
	$lastpage = ceil($total_record/$limit);
	$prev = $page - 1;
	$next = $page + 1;
	$lpm1 = $lastpage - 1;
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"javascript:frm_sub($prev)\" class=footer>&laquo; previous</a>";
		else
			$pagination.= "<span class=\"disabled\" class=footer>&laquo; previous</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\" class=footer>$counter</span>";
				else
					$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\" class=footer>$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
				$pagination.= "<span class=\"whitetext\">...</span>";
				$pagination.= "<a href=\"javascript:frm_sub($lpm1)\" class=footer>$lpm1</a>";
				$pagination.= "<a href=\"javascript:frm_sub($lastpage)\" class=footer>$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"javascript:frm_sub(1)\" class=footer>1</a>";
				$pagination.= "<a href=\"javascript:frm_sub(2)\" class=footer>2</a>";
				$pagination.= "<span class=\"whitetext\">...</span>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
				$pagination.= "<span class=\"whitetext\">...</span>";
				$pagination.= "<a href=\"javascript:frm_sub($lpm1)\" class=footer>$lpm1</a>";
				$pagination.= "<a href=\"javascript:frm_sub($lastpage)\" class=footer>$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"javascript:frm_sub(1)\" class=footer>1</a>";
				$pagination.= "<a href=\"javascript:frm_sub(2)\" class=footer>2</a>";
				$pagination.= "<span class=\"whitetext\">...</span>";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"javascript:frm_sub($next)\" class=footer>next &raquo;</a>";
		else
			$pagination.= "<span class=\"disabled\">next &raquo;</span>";
		$pagination.= "</div>\n";		
	}
	return $pagination;
}
////////////////////////////////////////////////// Pagination with Search - Ends //////////////////////////////////
////////////////////////////////////////////////// Alphabetical Search - Starts //////////////////////////////////
function DisplayAlphabet($val){
		$str_alpha = '';
		$str="A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
		$str=split(",",$str);
		
		$str_alpha .= "<table width=\"60%\" cellpadding=\"0\" cellspacing=\"0\">";
		$str_alpha .= "<tr>";
		for($i=0; $i < sizeof($str); $i++){
			if($i==13)
			{
				$str_alpha .= "</tr><tr>";
			}
			$str_alpha .= "<td align=\"center\" valign=\"top\">";
			$str_alpha .= "<div class=\"pagination\">";
			if($val==$str[$i])
			{
				$str_alpha .= "<span class=\"disabled\">$str[$i]</span>";
			}
			else
			{
				$str_alpha .= "<a href=\"#\" onClick=\"javascript:search_alpha('".$str[$i]."')\">$str[$i]</a>";
			}
			$str_alpha .= "</div>";			
			$str_alpha .= "</td>";
		}
		$str_alpha .= "</tr>";
		$str_alpha .= "</table>";
		echo $str_alpha;
}
//////////////////////////	
function getCategoryInfo($id)
{
$sql="SELECT * FROM ".QUES_CATEGORY." WHERE categoryId='".$id."'";
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);
return $row; 
}
function getQuestionInfo($id)
{
$sql="SELECT * FROM ".QUESTION." WHERE questionId='".$id."'";
$rs=mysql_query($sql);
$row=mysql_fetch_array($rs);
return $row; 
}
function getUserName($id)
{
  $qryUser=mysql_query("SELECT * FROM ".USER." WHERE userId='".$id."'");
  $rowUser=mysql_fetch_array($qryUser);
  $name=$rowUser['fName'];
  return $name;
}
function getProjectPath($str)
{
	$strarry=explode("/",$str);
	$c=count($strarry);
	for($i=0;$i<$c-1;$i++)
	{
		$st.=$strarry[$i]."/";
	}
	return $st;
}
////////////////////////////////////////////////// Pagination with Search - Starts fron end//////////////////////////////////
function paging1($frmName,$start,$page,$total_record,$limit)
{
?>
<script language="JavaScript">
	function frm_sub(page)
	{
	
		document.<?=$frmName?>.action="";
		document.<?=$frmName?>.page1.value = page;
		<?php if(isset($_REQUEST['Keyword'])&&isset($_REQUEST['categoryId'])){?>
		document.<?=$frmName?>.Keyword.value = '<?php echo $_REQUEST['Keyword'];?>';
		document.<?=$frmName?>.categoryId.value = '<?php echo $_REQUEST['categoryId'];?>';
		<?php }?>
		document.<?=$frmName?>.submit();
	}
</script>
<?php
	$adjacents = 3;
	//$limit = 5;
	$lastpage = ceil($total_record/$limit);
	$prev = $page - 1;
	$next = $page + 1;
	$lpm1 = $lastpage - 1;
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"javascript:frm_sub($prev)\" class=footer>&laquo; previous&nbsp;&nbsp;&nbsp;&nbsp;</a>";
		else
			$pagination.= "<span class=\"disabled\" class=footer>&laquo; previous&nbsp;&nbsp;&nbsp;&nbsp;</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\" class=footer>$counter&nbsp;&nbsp;&nbsp;&nbsp;</span>";
				else
					$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter&nbsp;&nbsp;&nbsp;&nbsp;</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\" class=footer>$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
				$pagination.= "<span class=\"whitetext\">...</span>";
				$pagination.= "<a href=\"javascript:frm_sub($lpm1)\" class=footer>$lpm1</a>";
				$pagination.= "<a href=\"javascript:frm_sub($lastpage)\" class=footer>$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"javascript:frm_sub(1)\" class=footer>1&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				$pagination.= "<a href=\"javascript:frm_sub(2)\" class=footer>2&nbsp;&nbsp;&nbsp;&nbsp;</a>";
				$pagination.= "<span class=\"whitetext\">...</span>";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
				$pagination.= "<span class=\"whitetext\">...</span>";
				$pagination.= "<a href=\"javascript:frm_sub($lpm1)\" class=footer>$lpm1</a>";
				$pagination.= "<a href=\"javascript:frm_sub($lastpage)\" class=footer>$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"javascript:frm_sub(1)\" class=footer>1</a>";
				$pagination.= "<a href=\"javascript:frm_sub(2)\" class=footer>2</a>";
				$pagination.= "<span class=\"whitetext\">...</span>";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"javascript:frm_sub($counter)\" class=footer>$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"javascript:frm_sub($next)\" class=footer>next &raquo;</a>";
		else
			$pagination.= "<span class=\"disabled\">next &raquo;</span>";
		$pagination.= "</div>\n";		
	}
	return $pagination;
}
////////////////////////////////////////////////// Pagination with Search - Ends //////////////////////////////////



//************************************************FOR FETCH CATEGORY BEGIN *********************************//

function fetchCategory()
{
	$fetch_category=mysql_query(" SELECT * FROM ".CATEGORY." ORDER BY catname ASC ");
	return $fetch_category;
}

//************************************************FOR FETCH CATEGORY END************************************//


//************************************************INSERT CATEGORY BEGIN************************************//

function insertCategory()
{
	$catname=$_REQUEST['catname'];
	if(isset($catname))
	{
		$category_no=mysql_num_rows(mysql_query(" SELECT * FROM ".CATEGORY." WHERE catname='".$catname."'"));
		if($category_no>0)
		{
			$GLOBALS['cat_sucesss']="This category has been already exists.";
		}
		else
		{
			$value="
				catname	=	'".$catname."'
			,	owner	=	'".$_SESSION['username']."'
			";
			if(Insert_Qry(CATEGORY,$value))
			{
				$GLOBALS['cat_sucesss']="Category has been added successfully.";	
			}
			else
			{
				$GLOBALS['cat_sucesss']="Sorry there some inserting error please try again";
			}
		}
	}
	else
	{
		$GLOBALS['cat_sucesss']="Please input the value.";
	}
}

//************************************************INSERT CATEGORY END************************************//

//************************************************INSERT CATEGORY END************************************//

function fetchItemFormat()
{
	$fetch_item_format=mysql_query(" SELECT * FROM ".ITEMFORMAT." ORDER BY format ASC ");
	return $fetch_item_format;
}

//************************************************INSERT CATEGORY END************************************//

//************************************************INSERT ITEM END************************************//

function insertItem()
{
	$title=$_REQUEST['title'];
	$author=$_REQUEST['author'];
	$category=$_REQUEST['category'];
	$format=$_REQUEST['format'];
	$description=$_REQUEST['description'];
	//$quantity=$_REQUEST['qty'];
	
	if($title=="" || $author=="" || $category=="" || $format=="" || $description=="" || $_FILES['file']['name']=="")
	{
		$GLOBALS['item_insert']="Some fields are missing. Please check.";
	}
	else
	{
		/*$category_no=mysql_num_rows(mysql_query(" SELECT * FROM ".CATEGORY." WHERE catname='".$catname."'"));
		if($category_no>0)
		{
			$GLOBALS['cat_sucesss']="This category has been already exists.";
		}
		else
		{*/
		$up_file1=$_REQUEST['file'];
			
			if($_FILES['file']['name']!=""){
				$wdir="pics/";
				@unlink($wdir."small_");
				@unlink($wdir."thumb_");
				@unlink($wdir."large_");
				$file_type = $_FILES['file']['type'];
				$file_name = $_FILES['file']['name'];
				$file_size = $_FILES['file']['size'];
				$file_tmp = $_FILES['file']['tmp_name'];
				$ext=strchr($_FILES['file']['name'],".");
				$up_file1=rand()."_".date("m_d_Y").$ext;
				
			image_resize($wdir."small_",126,$file_type,$file_name,$file_size,$file_tmp,$up_file1);
			#CroptoSmall($wdir."small_".$imagname,$wdir."small_".$imagname,'0','0',90,70);
				
			image_resize($wdir."thumb_",258,$file_type,$file_name,$file_size,$file_tmp,$up_file1);				            				   #CroptoSmall($wdir."thumb_".$imagname,$wdir."thumb_".$imagname,'0','0',160,120);
				
			image_resize($wdir."large_",400,$file_type,$file_name,$file_size,$file_tmp,$up_file1);
			#CroptoSmall($wdir."large_".$imagname,$wdir."large_".$imagname,'0','0',207,160);
				//$insert_faq_sql.=",model_image1='".$imagname."'";
				if($_FILES['file']['name']=='')
				$up_file1='';
				
			$value=" 	 	 	
				author		=	'".mysql_escape_string($author)."'
			,	title		=	'".mysql_escape_string($title)."'
			,	catid		=	'".$category."'
			,	price		=	''
			,	description	=	'".mysql_escape_string($description)."'
			,	owner		=	'".$_SESSION['username']."'
			,	format		=	'".$format."'
			,	imgName		=	'".$up_file1."'
						
			";
			
			
			
			//************* End *************//
			
			if(Insert_Qry(ITEMS,$value))
			{
			    //Check items from want table
				$iitemid = mysql_insert_id();
				
				$want_produt = mysql_query("select * from want_product where item = '".mysql_escape_string($title)."' and status = 0 order by id asc limit 1")or die(mysql_error());
			
				
				if(mysql_num_rows($want_produt) > 0)
				{
				   $tempId11=rand();
				   $sesionId11=session_id();
				   
				   $update_item_table = mysql_query("update items set status = 'Y' where item_id = '".$iitemid."'")or die(mysql_error());
				   
				   $want_produttt = mysql_query("select * from want_product where item = '".mysql_escape_string($title)."' and status = 0 order by id asc limit 1")or die(mysql_error());
				   $want_produt_result = mysql_fetch_array($want_produttt);
				   
// get user value

$usernamesql = mysql_query("select id,username from admin where id = '{$want_produt_result['user_id']}'")or die(mysql_error());
$usernamesqlresult = mysql_fetch_array($usernamesql);
$usernameforchange = $usernamesqlresult['username'];
$useridforchange = $usernamesqlresult['id'];
// get user value				     

				     $item_order_insert = mysql_query("insert into order_items(userId,item_id,quantity,tempId,sesionId,createDate)values('".$want_produt_result['user_id']."','".$iitemid."',1,'".$tempId11."','".$sesionId11."',NOW())")or die(mysql_error());
					 
					 //ADD MEMBERSHIP AMOUNT INTO ITEM OWNER (1st_aug_2014) 
					 
					 $item_owner_fees=mysql_fetch_array(mysql_query("SELECT * FROM portion_for_item_owner"));
					 
//		 $member_fees=mysql_fetch_array(mysql_query("SELECT * FROM membership_fee WHERE owner='".$_SESSION['username']."' "));
 $member_fees=mysql_fetch_array(mysql_query("SELECT * FROM membership_fee WHERE owner='".$usernameforchange."' "));
				     
					 $rebate_amt=$member_fees['rebate_amount']+($item_owner_fees['dollar_amount']*1);
					 					 			 
	$update_membership_fees = mysql_query("update membership_fee set rebate_amount = '".$rebate_amt."' where owner='".$usernameforchange."'")or die(mysql_error());
	// update plan
	$update_plan = mysql_query("update admin set plan = (plan+1) where id='".$useridforchange."'")or die(mysql_error());
				   
				     $update_want_item_table = mysql_query("update want_items set status = 1 where item_id = '".$want_produt_result['id']."'")or die(mysql_error());
				   
				     $update_want_product_table = mysql_query("update want_product set status = 1 where id = '".$want_produt_result['id']."'")or die(mysql_error());
					 				    
				   	 
				}
				$GLOBALS['item_insert']="Item inserted successfully.";
			}
								
		  }
		  
  	}
 // }
}

//************************************************INSERT ITEM END************************************//


//************************************************EDIT USER END************************************//

function showUserDetails()
{
	$fetch_user_details=mysql_fetch_array(mysql_query(" SELECT * FROM ".ADMIN." WHERE id='".$_SESSION['userId']."' "));
	return $fetch_user_details;
}



function editUser()
{

$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$password_confirm=$_REQUEST['password_confirm'];
$email=$_REQUEST['email'];
$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$address_1=$_REQUEST['address_1'];
$address_2=$_REQUEST['address_2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$zip_code=$_REQUEST['zip_code'];
$country=$_REQUEST['country'];
$plan=$_REQUEST['plan'];
$phone=$_REQUEST['phone'];
$card_name=$_REQUEST['card_name'];
$card_type=$_REQUEST['card_type'];
$card_number=$_REQUEST['card_number'];
$date=explode("/",$_REQUEST['card_exp_date']);
	$m=$date[0];
	$d=$date[1];
	$y=$date[2];
	$card_exp_date=$y."-".$m."-".$d;


$card_sec=$_REQUEST['card_sec'];
$acct_name=$_REQUEST['acct_name'];
$bank_name=$_REQUEST['bank_name'];
$aba_number=$_REQUEST['aba_number'];
$acct_num=$_REQUEST['acct_num'];
$bank_city=$_REQUEST['bank_city'];
$bank_state=$_REQUEST['bank_state'];
$paypal_name=$_REQUEST['paypal_name'];
$gender=$_REQUEST['gender'];

$date1=explode("/",$_REQUEST['dob']);
	$m1=$date[0];
	$d1=$date[1];
	$y1=$date[2];
	$dob=$y1."-".$m1."-".$d1;

	if($username=='' || $password=='' || $email=='' || $firstname=='' || $lastname=='' || $address_1=='' || $city=='' || $state=='' || $zip_code=='' || $country=='' || $plan=='' || $card_name=='' || $card_type=='' || $card_number=='' || $card_exp_date=='' || $card_sec=='' || $gender=='' || $dob=='' )
	{	
		
		header('Location:home.php?page=edit_account&msg');
		//exit;
	}
	else
	{
	$set_value="
	username		=	'".$username."'
	,password		=	'".$password."'
	,god			=	''
	,first_name		=	'".$firstname."'
	,last_name		=	'".$lastname."'
	,address_1		=	'".$address_1."'
	,address_2		=	'".$address_2."'
	,city			=	'".$city."'
	,state			=	'".$state."'
	,zip_code		=	'".$zip_code."'
	,telephone		=	'".$phone."'
	,email			=	'".$email."'
	,gas_pas		=	'".$email."'
	,card_name		=	'".$card_name."'
	,card_type		=	'".$card_type."'
	,card_number	=	'".$card_number."'
	,card_exp_date	=	'".$card_exp_date."'
	,card_sec		=	'".$card_sec."'
	,acct_name		=	'".$acct_name."'
	,bank_name		=	'".$bank_name."'
	,aba_number		=	'".$aba_number."'
	,acct_num		=	'".$acct_num."'
	,bank_city		=	'".$bank_city."'
	,bank_state		=	'".$bank_state."'
	,paypal_name	=	'".$paypal_name."'
	,vehicle_mnfct	=	''
	,vehicle_model	=	''
	,vehicle_year	=	''
	,gender			=	'".$gender."'
	,dob			=	'".$dob."'
	,country		=	'".$country."'
	,plan			=	'".$plan."'
	";
	
	$where_clause=" id='".$_SESSION['userId']."' ";
		
		//echo $value;
		//exit;
		
		if(Update_Qry(ADMIN,$set_value,$where_clause))
		{
			$GLOBALS['msg_success']="Your account successfully updated.";
		}
		else
		{
			$GLOBALS['msg_success']="Sorry there some error please try again.";	
		}
		
	}
}





//************************************************EDIT USER END************************************//


//************************************************USER DETAILS AND ITEM DETAILS************************************//

function fetchUserDetails($userId)
{
	$fetch_user_details=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$userId."'"));
	return $fetch_user_details;
}

function fetchItemsDetails($item_id)
{
	$fetch_item_details=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."' AND status='Y'"));
	return $fetch_item_details;
}

function fetchItemsDetailsAval($item_id)
{
	$fetch_item_details=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."' AND status='N'"));
	return $fetch_item_details;
}

function fetchItemsDetailsRented($item_id)
{
	$fetch_item_details=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."' AND status='Y'"));
	return $fetch_item_details;
}


//************************************************USER DETAILS AND ITEM DETAILS************************************//


//************************************************Category By USER BEGIN************************************//
function fetchCategoryUserCount($userName)
{
   	$fetch_category1=mysql_query("SELECT * FROM ".ITEMS." WHERE owner='".$userName."'");
	$count = mysql_num_rows($fetch_category1);
	return $count;
}

function fetchCategoryUser($userName)
{
	$fetch_category=mysql_query("SELECT DISTINCT(catid) FROM ".ITEMS." WHERE owner='".$userName."'");
	return $fetch_category;
}

//************************************************Category By USER END************************************//


//************************************************ SELECTED Category BEGIN************************************//

function fetchSelectCategory($catid)
{
	$fetch_select_cat=mysql_fetch_array(mysql_query("SELECT * FROM ".CATEGORY." WHERE catid='".$catid."' "));
	return $fetch_select_cat;
}

function fetchItems($catid,$vendor)
{
	$fetch_items=mysql_query("SELECT * FROM ".ITEMS." WHERE catid='".$catid."' AND owner='".$vendor."' AND status='N' ");
	return $fetch_items;
}

function fetchItemCategoryUser($userName)
{
	$fetch_item_category=mysql_query("SELECT * FROM ".ITEMS." i JOIN ".CATEGORY." c ON i.catid=c.catid  WHERE i.owner='".$userName."'");
	
	return $fetch_item_category;
}
	
//************************************************ SELECTED Category END************************************//


//************************************************ FOR TEPORARY CART BEGIN ************************************//

function tempCart($item_id)
{
		$tempId=rand();
		$sesionId=session_id();
		
	$fetch_temp_item=mysql_fetch_array(mysql_query("SELECT COUNT(*) AS COUNTID FROM ".ORDERITEMS." WHERE sesionId='".$sesionId."' AND item_id='".$item_id."' AND status='N'"));
	
	if($fetch_temp_item['COUNTID']>0)
	{
		$GLOBALS['msg_cart']="This item exists in your cart.";
		
	}
	else
	{
		$fetch_item_price=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."'"));		
		
		$value="
		 item_id 	=	'".$item_id."'
		 ,userId	=	'".$_SESSION['userId']."'
		,item_price =	'".$fetch_item_price['price']."'
		,quantity 	=	'1'
		,tempId		=	'".$tempId."'
		,sesionId	=	'".$sesionId."'
		";
		
		if(Insert_Qry(ORDERITEMS,$value))
		{
			$item_fetch=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE status='N'");
			while($itemUpdate=mysql_fetch_array($item_fetch))
			{
				mysql_query("UPDATE ".ITEMS." SET status='Y' WHERE item_id='".$itemUpdate['item_id']."' ");
			}
		
		}
	}
}

function tempCartQnty()
{
	$items=mysql_fetch_array(mysql_query("SELECT SUM(quantity) AS QUANTITY FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND userId='0' AND status='N' "));
	return $items['QUANTITY'];
}

//after login
function tempCartQntyLog()
{
	$items=mysql_fetch_array(mysql_query("SELECT SUM(quantity) AS QUANTITY FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND userId='".$_SESSION['userId']."' AND status='N' "));
	return $items['QUANTITY'];
}
//after login
//************************************************ FOR TEPORARY CART END************************************//


//************************************************ FOR TEPORARY CART BEGIN************************************//

function fetchTempItem()
{
	$fetch_temp_cart=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND userId='0' AND status='N' ");
	return $fetch_temp_cart;
}

//after login
function fetchTempItemLog()
{
			$set_value="userId='".$_SESSION['userId']."' ";
			$where_clause=" sesionId='".session_id()."' AND userId='0' ";
			
			if(Update_Qry(ORDERITEMS,$set_value,$where_clause))
			{
				/*$fetch_temp_cart=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND userId='".$_SESSION['userId']."' AND status='N' ");
				return $fetch_temp_cart;*/
			}
			
}
//for view shopping cart
function fetchTempItemLogView()
{	
	$fetch_temp_cart=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND userId='".$_SESSION['userId']."' AND status='N' ");
	return $fetch_temp_cart;
}
//after login

//************************************************ FOR TEPORARY CART END************************************//

//************************************************ FOR TEPORARY CART END************************************//
function userData($userId)
{
	$fetch_user=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$userId."'"));
	return $fetch_user;
}
//************************************************ FOR TEPORARY CART END************************************//


//************************************************ FOR TEPORARY CART END************************************//


function userCart()
{
 $amt=mysql_fetch_array(mysql_query("SELECT SUM(item_price) AS AMOUNT FROM ".ORDERITEMS." WHERE sesionId='".session_id()."'")); 
 	 	 	 	 	 	
$value="
		
		 customerid		=	'".$_SESSION['userId']."'
		,amount		 	=	'".$amt['AMOUNT']."'
		,date 			=	'".date('Y-m-d H:j:s')."'
		,order_status	=	'PARTIAL'
		,ship_name		=	'".$_REQUEST['name']."'
		,ship_address	=	'".$_REQUEST['address']."'
		,ship_city		=	'".$_REQUEST['city']."'
		,ship_state		=	'".$_REQUEST['state']."'
		,ship_zip		=	'".$_REQUEST['zip']."'
		,ship_country	=	'".$_REQUEST['country']."'
		
		";
		
		if(Insert_Qry(ODERS,$value))
		{
			$set_value=" status='Y' ";
			$where_clause=" sesionId='".session_id()."'";
			
			if(Update_Qry(ORDERITEMS,$set_value,$where_clause))
			{
			
			$item_owner_fee=mysql_fetch_array(mysql_query("SELECT * FROM ".PORTIONFORITEMOWNER." "));
			
			$fetch_itemId=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE sesionId='".session_id()."' AND status='Y'");
			while($itemId=mysql_fetch_array($fetch_itemId))
			{
				$owner=fetchItemsPrice($itemId['item_id']);				
				$member_fee=mysql_fetch_array(mysql_query("SELECT * FROM ".MEMBERSHIPFEE." WHERE owner='".$owner['owner']."' "));
				$rebate_amt=$member_fee['rebate_amount']+($item_owner_fee['dollar_amount']*$itemId['quantity']);				
				 $set_value="rebate_amount='".$rebate_amt."'";
				 $where_clause="owner='".$owner['owner']."' ";
			
				if(Update_Qry(MEMBERSHIPFEE,$set_value,$where_clause))
				{
					/*$item_fetch=mysql_query("SELECT * FROM ".ORDERITEMS." WHERE status='Y'");
					while($itemUpdate=mysql_fetch_array($item_fetch))
					{	
						$member_fee=mysql_fetch_array(mysql_query("UPDATE ".ITEMS." SET status='Y' WHERE item_id='".$itemUpdate['item_id']."' "));
					}*/
					
					
				}
			}
			header('Location:home.php?page=sucess');
			}
		
		}

	}

//************************************************ FOR TEPORARY CART END************************************//

// for items
function fetchItemsPrice($item_id)
{
	$fetch_items_price=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."'"));
	return $fetch_items_price;
}

//Monthly Plan Charge
function planCharge($planID)
{
	$fetData = mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$planID."'"));
	return $fetData;
}
//rebate Point

function rebateAmt($username)
{
	$sql = "select rebate_amount,membership_fee from membership_fee where owner = '".$username."'";
	$rs = mysql_query($sql)or die("Could not select the amount");
	while($row = mysql_fetch_array($rs))
	{
		$rebate_amount = $row["rebate_amount"];
		$membership_fee = $row["membership_fee"];
	}
	$net_pay = $rebate_amount;
	return $net_pay;
}
//update userInfo()
 function userInfo($userId)
 {
	 if($_REQUEST['new_passwd']!='')
	 {
	 $set_value="
	password		=	'".$_REQUEST['new_passwd']."'
	,first_name		=	'".$_REQUEST['first_name']."'
	,last_name			=	'".$_REQUEST['last_name']."'
	,address_1		=	'".$_REQUEST['address_1']."'
	,address_2		=	'".$_REQUEST['address_2']."'
	,city		=	'".$_REQUEST['city']."'
	,zip_code		=	'".$_REQUEST['zip_code']."'
	,state			=	'".$_REQUEST['state']."'
	,telephone			=	'".$_REQUEST['telephone']."'
	,email			=	'".$_REQUEST['email']."'
	";
	 }
	 else
	 {
		$set_value="
		first_name		=	'".$_REQUEST['first_name']."'
		,last_name			=	'".$_REQUEST['last_name']."'
		,address_1		=	'".$_REQUEST['address_1']."'
		,address_2		=	'".$_REQUEST['address_2']."'
		,city		=	'".$_REQUEST['city']."'
		,zip_code		=	'".$_REQUEST['zip_code']."'
		,state			=	'".$_REQUEST['state']."'
		,telephone			=	'".$_REQUEST['telephone']."'
		,email			=	'".$_REQUEST['email']."'
		"; 
	 }
	
	$where_clause=" id='".$_SESSION['userId']."' ";
		
		//echo $value;
		//exit;
		
		if(Update_Qry(ADMIN,$set_value,$where_clause))
		{
			header("Location:home.php?page=myaccount");
		}
		else
		{
			$GLOBALS['msg_success']="Sorry there some error please try again.";	
		}
 }
//update plan
function updatePlan($userId)
{
	$set_value="
	plan		=	'".$_REQUEST['plan']."'
	";
	$where_clause=" id='".$_SESSION['userId']."' ";
	if(Update_Qry(ADMIN,$set_value,$where_clause))
		{
		$userId=$_SESSION['userId'];
			$fetch_user=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$userId."' "));
			$userName=$fetch_user['username'];
			$plan=$fetch_user['plan'];
				
			$fetch_plan_fee=mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$plan."' "));
			$planFee=$fetch_plan_fee['monthly_fee'];
			
			$set_value="membership_fee='".$planFee."'";
			$where_clause="owner='".$userName."' ";
			
			if(Update_Qry(MEMBERSHIPFEE,$set_value,$where_clause))
			{
				header("Location:home.php?page=myaccount");
			}
			else
			{
				$GLOBALS['msg_success']="Sorry there some error please try again.";
			}
			
		}
}
//payout function

function payoutList()
{
	$sqlData = mysql_query("SELECT ".PAYOUTS.".*,SUM(credit)-SUM(debit) AS bal, SUM(credit) as cr, SUM(debit) as deb FROM ".PAYOUTS." GROUP BY owner_id");
	return $sqlData;
}
//payout function for single Data

function payoutData($owner)
{
	$sqlData = mysql_query("Select * from ".PAYOUTS." where owner_id='".$owner."'");
	return $sqlData;
}
//dollar value for payout
function dollarAmount()
{
	$sqlData = mysql_fetch_array(mysql_query("Select * from portion_for_item_owner limit 1"));
	$dollar_amount= $sqlData["dollar_amount"];
	return $dollar_amount;
}

// item quantity for the selected user for current month
function fetchQntyMonth()
{
 $fetch_qntity=mysql_fetch_array(mysql_query("SELECT SUM(quantity) AS QUANTITY FROM ".ORDERITEMS." WHERE userId='".$_SESSION['userId']."' AND MONTH( CURDATE( ) ) = MONTH( createDate ) AND status='Y'"));
 return $fetch_qntity;
}
// item quantity for the selected user for current month

//********************   add penalty ampunt begin  ***************************//

function addPenaltyAmt()
{

			// how many items rented by a user in a month
			$rented_item_quantity=fetchQntyMonth();
			// how many items insert by a user in a month
			$userItemQuantity=countItemsUser();
		
			$user_plan=fetchUserDetails($_SESSION['userId']);
			$fetch_plan=mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$rented_item_quantity['QUANTITY']."'"));
			
			//echo "<br/>User Plan";
			$userPlanItem=$user_plan['plan'];
			//echo "<br/>User Rented Items";
			$userRentItems=$rented_item_quantity['QUANTITY'];
			//echo "<br/>User Insert Items";
			$userInsertItems=$userItemQuantity['QNTY'];
			//echo "<br/>User Rest Items";
			$restUserItems=($userRentItems+$userInsertItems)-$userPlanItem;
			
			if($restUserItems>=$userPlanItem)
			{	
				//echo "<br/>User total items for a month";
				$totalItemMonth=$restUserItems+$userPlanItem;
				//echo "<br/>User Monthly Fees";
				if($fetch_plan['monthly_fee']>0)
				{
					$newMemberShipAmt=($fetch_plan['monthly_fee']/$fetch_plan['items_per_month'])*$totalItemMonth;
					mysql_query("UPDATE ".MEMBERSHIPFEE." SET membership_fee='".$newMemberShipAmt."' WHERE owner='".$_SESSION['username']."' ");
					
				}	
				/*$set_value="membership_fee='".$newMemberShipAmt."'";
				$where_clause=" owner='".$_SESSION['username']."' ";
				
				Update_Qry(MEMBERSHIPFEE,$set_value,$where_clause);*/
				
			}
}
// for showing result of monthly fee
function showingFees()
{
	// how many items rented by a user in a month
			$rented_item_quantity=fetchQntyMonth();
			// how many items insert by a user in a month
			$userItemQuantity=countItemsUser();
		
			$user_plan=fetchUserDetails($_SESSION['userId']);
			$fetch_plan=mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$user_plan['plan']."'"));
			
			//echo "<br/>User Plan";
			$userPlanItem=$user_plan['plan'];
			//echo "<br/>User Rented Items";
			echo "In this month<br/> Rented Items: ".$userRentItems=number_format($rented_item_quantity['QUANTITY']);
			//echo "<br/>User Add Items";
			echo "<br/> Add Items: ".$userInsertItems=$userItemQuantity['QNTY'];
			//echo "<br/>User Rest Items";
			$restUserItems=($userRentItems+$userInsertItems)-$userPlanItem;
			
				//echo "<br/>User total items for a month";
				echo "<br/> Total items for a month: ".$totalItemMonth=$restUserItems+$userPlanItem;
				
				//echo "<br/>User Monthly Fees";
				$newMemberShipAmt=($fetch_plan['monthly_fee']/$fetch_plan['items_per_month'])*$totalItemMonth;
				if($newMemberShipAmt>0)
				{
					echo "<br/> Monthly Fees: ".$newMemberShipAmt;
				}
				else
				{
					echo "<br/> Monthly Fees: ".$fetch_plan['monthly_fee'];
				}
			
}

//
//********************   add penalty ampunt  end ***************************//

// fetch not rented items
function fetchItem($item_id)
{
	$fetch_item=mysql_fetch_array(mysql_query("SELECT * FROM ".ITEMS." WHERE item_id='".$item_id."' AND status='N'"));
	return $fetch_item;
}
// fetch not rented items


//****************** EDIT ITEMS BEGIN **********************/
function editItem()
{
	$item_id=$_REQUEST['item_id'];
	$title=$_REQUEST['title'];
	$author=$_REQUEST['author'];
	$category=$_REQUEST['category'];
	$format=$_REQUEST['format'];
	$description=$_REQUEST['description'];
    //$qty = 	$_REQUEST['qty'];
	if($title=="" || $author=="" || $category=="" || $format=="" || $description=="" || $qty == "")
	{
		$GLOBALS['item_insert']="Please input the value.";
	}
	else
	{
		if($_FILES['file']['name']!="")
		{
		$up_file1=$_REQUEST['file'];
			
			if($_FILES['file']['name']!=""){
				$wdir="pics/";
				@unlink($wdir."small_");
				@unlink($wdir."thumb_");
				@unlink($wdir."large_");
				$file_type = $_FILES['file']['type'];
				$file_name = $_FILES['file']['name'];
				$file_size = $_FILES['file']['size'];
				$file_tmp = $_FILES['file']['tmp_name'];
				$ext=strchr($_FILES['file']['name'],".");
				$up_file1=rand()."_".date("m_d_Y").$ext;
				
			image_resize($wdir."small_",126,$file_type,$file_name,$file_size,$file_tmp,$up_file1);
			#CroptoSmall($wdir."small_".$imagname,$wdir."small_".$imagname,'0','0',90,70);
				
			image_resize($wdir."thumb_",258,$file_type,$file_name,$file_size,$file_tmp,$up_file1);				            				   #CroptoSmall($wdir."thumb_".$imagname,$wdir."thumb_".$imagname,'0','0',160,120);
				
			image_resize($wdir."large_",400,$file_type,$file_name,$file_size,$file_tmp,$up_file1);
			#CroptoSmall($wdir."large_".$imagname,$wdir."large_".$imagname,'0','0',207,160);
				//$insert_faq_sql.=",model_image1='".$imagname."'";
				
				$set_value=" 	 	 	
					author		=	'".$author."'
				,	title		=	'".$title."'
				,	catid		=	'".$category."'
				,	description	=	'".$description."'
				,	format		=	'".$format."'
				,	imgName		=	'".$up_file1."'								,	stock		=	'".$qty."'
				";
				
				$where_clause=" item_id='".$item_id."' ";
			
				if(Update_Qry(ITEMS,$set_value,$where_clause))
				{
					$GLOBALS['item_update']="Item updated successfully.";
				}
				else
				{
					$GLOBALS['item_update']="Fail to item update please try again.";
				}
				}
			}
			
			
			else
			{
			$set_value=" 	 	 	
				author		=	'".$author."'
			,	title		=	'".$title."'
			,	catid		=	'".$category."'
			,	description	=	'".$description."'
			,	format		=	'".$format."'	
			";
			
			$where_clause=" item_id='".$item_id."' ";
			
			if(Update_Qry(ITEMS,$set_value,$where_clause))
			{
				$GLOBALS['item_update']="Item updated successfully.";
			}
			else
			{
				$GLOBALS['item_update']="Fail to item update please try again.";
			}
			}
								
		  }
		  
  	}
 
//********************** EDIT ITEMS END *************************//


//**********************  SHOWING ITEMS BEGIN ************************

function showNoRentedItems()
{
	$fetch_item_details=mysql_query("SELECT * FROM ".ITEMS." WHERE status='N' AND imgName<>'' ORDER BY item_id DESC ");
	return $fetch_item_details;
}

//**********************  SHOWING ITEMS END *************************//

//**********************  DELETE ITEMS BEGIN *************************//

function deleteItem($item_id)
{
	$del_item_details=mysql_query("DELETE FROM ".ITEMS." WHERE item_id='".$item_id."' AND owner='".$_SESSION['username']."'");
	if($del_item_details>0)
	{
		header('Location:home.php?page=edit_item&msg_del='.$item_id.'');
	}
}

//**********************  DELETE ITEMS END *************************//


//**********************  COUNT ITEMS END *************************//

function countItemsUser()
{
 $count_items=mysql_fetch_array(mysql_query("SELECT COUNT(*) AS QNTY FROM ".ITEMS." WHERE owner='".$_SESSION['username']."' AND MONTH( CURDATE( ) ) = MONTH( createItemDate )"));
 return $count_items;
}

//**********************  COUNT ITEMS END *************************//

//*********************  USER NEW MEMBERSHIP FEES  ***************//
function newMemberShipPlan()
{
	$ftech_new_membership=mysql_fetch_array(mysql_query("SELECT * FROM ".MEMBERSHIPFEE." WHERE owner='".$_SESSION['username']."'"));
	return $ftech_new_membership['membership_fee'];
}
//********************   USER NEW MEMBERSHIP FEES  ***************//

//********************   AMOUNT PER ITEM  ***************//

function fetchPlan($items_per_month)
{
	$fetch_plan_amt=mysql_fetch_array(mysql_query("SELECT * FROM ".PLAN." WHERE items_per_month='".$items_per_month."'"));
	return $fetch_plan_amt;
}

//********************   AMOUNT PER ITEM  ***************//
?>