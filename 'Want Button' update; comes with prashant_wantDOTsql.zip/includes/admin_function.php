<?
function formatsaql()
{
$itemsql=mysql_query("SELECT * FROM ".ITEMFORMAT." ORDER BY id ASC "); 
return $itemsql;
}
function insertformat()
{
$value="
	id 			=	''
	,format		=	'".$_REQUEST['format1']."'
	,price		=	'".$_REQUEST['price1']."'
	,max_days			=	'".$_REQUEST['max_days1']."'
	";
	if(Insert_Qry(ITEMFORMAT,$value))
		{
			$GLOBALS['msg_err']="Successfully! data inserted!";	
		}
		else
		{
			$GLOBALS['msg_err']="Sorry there some error please try again.";	
		}
		return $GLOBALS['msg_err'];
  }
 function delete_manage_format()
 {
$sql_delete=mysql_query("DELETE FROM ".ITEMFORMAT." WHERE id='".$_REQUEST['id']."' ");
 if($sql_delete)
 $GLOBALS['msg_err']="Successfully! Item Deleted!";	
 else
  $GLOBALS['msg_err']="Sorry! Item not Deleted!";	
 
 return $GLOBALS['msg_err'];
 
 } 
 function update_manage_format()
 {
   $value=" format='".$_REQUEST['format']."', price='".$_REQUEST['price']."', max_days=	'".$_REQUEST['max_days']."'";

	$where_clause=" id='".$_REQUEST['id']."'";

	if(Update_Qry(ITEMFORMAT,$value,$where_clause))
		{
			$GLOBALS['msg_err']="Successfully! data Updated!";	
		}
		else
		{
			$GLOBALS['msg_err']="Sorry there some error please try again.";	
		}
		return $GLOBALS['msg_err'];
 
 }
 function plansql()
 {
 $itemsql=mysql_query("SELECT * FROM ".PLAN." ORDER BY planID ASC "); 
return $itemsql;
 
 }
 
 function delete_admin_plan()
 {
 $sql_delete=mysql_query("DELETE FROM ".PLAN." WHERE planID='".$_REQUEST['planID']."' ");
 if($sql_delete)
 $GLOBALS['msg_err']="Successfully! Item Deleted!";	
 else
  $GLOBALS['msg_err']="Sorry! Item not Deleted!";	
 
 return $GLOBALS['msg_err'];
 }
 function add_admin_plan()
 {
 $value="
	planID 			=	''
	,items_per_month		=	'".$_REQUEST['items_per_month']."'
	,monthly_fee			=	'".$_REQUEST['monthly_fee']."'
	";
	if(Insert_Qry(PLAN,$value))
		{
			$GLOBALS['msg_errh']="Successfully! data inserted!";	
		}
		else
		{
			$GLOBALS['msg_errh']="Sorry there some error please try again.";	
		}
		return $GLOBALS['msg_errh'];
 }
 function update_admin_plan()
 {
  $value=" items_per_month='".$_REQUEST['items_per_month']."', monthly_fee=	'".$_REQUEST['monthly_fee']."'";

	$where_clause=" planID='".$_REQUEST['id']."'";

	if(Update_Qry(PLAN,$value,$where_clause))
		{
			$GLOBALS['msg_err']="Successfully! data Updated!";	
		}
		else
		{
			$GLOBALS['msg_err']="Sorry there some error please try again.";	
		}
		return $GLOBALS['msg_err'];
 
 }
 function user_list()
 {
  $itemsql=mysql_query("SELECT * FROM ".ADMIN." ORDER BY id DESC "); 
 return $itemsql;

 }
 function createUser()
 {
    $first_name=$_REQUEST['fname'];  
	$last_name=$_REQUEST['lname'];
	$address_1=$_REQUEST['address1'];	
	$address_2=$_REQUEST['address2'];	
	$city=$_REQUEST['city'];	
	$state=$_REQUEST['state'];	
	$zip_code=$_REQUEST['zip_code'];	
	$telephone=$_REQUEST['telephone'];	
	$email=$_REQUEST['email'];	
	$username=$_REQUEST['username'];	
	$password=$_REQUEST['password'];
	
	$fetch_user_login=mysql_num_rows(mysql_query("SELECT * FROM ".ADMIN." WHERE username='".$username."'"));
	if($fetch_user_login==0)
	{
	$value="
	id 			=	''
	,username		=	'".$username."'
	,password		=	'".$password."'
	,first_name		=	'".$first_name."'
	,last_name		=	'".$last_name."'
	,address_1		=	'".$address_1."'
	,address_2		=	'".$address_2."'
    ,city		=	'".$city."'
	,state		=	'".$state."'
	,zip_code		=	'".$zip_code."'
	,telephone		=	'".$telephone."'
	,email			=	'".$email."'
	";
	if(Insert_Qry(ADMIN,$value))
		{
		
		$userId=mysql_insert_id();
				$fetch_user=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$userId."' "));
				$userName=$fetch_user['username'];
								
				$value2="
				membership_fee	=	''
				,rebate_amount	=	''
				,period			=	'1 Month'
				,description	=	''
				,owner			=	'".$userName."'
				,station		=	''
				";
				
				if(Insert_Qry(MEMBERSHIPFEE,$value2))
				{
					$GLOBALS['msg_errh']="Successfully! data inserted!";
				}	
		}
		else
		{
			$GLOBALS['msg_errh']="Sorry there some error please try again.";	
		}
	}
	   else
	   {
	   $GLOBALS['msg_errh']="Sorry Dublicate Username.";	
	   }
		return $GLOBALS['msg_errh'];
 
 }
 function delete_user_item()
 {
 $sql_delete=mysql_query("DELETE FROM ".ADMIN." WHERE id='".$_REQUEST['id']."' ");
 if($sql_delete)
 $GLOBALS['msg_err']="Successfully! Item Deleted!";	
 else
  $GLOBALS['msg_err']="Sorry! Item not Deleted!";	
 
 return $GLOBALS['msg_err'];
 }
 function make_Superuser()
 {
 $value=" god='1'";

	$where_clause=" id='".$_REQUEST['id']."'";

	if(Update_Qry(ADMIN,$value,$where_clause))
		{
			$GLOBALS['msg_err']="Successfully! Change in SuperUser!";	
		}
		else
		{
			$GLOBALS['msg_err']="Sorry there some error please try again.";	
		}
		return $GLOBALS['msg_err'];
 
 }
 function showAllUserDetails($id)
{
	$fetch_user_details=mysql_fetch_array(mysql_query(" SELECT * FROM ".ADMIN." WHERE id='".$id."' "));
	return $fetch_user_details;
}
function AlleditUser()
{

$username=$_REQUEST['username'];
$password=$_REQUEST['password'];
$email=$_REQUEST['email'];
$firstname=$_REQUEST['firstname'];
$lastname=$_REQUEST['lastname'];
$address_1=$_REQUEST['address_1'];
$address_2=$_REQUEST['address_2'];
$city=$_REQUEST['city'];
$state=$_REQUEST['state'];
$zip_code=$_REQUEST['zip_code'];
$country=$_REQUEST['country'];
$plan=$_REQUEST['plan'];
$phone=$_REQUEST['phone'];
$card_name=$_REQUEST['card_name'];
$card_type=$_REQUEST['card_type'];
$card_number=$_REQUEST['card_number'];
$date=explode("/",$_REQUEST['card_exp_date']);
	$m=$date[0];
	$d=$date[1];
	$y=$date[2];
	$card_exp_date=$y."-".$m."-".$d;


$card_sec=$_REQUEST['card_sec'];
$acct_name=$_REQUEST['acct_name'];
$bank_name=$_REQUEST['bank_name'];
$aba_number=$_REQUEST['aba_number'];
$acct_num=$_REQUEST['acct_num'];
$bank_city=$_REQUEST['bank_city'];
$bank_state=$_REQUEST['bank_state'];
$paypal_name=$_REQUEST['paypal_name'];
$gender=$_REQUEST['gender'];

$date1=explode("/",$_REQUEST['dob']);
	$m1=$date[0];
	$d1=$date[1];
	$y1=$date[2];
	$dob=$y1."-".$m1."-".$d1;

	if($username=='' || $password=='' || $email=='' || $firstname=='' || $lastname=='' || $address_1=='' || $city=='' || $state=='' || $zip_code=='' || $country=='' || $plan=='' || $card_name=='' || $card_type=='' || $card_number=='' || $card_exp_date=='' || $card_sec=='' || $gender=='' || $dob=='' )
	{	
		
		header('Location:home.php?page=edit_account&msg');
		//exit;
	}
	else
	{
 	$set_value="
	username		=	'".$username."'
	,password		=	'".$password."'
	,first_name		=	'".$firstname."'
	,last_name		=	'".$lastname."'
	,address_1		=	'".$address_1."'
	,address_2		=	'".$address_2."'
	,city			=	'".$city."'
	,state			=	'".$state."'
	,zip_code		=	'".$zip_code."'
	,telephone		=	'".$phone."'
	,email			=	'".$email."'
	,gas_pas		=	'".$email."'
	,card_name		=	'".$card_name."'
	,card_type		=	'".$card_type."'
	,card_number	=	'".$card_number."'
	,card_exp_date	=	'".$card_exp_date."'
	,card_sec		=	'".$card_sec."'
	,acct_name		=	'".$acct_name."'
	,bank_name		=	'".$bank_name."'
	,aba_number		=	'".$aba_number."'
	,acct_num		=	'".$acct_num."'
	,bank_city		=	'".$bank_city."'
	,bank_state		=	'".$bank_state."'
	,paypal_name	=	'".$paypal_name."'
	,vehicle_mnfct	=	''
	,vehicle_model	=	''
	,vehicle_year	=	''
	,gender			=	'".$gender."'
	,dob			=	'".$dob."'
	,country		=	'".$country."'
	,plan			=	'".$plan."'
	";
	

	$where_clause=" id='".$_REQUEST['userid']."' ";
		
		//echo $value;
		//exit;
		
		if(Update_Qry(ADMIN,$set_value,$where_clause))
		{
			$GLOBALS['msg_success']="Your account uccessfully updated.";
		}
		else
		{
			$GLOBALS['msg_success']="Sorry there some error please try again.";	
		}
	}
}
function saleResult($username)
{
/*$sqlData = mysql_query("SELECT order_items.userId, order_items.item_id, order_items.quantity, orders.date, items.author, items.title, items.catid, items.description, items.owner, items.format, categories.catid, categories.catname, categories.owner, admin.first_name, admin.last_name, admin.address_1, admin.address_2, admin.city, admin.state, admin.zip_code, admin.telephone, admin.email, admin.country,item_format.max_days
FROM order_items
INNER JOIN orders
ON orders.customerid=order_items.userId
INNER JOIN items
ON items.item_id=order_items.item_id
INNER JOIN categories
ON categories.catid=items.catid
INNER JOIN admin
ON order_items.userId=admin.id
INNER JOIN item_format
ON item_format.format=items.format
WHERE items.owner='".$username."'

");*/
 $sqlData=mysql_query("SELECT a.item_id,a.orderid,c.catid,e.catname,c.owner,b.username,b.first_name,b.last_name,b.address_1, b.address_2,b.city,b.state,b.zip_code,b.telephone,b.email, b.country,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  JOIN ".CATEGORY." e WHERE a.userId=b.id AND a.item_id=c.item_id AND c.format=d.format AND e.catid=c.catid AND c.owner='".$username."'  "); 
return $sqlData;
}
function saleitemtrack($username)
{
  $sqlData=mysql_query("SELECT a.item_id,a.orderid,c.catid,e.catname,c.owner,b.username,b.first_name,b.last_name,b.address_1, b.address_2,b.city,b.state,b.zip_code,b.telephone,b.email, b.country,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  JOIN ".CATEGORY." e WHERE a.userId=b.id AND a.item_id=c.item_id AND c.format=d.format AND e.catid=c.catid AND c.owner='".$username."' AND a.track='0'  "); 
 
return $sqlData;

}
function ordersaletrackSubmit()
{
$storeid=$_REQUEST['sel2'];

for($i=0;$i<count($storeid);$i++)
{
 $orderid=$storeid[$i]; 
 $fet_list=mysql_fetch_array(mysql_query("SELECT a.item_id,c.catid,c.owner,b.username,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  WHERE a.orderid='".$orderid."' AND a.userId=b.id AND a.item_id=c.item_id AND c.format=d.format ")); 

//$date_start=date('Y-m-d',strtotime($fet_list['createDate']));
//$date_end=date('Y-m-d',strtotime($fet_list['createDate'].' + '.$fet_list['max_days'].'day'));
	$date_start=date('Y-m-d');
	
	$value="
	id 			=	'' 	
	,order_id		=	'".$orderid."'
	,item_id		=	'".$fet_list['item_id']."'
	,category_id		=	'".$fet_list['catid']."'
	,owner_id		=	'".$fet_list['owner']."'
	,renter_id		=	'".$fet_list['username']."'
	,date_start		=	'".$date_start."'
	,date_end		=	''
    ,tracking_send		=	'".$_REQUEST['trackingno']."'
	,quantity		=	'".$fet_list['quantity']."'
	,author		=	'".$fet_list['author']."'
	,title		=	'".$fet_list['title']."'
	,format			=	'".$fet_list['format']."'
	";
	
	Insert_Qry(ORDERSALE,$value);
	
	$valu=" track='1'";

	$where_clause=" orderid ='".$orderid."'";

	Update_Qry(ORDERITEMS,$valu,$where_clause);
		
		$countQty=$$countQty+$fet_list['quantity'];
	}
	$dollarval=dollarval();
	 	$total= $dollarval*$countQty; 
		$date=date('Y-m-d');	 	
	$val="
	id 			=	'' 	
	,owner_id		=	'".$fet_list['owner']."'
	,balance		=	''
	,credit		=	'".$total."'
	,debit		=	''
    ,transaction_date		=	'".$date."'
	,description			=	'Credits earned todate'
	";
	Insert_Qry(PAYOUTS,$val);
	
	$msg="Data insert successfully";
	return $msg;
}
function checktrucker($oid)
{
$sql=mysql_num_rows(mysql_query("SELECT * FROM ".ORDERSALE." WHERE order_id='".$oid."' AND tracking_return='' "));
return $sql;
}

function truckerno($oid)
{
$sql=mysql_fetch_array(mysql_query("SELECT tracking_send,date_start FROM ".ORDERSALE." WHERE order_id='".$oid."' "));
return $sql;
}
function truckerReturnno($oid)
{
$sql=mysql_fetch_array(mysql_query("SELECT tracking_return,date_end  FROM ".ORDERSALE." WHERE order_id='".$oid."' "));
return $sql;
}
function rentResultgp($userId)
{$sqlData=mysql_query("SELECT a.item_id,a.orderid,c.catid,e.catname,c.owner,b.username,b.first_name,b.last_name,b.address_1, b.address_2,b.city,b.state,b.zip_code,b.telephone,b.email, b.country,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  JOIN ".CATEGORY." e WHERE c.owner=b.username AND a.item_id=c.item_id AND c.format=d.format AND e.catid=c.catid AND a.userId='".$userId."' "); 
// $sqlData=mysql_query("SELECT a.item_id,a.orderid,c.catid,e.catname,c.owner,b.username,b.first_name,b.last_name,b.address_1, b.address_2,b.city,b.state,b.zip_code,b.telephone,b.email, b.country,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  JOIN ".CATEGORY." e WHERE c.owner=b.username AND a.item_id=c.item_id AND c.format=d.format AND e.catid=c.catid AND a.userId='".$userId."' "); 
return $sqlData;
}
function rentItemTrackgp($userId)
{
 $sqlData=mysql_query("SELECT a.item_id,a.orderid,c.catid,e.catname,c.owner,b.username,b.first_name,b.last_name,b.address_1, b.address_2,b.city,b.state,b.zip_code,b.telephone,b.email, b.country,a.quantity,a.createDate,c.author,c.title,c.format,d.max_days FROM ".ORDERITEMS." a JOIN ".ADMIN." b JOIN ".ITEMS." c JOIN ".ITEMFORMAT." d  JOIN ".CATEGORY." e JOIN ".ORDERSALE." f WHERE c.owner=b.username AND a.item_id=c.item_id AND c.format=d.format AND e.catid=c.catid AND a.userId='".$userId."' AND f.order_id=a.orderid AND f.tracking_return=''  "); 
return $sqlData;
}
function submit_track_rent()
{
$storeid=$_REQUEST['sel2'];

for($i=0;$i<count($storeid);$i++)
{
 $orderid=$storeid[$i]; 
 $return_date=date('Y-m-d');
	 $value="date_end='".$return_date."',tracking_return='".$_REQUEST['trackingno']."'";

	$where_clause=" order_id ='".$orderid."'";

	Update_Qry(ORDERSALE,$value,$where_clause);
	
		
	}
	$msg="Data insert successfully";
	return $msg;

}
function trackerhiligt($oid)
{
$sql=mysql_num_rows(mysql_query("SELECT * FROM ".ORDERSALE." WHERE order_id='".$oid."' "));
return $sql;
}
function penalty_submit()
{
 $value=" 	dollar_amount ='".$_REQUEST['portion_for_item_owner']."',bumped_up ='".$_REQUEST['group1']."'";

	$where_clause=" id ='1'";
	
	

	if(Update_Qry("portion_for_item_owner",$value,$where_clause))
		{
		if($_REQUEST['group1']=="penalty")
	{
	 $value="penalty_amount ='".$_REQUEST['penaltyAmount']."'";

	$where_clause=" id ='1'";
	Update_Qry("portion_for_item_owner",$value,$where_clause);
	}
			$GLOBALS['msg_success']="Updated successfully .";
		}
		else
		{
			$GLOBALS['msg_success']="Sorry there some error please try again.";	
		}

return $GLOBALS['msg_success'];
}
function dollarval() { 
$dollar=mysql_fetch_array(mysql_query("SELECT * FROM `portion_for_item_owner` WHERE id='1' "));
return $dollar['dollar_amount'];
} 
function become_user()
{
$_SESSION['pre_userId']=$_SESSION['userId'];
unset($_SESSION['userId']);
$_SESSION['pre_user']=$_SESSION['username'];
unset($_SESSION['username']);
unset($_SESSION['userType']);
$fetch_user_dtl=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$_REQUEST['id']."' "));

	$_SESSION['userId']=$fetch_user_dtl['id'];
	$_SESSION['username']=$fetch_user_dtl['username'];
	$_SESSION['userType']=$fetch_user_dtl['god'];
	$_SESSION['become']="become";
	header('Location:home.php?page=myaccount');

}

?>