<?
/**********************************************************Start for user login**************************/
function login()
{
$username=$_REQUEST['username'];
$password=$_REQUEST['password'];

$fetch_user_pass=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE username='".$username."' OR password='".$password."' "));
if($fetch_user_pass>0)
{

$fetch_userName=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE username='".$username."' "));
if($fetch_userName>0)
{
	
	$fetch_user_login=mysql_num_rows(mysql_query("SELECT * FROM ".ADMIN." WHERE username='".$username."' AND password ='".$password."' "));
	
	$fields="*";
	$where_clause="username='".$username."' AND password ='".$password."'  ";		
	$fetch_user=Select_Qry($fields,ADMIN,$where_clause,$orderby,$type,$startRow, $PageSize);
	
	if($fetch_user_login>0 && !isset($_REQUEST['cart']))
	{
	
	$_SESSION['userId']=$fetch_user['id'];
	$_SESSION['username']=$fetch_user['username'];
	$_SESSION['userType']=$fetch_user['god'];
	header('Location:home.php?page=myaccount');
	
	}
	elseif(isset($_REQUEST['cart']))
	{	
		$_SESSION['userId']=$fetch_user['id'];
		$_SESSION['username']=$fetch_user['username'];
		$_SESSION['userType']=$fetch_user['god'];
		header('Location:home.php?page=checkout');
	}
	else
	{
	$GLOBALS['msg_login']="Pasword is worng please check again.";	
	}
}
else
	{
	$GLOBALS['msg_login']="User Name is worng please check again.";	
	}
}
	

else
{	
$GLOBALS['msg_login']="User name and password is wrong.";
}

}
/**********************************************************End for user login**************************/

?>