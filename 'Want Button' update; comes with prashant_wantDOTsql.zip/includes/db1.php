<?
/***************************************************START FUNCTION FOR FETCH MONTHLY PLAN****************************************************************************/
function monthlyPlanData()
{
	$plan = mysql_query("SELECT * FROM ".PLAN." ORDER BY items_per_month");
	return $plan;
}
/***************************************************START FUNCTION FOR FETCH Rent Result****************************************************************************/
function rentResult($userId)
{
	$sqlData = mysql_query("SELECT order_items.userId, order_items.item_id, order_items.quantity, orders.date, items.author, items.title, items.catid, items.description, items.owner, items.format, categories.catid, categories.catname, categories.owner, admin.first_name, admin.last_name, admin.address_1, admin.address_2, admin.city, admin.state, admin.zip_code, admin.telephone, admin.email, admin.country 
FROM order_items
INNER JOIN orders
ON orders.customerid=order_items.userId
INNER JOIN items
ON items.item_id=order_items.item_id
INNER JOIN categories
ON categories.catid=items.catid
INNER JOIN admin
ON items.owner=admin.username

");
return $sqlData;
}
/***************************************************START FUNCTION FOR FETCH MONTHLY PLAN****************************************************************************/

?>