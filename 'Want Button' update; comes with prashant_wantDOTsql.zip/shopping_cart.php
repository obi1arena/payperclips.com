<?
include("includes/_include.php");
?>
  <? include("includes/frontHeader.php");
 $item_id=$_REQUEST['item_id'];
 $catid=$_REQUEST['catid'];
/* if(isset($item_id))
 {
	$itemTemp=tempCart($item_id);
}*/
// for temp item
if(!empty($_SESSION['userId']))
{
	$temp_cart=fetchTempItemLogView();
}
else
{
	$temp_cart=fetchTempItem();
}

if(isset($_REQUEST['mode3']))
{

 $orderid=$_REQUEST['mode2'];
 $qnty=$_REQUEST['mode1'];
 $price=$_REQUEST['mode4'];
 $total=$qnty*$price;
 $set_value=" quantity='".$qnty."' ,item_price='".$total."' ";
 $where_clause=" orderid='".$orderid."'";
	
	if(Update_Qry(ORDERITEMS,$set_value,$where_clause))
	{
		header('Location:home.php?page=shopping_cart&aut');	
	}
}
$vendor=$_REQUEST['vendor'];
?>
<script type="text/javascript">    
            function update_cart(id)
{

var a= document.getElementById("qnty"+id).value;
var b= document.getElementById("orderid"+id).value;
var c= document.getElementById("price"+id).value;


document.frm_update_cart.mode1.value=a;
document.frm_update_cart.mode2.value=b;
document.frm_update_cart.mode4.value=c;


document.frm_update_cart.mode3.value="insert";
document.frm_update_cart.submit();
/*document.inputUpdate.id.value=d;
document.inputUpdate.format.value=a;
document.inputUpdate.price.value=b;
document.inputUpdate.max_days.value=c;
document.inputUpdate.submit();*/

}
           
         
		 
           </script>
<h2>Your shopping cart</h2>
<table border = 0 width = 100% cellspacing = 0>
        <form method="post" action="" name="frm_update">
        <tr>
          <th colspan = 4><? if(isset($GLOBALS['msg_cart'])) { echo $GLOBALS['msg_cart']; }
		  if(isset($_REQUEST['aut']))
		  {
		  	echo "Successfully updated.";
		  }
		  ?></th>
          </tr>
        <tr><th colspan = 2 align="left" bgcolor="#cccccc">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Item</th>
       <th bgcolor="#cccccc">Quantity</th>
        <th bgcolor="#cccccc"></th>
        </tr>
        
        <? while($cart=mysql_fetch_array($temp_cart)) {
		
		$itemsDetails=fetchItemsDetails($cart['item_id']);
		$itemPrice=fetchItemsPrice($cart['item_id']);
		
		?>
        <tr><td align = left>&nbsp;</td><td align = left>
        <a href = "home.php?page=show_item&item_id=<?=$cart['item_id']?>&type=rented"><?=$itemsDetails['title']?></a> by <?=$itemsDetails['owner']?>
        
        </td><td align = center><input type="text" name="qnty" id="qnty<?=$cart['orderid']?>" value="<?=$cart['quantity']?>" size="3" required></td><td align = center>
       <input type="hidden" name="price" id="price<?=$cart['orderid']?>" value="<?=$itemPrice['price'];?>">
       

       <input type="hidden" name="orderid" id="orderid<?=$cart['orderid']?>" value="<?=$cart['orderid']?>">
       
        <input type="button" onClick="update_cart(<?=$cart['orderid']?>);" name="update_order" value="UPDATE" class="button2">
        
        </td></tr>
        <? }?>
        
        <tr>
          <th colspan = 2 bgcolor="#cccccc">&nbsp;</td>
          <th align = center bgcolor="#cccccc">  
              <? 
			  if(!empty($_SESSION['username']))
			  {
			  	echo tempCartQntyLog();
			  }
			  else
			  {
			  	echo tempCartQnty();          
         	  } 
			  ?></th>
          <th align = center bgcolor="#cccccc">              </th>
        </tr><tr>
            <td colspan = 3>&nbsp;</td>
            <td align = center>
                        </td>
            <td>&nbsp;</td>
        </tr></form></table>
<center><a href="home.php?page=vendor&catid=<?=$catid;?>&vendor=<?=$vendor;?>" class="button2"><img src="images/continue-shopping.gif"
           alt="Continue Shopping" border=0 height = 50 width = 135></a></center><center><br /><br />
           <?
		if(empty($_SESSION['userId']))
		{?>
			<a href="home.php?page=login&cart" class="button2"><img src="images/go-to-checkout.gif" alt="Go To Checkout" border=0 height = 50 width = 135></a>
		<? }
		else
		{
		?>
           <a href="home.php?page=checkout" class="button2"><img src="images/go-to-checkout.gif" alt="Go To Checkout" border=0 height = 50 width = 135></a>
        <? }?>
           </center>
           
         <form name="frm_update_cart" action="" method="post" >
         <input type="hidden" name="mode1"  value="">
       		<input type="hidden" name="mode2"  value="">
            <input type="hidden" name="mode4"  value="">
            <input type="hidden" name="mode3"  value="">
         </form>