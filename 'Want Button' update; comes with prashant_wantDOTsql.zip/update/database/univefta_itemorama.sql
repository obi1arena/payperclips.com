-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 26, 2013 at 03:39 PM
-- Server version: 5.1.59-rel13.0-log
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `univefta_itemorama`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(16) NOT NULL DEFAULT '',
  `password` varchar(16) NOT NULL DEFAULT '',
  `god` tinyint(4) NOT NULL DEFAULT '0',
  `first_name` varchar(32) NOT NULL DEFAULT '',
  `last_name` varchar(32) NOT NULL DEFAULT '',
  `address_1` varchar(64) NOT NULL DEFAULT '',
  `address_2` varchar(64) NOT NULL DEFAULT '',
  `city` varchar(32) NOT NULL DEFAULT '',
  `state` varchar(32) NOT NULL DEFAULT '',
  `zip_code` varchar(16) NOT NULL DEFAULT '',
  `telephone` varchar(32) NOT NULL DEFAULT '',
  `email` varchar(64) NOT NULL DEFAULT '',
  `gas_pas` varchar(30) NOT NULL DEFAULT '0',
  `card_name` varchar(60) NOT NULL DEFAULT '',
  `card_type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `card_number` varchar(16) NOT NULL DEFAULT '0',
  `card_exp_date` date NOT NULL DEFAULT '0000-00-00',
  `card_sec` varchar(4) NOT NULL DEFAULT '0',
  `acct_name` varchar(60) NOT NULL DEFAULT '',
  `bank_name` varchar(60) NOT NULL DEFAULT '',
  `aba_number` varchar(9) NOT NULL DEFAULT '0',
  `acct_num` varchar(13) NOT NULL DEFAULT '0',
  `bank_city` varchar(60) NOT NULL DEFAULT '',
  `bank_state` char(2) NOT NULL DEFAULT '',
  `paypal_name` varchar(60) NOT NULL DEFAULT '',
  `vehicle_mnfct` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `vehicle_model` varchar(60) NOT NULL DEFAULT '',
  `vehicle_year` date NOT NULL DEFAULT '0000-00-00',
  `gender` enum('m','f') NOT NULL DEFAULT 'm',
  `dob` date NOT NULL DEFAULT '0000-00-00',
  `country` varchar(100) NOT NULL DEFAULT '',
  `plan` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=83 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `god`, `first_name`, `last_name`, `address_1`, `address_2`, `city`, `state`, `zip_code`, `telephone`, `email`, `gas_pas`, `card_name`, `card_type`, `card_number`, `card_exp_date`, `card_sec`, `acct_name`, `bank_name`, `aba_number`, `acct_num`, `bank_city`, `bank_state`, `paypal_name`, `vehicle_mnfct`, `vehicle_model`, `vehicle_year`, `gender`, `dob`, `country`, `plan`) VALUES
(1, 'srishti', 'srishti', 0, 'Srishti', 'Infotech', 'Vallabh Nagar', 'Pimpri', 'Pune', '5', '123456', '1234567890', 'srishtiinfotech@gmail.com', '0', 'Srishti', 0, '123', '2008-12-26', '0', '', '', '0', '0', '', '', '', 0, '', '2008-12-31', 'm', '2000-12-21', 'India', 4),
(2, 'proflexive', 'proflexive1', 1, 'Proflexive', 'International', '666 Elm Street', '', 'Chicago', 'IL', '60606', '', 'proflexive@proflexive.com', '0', 'Proflexive', 1, '6666666666666666', '2006-06-01', '0', '', '', '0', '0', '', '', '', 8, '530i', '1994-01-01', 'm', '1971-01-01', 'USA', 4),
(3, 'rlembong', 'ggc2006j', 1, 'Ray', 'Me', '10411 York', '', 'Minneapolis', 'MN', '55431', '', 'raylembong@yahoo.com', '', 'rlembong', 1, '', '2007-10-01', '', '', '', '', '', '', '', '', 8, '530i', '1994-01-01', 'm', '1970-02-01', 'USA', 2),
(4, 'nongasbiz', 'nongasbiz1', 0, 'Non-gasoline', 'Business', '10411 York Lane', '', 'Bloomington', 'MN', '55431', '', 'proflexive@gmail.com', '', 'Non-gasoline Business', 1, '', '2008-01-01', '', '', '', '', '', '', '', '', 25, 'Ranger', '1992-01-01', 'm', '1970-02-01', 'USA', 1),
(5, 'Buyer_One', 'buyer1', 0, 'Buyer', 'One', '7654 On the Street', '', 'Bloomington', 'MN', '55431', '', 'proflexive@gmail.com', '', 'Buyer One', 4, '', '2007-11-01', '', '', '', '', '', '', '', '', 44, 'Protege', '1996-01-01', 'm', '1970-02-01', 'USA', 1),
(6, 'newuser', 'newpass', 0, 'New', 'User', 'abc', '', 'Pune', '2', '1234', '', 'new@user.com', '', 'new user', 2, '123', '2010-01-01', '7676', '', '', '', '', '', '', '', 28, '2007', '2008-01-01', 'm', '1976-12-30', 'India', 3),
(7, 'yogesh', 'mahajan', 0, 'Yogesh', 'Mahajan', 'Jalgaon', '', 'Jalgaon', '2', '2323', '', 'yog@gmail.com', '', 'Y B Mahajan', 2, '24554435', '2018-12-01', '2423', '', '', '', '', '', '', '', 19, 'sdf', '2009-01-01', 'm', '1966-12-19', 'India', 3),
(8, 'perform', 'perf0rm', 0, 'Perform', 'Better', '201 Watson Road', '', 'STL', 'MO', '63119', '319-267-6789', 'perf0rm@email.com', '', 'Perform Better', 1, '7683938657290000', '2017-02-01', '486', '', '', '', '', '', '', '', 4, 'DB5', '1963-01-01', 'm', '1980-10-10', 'USA', 2),
(9, 'fortoday', 'fortoday', 0, 'For', 'Today', 'JM', 'Road', 'Pune', '15', '42514', '123456789', 'for@today.com', '', 'Todays World', 1, '12345678', '2009-11-01', '1232', '', '', '', '', '', '', '', 17, 'fg12', '2008-01-01', 'm', '1977-12-19', 'India', 7),
(10, 'raju', 'raju123', 0, 'Raju', 'Mahajan', 'Vallabh Nagar', 'Pimpri', 'Pune', '2', '12345', '123123123', 'raju@gmail.com', '123456', 'Raju Mahajan', 3, '1234567897879456', '2010-02-01', '1234', '', '', '', '', '', '', '', 16, '123', '2008-01-01', 'm', '1966-11-17', 'India', 3),
(11, 'cbeene', 'cbeene', 0, 'Carissa', 'Beene', '875 Summit Avenue', '', 'St. Paul', 'Minnesota', '55105', '6127026673', 'carissa.dotseth@wmitchell', '0', '', 0, '0', '0000-00-00', '0', '', '', '0', '0', '', '', '', 0, '', '0000-00-00', 'm', '0000-00-00', '', 1),
(12, 'mdenoma', 'mdenoma', 0, 'Michael', 'DeNoma', '875 Summit Avenue', '', 'St. Paul', 'Minnesota', '55105', '6512906351', 'Michael.DeNoma@wmitchell.', '0', '', 0, '0', '0000-00-00', '0', '', '', '0', '0', '', '', '', 0, '', '0000-00-00', 'm', '0000-00-00', '', 1),
(13, 'jerstling', 'jerstling', 0, 'Jay', 'Erstling', '875 Summit Avenue', '', 'St. Paul', 'Minnesota', '55105', '6512906351', 'jay.erstling@wmitchell.ed', '0', '', 0, '0', '0000-00-00', '0', '', '', '0', '0', '', '', '', 0, '', '0000-00-00', 'm', '0000-00-00', '', 1),
(14, 'Mohit', '123456', 0, 'Mohit', 'Sharma', 'Test', 'TEst', 'test', '19', '111', '', 'mohit2305@gmail.com', '', 'Test', 3, '1111111111111111', '2009-02-01', '2222', 'test', 'Test', '333333333', '', '', '', '', 73, 's', '2009-01-01', 'm', '1980-05-23', 'India', 0),
(15, 'vikas', 'vikas', 0, 'Vikas', 'Garg', 'C-15,3rd Fllor', 'Amar Colony Main Market', 'New Delhi', '14', '11111', '1234567890', 'vikasgarg@yahoo.com', '', 'Vikas Garg', 1, '4111111111111111', '2010-01-01', '123', '', '', '', '', '', '', '', 7, '2000', '2000-01-01', 'm', '1971-01-01', 'India', 0),
(16, 'trinath', 'trinath123', 0, 'trinath', 'pradhan', 'asdfasdf', 'asdfasdf', 'Florida', '14', '23456', '2344563456', 'connecttrinath@yahoo.com', '', 'wwertwert', 1, '4111111111111111', '2011-05-01', '1111', 'trinath', 'scb', '123456789', '1234567890', 'florida', 'FL', '', 23, 'm3456', '2008-01-01', 'm', '1974-08-09', 'usa', 0),
(17, 'teewanna', 'passw0rd', 0, 'Tri', 'Vo', '120 Main St', 'PW mit cero', 'Farmingdale', '38', '11735', '', 'tri.vo@itsofts.com', '', 'Tri Vo', 1, '4111111111111111', '2010-01-01', '123', '', '', '', '', '', '', '', 1, 'MDX', '2009-01-01', 'm', '1971-01-01', 'USA', 1),
(18, 'rishijethwa', 'cleartext?', 0, 'Rishi', 'Jethwa', '1310 N Cockrell Hill Rd', '', 'Dallas', '50', '75211', '1111111111', 'rishijethwa@gmail.com', '', 'Rishi Jethwa', 1, '4211111111111111', '2012-08-01', '111', '', '', '', '', '', '', '', 23, 'Toyota', '2009-01-01', 'm', '1980-10-24', 'USA', 1),
(19, 'kirans', 'change', 0, 'arun', 'Chandra', 'Hyd', '', 'Hyderabad', '1', '11112', '121221212', 'kiransatmail@gmail.com', '', 'kiran', 2, '4111111111111111', '2010-02-01', '643', '', '', '', '', '', '', '', 15, 'hsgfdh', '1980-01-01', 'm', '1950-02-01', 'IND', 1),
(20, 'chetanpatel', 'chetanpatel', 0, 'chetan', 'patel', 'chetan', '', 'bangalore', '41', '56564', '7897894586', 'chetanpatel@dreamajax.com', '', 'chetanpatel', 1, '1234134312341234', '2019-12-01', '234', '', '', '', '', '', '', '', 30, '345dsret32', '2009-01-01', 'm', '1964-10-17', 'India', 3),
(21, 'emicosoft', 'rajaram', 0, 'Rajaraman', 'Perumal', '2A, JP Greenland Apartment', '', 'Chennai', '18', '12112', '', 'emicosoft@gmail.com', '', 'Rajaram', 1, '1212121212121212', '2013-12-01', '645', '', '', '', '', '', '', '', 8, '2009', '2001-01-01', 'm', '1971-02-16', 'India', 1),
(22, 'daleedom', 'dayspring777', 0, 'David', 'Leedom', '415 Larkspur Loop', '', 'Lancaster', '45', '17602', '', 'daleedom@hightowergroup.com', '', 'dave', 1, '234', '2014-03-01', '234', '', '', '', '', '', '', '', 14, '34d', '2001-01-01', 'm', '1962-10-03', 'USA', 1),
(23, 'kailash', 'kailash', 0, 'Kailash', 'Unknown', '34 Postfach 20', '', 'Zurich', 'Canton', '54321-87', '', 'kailash@kailash.com', '', 'kailash', 1, '1212121212', '2019-11-01', '122', '', '', '', '', '', '', '', 29, '12', '1212-01-01', 'm', '1971-12-28', 'US', 2),
(24, 'kevinadams', 'Hydrogen789', 0, 'Kevin', 'Adams', 'Street', '', 'City', '38', '10286', '8457042843', 'kevin.adams@avidtechnosys.com', '', 'Kevin Adams', 1, '4444333322221111', '2011-04-01', '477', '', '', '', '', '', '', '', 12, '123', '2009-01-01', 'm', '1985-08-18', 'USA', 2),
(25, 'thomasreitz', 'Opus6787', 0, 'Thomas', 'Reitz', '8180 Boat Hook Loop #325', '', 'Windermere', '14', '34786', '4076144554', 'reitz@seo9oneone.com', '', 'Thomas Reitz', 1, '4111111111111111', '2011-07-01', '898', '', '', '', '', '', 'FL', '', 23, 'Testarossa', '2008-01-01', 'm', '1963-02-07', 'United States', 5),
(26, 'kishore', 'k1sh0re', 0, 'Kishore', 'Gupta', '683 Cascade', '', 'Boise', 'ID', '65432', '517-234-9821', 'kishorgupta5@gmail.com', '', 'kishore gupta', 1, '1234561236585225', '2010-02-01', '123', 'test', 'test', '121', '1234567890', 'test', 'AL', '', 1, '120', '2012-01-01', 'm', '1951-02-01', 'test', 1),
(27, 'ezequiel', 'care4u', 0, 'Ezequiel', 'Santamaria', '3480 Zarthan Ave.', 'Apt 4', 'St. Louis Park', '28', '55416', '5072502686', 'ezequiell@gmail.com', '', 'Ezequiel Santamaria', 1, '4455333311114555', '2011-03-01', '174', '', '', '', '', '', '', '', 18, 'Still', '1985-01-01', 'm', '1983-11-10', 'Hennepin', 1),
(28, 'testinaccount', '123456', 0, 'admin', 'admin', 'New Delhi', 'New Delhi', 'New Delhi', '19', '11009', '', 'vikas@globaltechnosys.com', '0', 'Testing', 1, '4111111111111111', '2009-09-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1969-12-31', 'India', 2),
(29, 'August2009', 'august2009', 0, 'Caesar', 'Augustus', '10411 York', '', 'Rome', '17', '10001', '', 'joke@joke.com', '0', 'Caesar Augustus', 1, '4008263559771775', '2011-03-01', '034', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1978-08-08', 'Italy', 1),
(30, 'syman', 'syman', 0, 'syman', 'syman', 'syman st', '', 'syman', '26', '02169', '', 'syman@syman.com', '0', 'syman', 1, '4444333322221111', '2010-01-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1949-01-01', 'USA', 5),
(31, 'awara', '03004484312', 0, 'Awara', 'Pucit', 'lahore', '', 'lahore', '3', '54000', '', 'awara_pucit@yahoo.com', '0', 'awara', 1, '03456465', '2016-06-01', '0415', 'allied bank', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1986-09-24', 'pakistani', 2),
(32, 'Georgia', 'jandaba', 0, 'Zura', 'Egetashvili', 'Chikovani St.34', '', 'Tbilisi', '15', '12345', '', 'wanderer.geo@gmail.com', '0', 'Zura Egetashvili', 1, '4111111111111111', '2012-05-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1981-05-18', 'Georgia', 0),
(33, 'securenext', 'saran123', 0, 'K Saravana', 'Kumar', '#6', 'Ch', 'NY', '38', '11002', '6502674363', 'securenext@gmail.com', '0', 'K Saravana kumar', 1, '4100000000000000', '2009-01-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1976-12-25', 'United States', 3),
(34, 'test', 'test', 0, 'test', 'test', 'fgfghfhgf', '', 'hghhgh', '5', '20001', '7687765646', 'test@test.com', '0', 'john', 1, '4334343434534534', '2010-04-01', '111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1973-06-19', 'usa', 2),
(35, 'sathish', 'passwordabcd', 0, 'sathish', 'manohar', 'kknagar', '', 'chennai', '49', '44', '', 'nmsathishraju@gmail.com', '0', 'sathish', 1, '435345453453', '2011-02-01', '5555', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1966-12-15', 'india', 3),
(36, 'ram', 'ram', 0, 'ram', 'ram', 'chennai', '', 'chennai', '32', '45644', '', 'krishrameesh@gmail.com', '0', 'dgdg', 1, '1111111111111111', '2011-09-01', '1232', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1986-07-13', 'india', 0),
(37, 'dstephans', 'test', 0, 'Dan', 'Stephans', '14244 Allen Drive', '', 'Savage', '28', '55378', '', 'adept@stephans.org', '0', 'DJS', 1, '44444444444444', '2019-11-01', '234', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1964-12-19', 'USA', 2),
(38, 'dummy', 'dummy', 0, 'dummy', 'dummy', '123 dummy', '', 'dummy', '1', '12345', '', 'dummy@dummy.com', '0', '123567890', 1, '1234567890', '2009-01-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1949-01-01', 'dummy', 1),
(39, 'sriram85', '123456', 0, 'sri', 'ram', '32 naths st', '', 'new york', '38', '10044', '', 'sriram85@ymail.com', '0', 'asdasd', 1, '3424234324', '2011-02-01', '323', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1966-11-20', 'us', 2),
(40, 'Charles', 'webterrain', 0, 'Charles', 'Thomas', 'yellow stone lane', '', 'fdg', '1', '34567', '', 'webterrain.info@gmail.com', '0', 'Charles Thomas', 1, '4111111111111111', '2014-09-01', '234', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1981-11-18', 'USA', 5),
(41, 'Sam', 'webterrain', 0, 'Sam', 'Gregg', 'later', '', 'albama', '1', '34453', '', 'sun_coder28@yahoo.com', '0', '4111111111111111', 1, '42422422223322', '2011-01-01', '232', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1985-09-17', 'USA', 3),
(42, 'asimism', 'qwerty123', 0, 'Asim', 'Ismail', 'abz', 'asa', 'New york', '36', '38000', '121-212-2121', 'asimism@gmail.com', 'asimism@gmail.com', 'asim ismail', 1, '1111111111111111', '2011-01-01', '1111', '', '', '', '', '', '', 'asimism@gmai.com', 0, '', '0000-00-00', 'm', '2011-01-01', 'USA', 2),
(43, 'alex', 'qwerty123', 0, 'Alex', 'Mick', '!23 Lane', 'Alpha', 'Glasgow', '25', '38000', '1212121212', 'asimism@hotmail.com', '0', 'ASIM ISMAIL', 1, '1212121212121212', '2012-02-01', '2121', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1977-12-21', 'USA', 2),
(44, 'karthik', 'password', 0, 'karthik', 'karthik', 'kk nagar', '', 'chennai', '19', '60007', '', 'reikia12345678@gmail.com', '0', 'karthik', 1, '6252365321522', '2009-05-01', '4567', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1982-05-16', 'india', 2),
(45, 'sateeshchandra', 'sanga', 0, 'Sateesh', 'Chandra', 'Banshankari', '', 'Bangalore', '23', '34567', '9877681234', 'sateeshchandra.sanga@gmail.com', '0', 'Sateesh', 2, '789098765', '2012-01-01', '1234', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1984-08-14', 'INDIA', 5),
(46, 'faraz', '1111', 0, 'faraz', 'nawaz', '123', '', 'faisalabad', '33', '38000', '', 'farazhoney@hotmail.com', '0', 'faraz', 1, '123456789', '2012-12-01', '589', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1981-12-12', 'pakistan', 1),
(47, 'admin', 'admin12', 0, 'nishant', 'singh', 'shipra', 'shipra', 'noida', '18', '47533', '', 'nishant@vedangsoftware.com', '0', 'nishant', 1, '5252553523534653', '2018-12-01', '1231', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1974-11-27', 'india', 5),
(48, 'fasfa', '123456', 0, 'asdf', 'df', 'asdf', 'adf', 'asdf', '6', '423', '', 'sdf@ss.com', '0', 'afda', 1, '463434', '2013-02-01', '3333', '', ',,,', '', '', ',,,', '', '', 0, '', '0000-00-00', 'm', '1956-08-07', 'adfas', 0),
(49, 'manoj', 'manoj', 0, 'manoj', 'manoj', 'manoj', 'manoj', 'manoj', '2', '71130', '3333333333', 'manoj@101websitedesign.com', '0', 'manoj', 1, '1111111111111', '2011-02-01', '333', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1960-02-15', 'manoj', 4),
(50, 'ashok_shah', 'ashok123', 0, 'Ashok', 'Kumar', 'F 35 / 2', 'Katwaria Sarai', 'Town hall', '38', '55434', '1111111111', 'ashok_shah1091@yahoo.co.in', '0', 'Ashk Kumar', 1, '1111111111111', '2012-01-01', '111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1983-01-02', 'USA', 1),
(51, 'j2ibeo', 'qwerty12345', 1, 'ronald', 'tuibeo', '87 banlat road', '', 'q.c', '18', '1111', '', 'j2ibeo@gmail.com', '0', 'ronald tuibeo', 1, '1111111111111111', '2011-11-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1967-01-01', 'phils', 5),
(57, 'universe', '123@admin', 0, 'Universe', 'Technology', '19/B', 'Club Road', 'Kolkata', '5', '12345', '111-111-1111', 'universesys@gmail.com', 'universesys@gmail.com', 'Cardholder Name', 2, '1111111111111111', '2013-06-16', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-16', 'India', 2),
(55, 'vbdf', '1234', 1, 'c2', 'dsfsdf', 'sdfsd', 'sdfsd', 'sdfs', '1', 'sdfs', '111-111-1111', 'a1@gmail.com', 'a1@gmail.com', '1111', 2, '011', '2013-06-04', '1', '11', '11', '11', '111', '111', '', '', 0, '', '0000-00-00', 'm', '2013-06-04', 'www', 1),
(58, 'ksautya10', '123@admin', 0, 'Krishna', 'Sautya', 'Kolkata', 'Kolkata', 'Kolkata', '5', '12345', '___-___-____', 'ksautya10@gmail.com', 'ksautya10@gmail.com', 'Krishna', 2, '111111111111111', '2013-06-16', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-16', 'India', 4),
(59, 'Goutam', 'test', 0, 'goutam', 'majumder', 'kolkata', 'kolkata', 'kolkata', '1', '11111', '111-111-1111', 'gmajumder89@gmail.com', 'gmajumder89@gmail.com', 'cvgd', 1, '5444', '2013-06-16', '111', '444444444444', 'gdfgfdg', '444757774', '4444444444444', 'fdf', '1', 'fdf', 0, '', '0000-00-00', 'm', '2013-06-16', 'india', 3),
(60, 'cris', '123456', 0, 'Cris', 'test', 'test', 'test', 'kolkata', '1', '12345', '', 'k@gmail.com', 'k@gmail.com', 'test', 1, '0', '0000-00-00', '0', '', '', '0', '0', '', '', '', 0, '', '0000-00-00', 'm', '0000-00-00', 'USA', 1),
(62, 'user1', '1111', 0, 'user', 'user', 'user', 'user', 'user', '18', '1234', '', 'arnab@universe-tech.com', 'arnab@universe-tech.com', 'user', 2, '1111', '2013-06-04', '1111', 'user', 'user', '111111111', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-04', 'user', 2),
(63, 'user2', 'user2', 0, 'user2', 'user2', 'user2', 'user2', 'user2', '3', '1111', '', 'user2@gmail.com', 'user2@gmail.com', 'user2', 2, '1111', '2013-06-05', '111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-05', 'user2', 2),
(64, 'test2', '123@admin', 0, 'test', 'test', 'kolkata', 'kolkata', 'kolkata', '19', '70011', '111-111-1111', 'teat12@gmail.com', 'teat12@gmail.com', '111111111111', 2, '111111111', '2013-06-12', '2222', '2222222222', 'dfdsf', '111111', '1222221121212', 'fgdgd', '19', '545435443543', 0, '', '0000-00-00', 'm', '2013-06-12', 'india', 4),
(65, 'userKrishna', '123@admin', 0, 'TestUser', 'TestUser', 'sadsd', '', 'sdsds', '15', '12345', '___-___-____', 'testK@gmail.com', 'testK@gmail.com', '11111111111111111', 1, '1111111111111111', '2013-06-28', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-28', 'India', 1),
(66, 'Borrower', 'Borrower', 0, 'Borrower1st', 'BorrowerLast', 'Borrower''s Lane', '', 'Borrowersville', '5', '94271', '', 'BorrowerEmail@gmail.com', 'BorrowerEmail@gmail.com', 'h', 1, '3446', '2014-06-25', '874', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2014-06-25', 'USA', 1),
(67, 'Lender', 'Lender', 0, 'Lender1st', 'LenderLast', 'Lender Boulevard', '', 'Lendersville', '15', '43896', '', 'Lenderand@yahoo.com', 'Lenderand@yahoo.com', 'Lender', 2, '865432', '2022-06-23', '089', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'f', '2022-06-23', 'USA', 1),
(68, 'user3', 'user3', 0, 'user3', 'user3', 'user3', 'user3', 'user3', '8', '11111', '1111111111', 'user3@gmail.com', '0', '', 0, '0', '0000-00-00', '0', '', '', '0', '0', '', '', '', 0, '', '0000-00-00', 'm', '0000-00-00', '', 1),
(69, 'KrishnaSautya', '123@admin', 0, 'sdsd', 'ssds', 'sdsdsd', '', 'sdsdsd', '17', '12345', '', 'test12@gmail.com', 'test12@gmail.com', 'dfdfdfd', 2, '1111111111111111', '2013-06-25', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-25', 'India', 5),
(70, 'itemOwner1', 'itemOwner1', 0, 'itemOwner1', 'itemOwner1', 'itemOwner1', 'itemOwner1', 'itemOwner1', '1', '11111', '', 'itemOwner1@gmail.com', 'itemOwner1@gmail.com', 'itemOwner1', 2, '1111111111111111', '2018-06-14', '1111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2018-06-14', 'itemOwner1', 1),
(71, 'renter1', 'renter1', 0, 'renter1', 'renter1', 'renter1', '', 'renter1', '1', '11111', '', 'renter1@gmail.com', 'renter1@gmail.com', 'renter1', 2, '1111111111111122', '2018-06-14', '1111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2018-06-14', 'renter1', 1),
(72, 'Borrower1', 'Borrower', 0, 'Borrower', 'Borrower', 'Borrower', '', 'Borrower', '1', '12345', '', 'gmajumder891@gmail.com', '0', 'asasa', 1, '1234567891234567', '2023-01-01', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '1971-12-19', 'India', 1),
(73, 'test13B', 'test13', 0, 'test13', 'test13', 'test13', 'test13', 'test13', '16', '12345', '', 'test13@gmail.com', 'test13@gmail.com', 'test13', 2, '1234567891234567', '2013-06-26', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-26', 'India', 2),
(74, 'test13O', 'test13', 0, 'test13', 'test13', 'test13', '', 'test13', '4', '12345', '', 'test131@gmail.com', 'test131@gmail.com', 'test13', 1, '1111', '2013-06-26', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-26', 'India', 2),
(75, 'Borrower13', 'Borrower', 0, 'Borrower', 'Borrower', 'Borrower', '', 'Borrower', '1', '12345', '', 'Borrower@gmail.com', 'Borrower@gmail.com', 'Borrower', 1, '123456789123456', '2013-06-27', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-27', 'India', 1),
(76, 'ItemOwner', 'ItemOwner', 0, 'ItemOwner', 'ItemOwner', 'ItemOwner', '', 'ItemOwner', '1', '12345', '', 'ItemOwner@gmail.com', 'ItemOwner@gmail.com', 'ItemOwner', 1, '1234567891234567', '2013-06-27', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-27', 'India', 1),
(77, 'ItemOwner15', 'ItemOwner15', 0, 'ItemOwner15', 'ItemOwner15', 'ItemOwner15', '', 'ItemOwner15', '2', '12345', '', 'ItemOwner15@gmail.com', 'ItemOwner15@gmail.com', 'ItemOwner15', 1, '1234567891234567', '2013-06-27', '123', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-27', 'India', 1),
(78, 'item0123', 'item0123', 0, 'item0123', 'item0123', 'item0123', '', 'item0123', '1', '11111', '', 'item0123@gmail.com', 'item0123@gmail.com', 'item0123', 2, '1111111111111111', '2013-06-29', '1111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2013-06-29', 'item0123', 1),
(79, 'itemOwner20', 'itemOwner20', 0, 'itemOwner20', 'itemOwner20', 'itemOwner20', 'itemOwner20', 'itemOwner20', '1', '11111', '', 'itemOwner20@gmail.com', 'itemOwner20@gmail.com', 'itemOwner20', 2, '1111111111111111', '2015-06-25', '1111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2015-06-25', 'itemOwner20', 1),
(80, 'Borrower20', 'Borrower20', 0, 'Borrower20', 'Borrower20', 'Borrower20', 'Borrower20', 'Borrower20', '1', '11111', '', 'Borrower20@gmail.com', 'Borrower20@gmail.com', 'Borrower20', 2, '1111111111111111', '2019-06-21', '1111', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'm', '2019-06-21', 'Borrower20', 1),
(81, 'LenderJun28', 'LenderJun28', 0, 'Lender', 'Jun28', '9u92je', '', 'mnkasndn', '17', '38461', '', 'jsdhsh@ijhwkjds.com', 'jsdhsh@ijhwkjds.com', 'LenderJun28', 1, '157', '2016-06-27', '643', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'f', '2016-06-27', 'USA', 1),
(82, 'BorrowerJun28', 'BorrowerJun28', 0, 'Borrower', 'Jun28', 'BorrowerJun28 Lane', '', 'jkkas', '11', '23552', '', 'BorrowerJun28@yahoo.com', 'BorrowerJun28@yahoo.com', 'BorrowerJun28', 3, '6173919347217632', '2016-06-30', '765', '', '', '', '', '', '', '', 0, '', '0000-00-00', 'f', '2016-06-30', 'USA', 1);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(30) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `catid` int(10) unsigned DEFAULT NULL,
  `price` float(4,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=68 ;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`item_id`, `author`, `title`, `catid`, `price`, `description`, `owner`) VALUES
(1, 'Kishor', 'The Aviator', 42, 0.01, 'Testing items', 'kishore'),
(2, 'Kishor', 'Casino Royale', 42, 0.01, 'Testin item', 'kishore'),
(3, 'Kishor', 'Casino Royale', 42, 0.01, 'testing.............', 'kishore'),
(4, 'Kishor', 'The Aviator', 42, 0.01, 'testing', 'kishore'),
(5, 'Test', 'The Aviator2', 42, 0.01, 'testind', 'kishore'),
(6, 'Test', 'The Aviator3', 42, 0.01, 'Testing', 'kishore'),
(7, 'Test', 'Casino Royale', 42, 0.01, 'Tseting', 'kishore'),
(8, 'Woman with Cat', 'Octopus 101', 44, 5.00, 'With pic', 'August2009'),
(9, 'Tom Rooster', 'Biology 101', 19, 0.10, 'Text Book Title is Biology 101 by Tom Rooster. Pic is TracFone. Price: 0.1', 'srishti'),
(10, 'Brittanica', 'Encyclopaedia', 45, 99.99, 'All the maps are included', 'August2009'),
(11, 'syman', 'GoldenEye', 46, 2.00, 'Bond, James Bond!', 'syman'),
(12, 'syman', 'GoldenEye', 46, 2.00, 'Bond, James Bond!', 'syman'),
(13, 'Microsoft', 'Windows 95 software', 47, 99.99, 'This is 100% onlyproduct bug free from microsoft. I have limitedversion of these CD''s. if anyone want to be a proud holder of these disk for few weeks then i am here. contact me', 'securenext'),
(14, 'ramesg', 'pictures', 48, 99.99, 'sdfsdf', 'ram'),
(15, 'sathish', 'novelties', 51, 24.00, 'black grm', 'sathish'),
(16, 'Test`', 'Test CS', 17, 10.00, 'test video cassette', 'proflexive'),
(17, 'James Bond', 'Casino Royale', 54, 0.07, 'Daniel Craig''s 1st movie', 'mdenoma'),
(18, 'test', 'item 3', 17, 12.00, 'test', 'proflexive'),
(34, 'item', 'item2', 55, 0.00, 'item', 'charles'),
(22, 'Jay Erstling', 'Any Title 23.9.09', 30, 0.00, 'Written and uploaded on 23, 2009', 'jerstling'),
(23, 'Admin', 'Test Item Test', 16, 0.00, 'test', 'proflexive'),
(33, 'Blue Ray1', 'Blue Ray1--charles', 55, 0.00, 'Blue Ray1', 'charles'),
(26, 'Mike DeNoma = Author', 'Sep 24, 09 book', 54, 0.00, 'Entered on Sep 24, 09', 'mdenoma'),
(35, 'asim', 'So cool DVD', 56, 0.00, 'A new DVD', 'asimism'),
(36, 'Alex', 'Star Wars', 56, 0.00, 'A latest release of star wars. as we have seen on TV.', 'asimism'),
(37, 'sandesk', 'ram', 57, 0.00, '256MB', 'karthik'),
(38, 'Luca Pasani', 'PHP Rocks', 58, 0.00, 'Its the Book About all PHP', 'sateeshchandra'),
(39, 'New Author 2010', 'New Book 2010', 44, 0.00, 'New Book 2010 and New Author 2010', 'august2009'),
(40, 'manoj', 'manoj', 0, 0.00, 'sfds sd fsdf segg etet eter', 'manoj'),
(41, 'Add Sms', 'Add Sms', 59, 0.00, 'sfdsf sf sddstgds dgd', 'manoj'),
(42, 'item author', 'item Title', 59, 0.00, 'testing for dvd', 'manoj'),
(43, 'item author22', 'item Title11', 60, 0.00, 'dsf dgr regg', 'manoj'),
(44, 'mmmmm', 'mmmmm', 59, 0.00, 'mmmm', 'manoj'),
(45, 'j2ibeo', 'THe last item', 0, 0.00, 'this is a test item without category', 'j2ibeo'),
(46, 'j2ibeo', 'acceleration due to gravity', 0, 0.00, 'a short film that exhibits Newton''s 3rd law of motion', 'j2ibeo'),
(47, 'jbt', 'the best in the west', 61, 0.00, 'this is a flyer about a play', 'j2ibeo'),
(48, 'j2ibeo', 'the last programmer', 46, 0.00, 'this is a book', 'j2ibeo'),
(49, 'ram', '1201-For Medical Professionals', 44, 0.00, 'test', 'ram'),
(50, 'manoj', 'The Love Boat', 16, 0.00, 'test', 'manoj'),
(51, 'test', 'test', 16, 0.00, 'tetsadasadasdasdas', 'manoj'),
(52, 'another test', 'my test', 60, 0.00, 'what is this?', 'manoj'),
(53, 'qwqwqwq', 'WEWEWEW', 60, 0.00, 'asdasdasdasd', 'manoj'),
(54, 'new beast', 'new book', 16, 0.00, 'new books', 'manoj'),
(55, 'manoj', 'new manoj item', 16, 0.00, 'test', 'manoj'),
(56, 'manoj', '6206-cosmetic line', 12, 0.00, 'eaaeaafa', 'manoj'),
(57, 'manoj', '3201-DVT Medical Device', 60, 0.00, 'zsdfgdfdfb', 'manoj'),
(58, 'dadasdas', 'asdasd', 16, 0.00, 'aafaasdadasdasdas', 'j2ibeo'),
(59, 'new beast', '6203- Skin Fungi and Eczema', 62, 0.00, 'adesfsdfs', 'manoj'),
(60, 'another test', 'Clinical Information', 24, 0.00, 'xdfgdsgfdsgd', 'manoj'),
(61, 'another test', 'Charter Edit', 44, 0.00, 'fcgfdg', 'manoj'),
(62, 'ram', '6206-cosmetic line', 24, 0.00, 'asdadasda', 'j2ibeo'),
(63, 'test', 'What''s On', 46, 0.00, 'asdadas', 'j2ibeo'),
(64, 'test', 'Win Server', 45, 0.00, 'asdasd', 'j2ibeo'),
(65, 'new beast', 'Lawn Bowls', 46, 0.00, 'asdasd', 'j2ibeo'),
(66, 'Admin', 's1', 8, 0.00, 'asasas', 'srishti'),
(67, 'Admin', 's2', 12, 0.00, 'sasas', 'srishti');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `catid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `catname` varchar(40) NOT NULL DEFAULT '',
  `owner` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`catid`, `catname`, `owner`) VALUES
(1, 'Internet', ''),
(2, 'Self-help', ''),
(5, 'Fiction', ''),
(4, 'Gardening', ''),
(6, 'test', '1'),
(7, '2a', '2'),
(8, '2b', '2'),
(9, '3a', '3'),
(10, '3b', '3'),
(11, 'AC', '2'),
(12, '2', '2'),
(13, '2abc', '2'),
(14, 'zipp', '2'),
(15, 'abc', '2'),
(16, 'Books', 'proflexive'),
(17, 'Novels', 'proflexive'),
(18, 'Reference Books', 'srishti'),
(19, 'Text Books', 'srishti'),
(20, 'Mystery', 'rlembong'),
(21, 'Adult', 'yogesh'),
(22, 'Magazine', 'fortoday'),
(23, 'Fortnightly', 'fortoday'),
(24, 'Biography', 'newuser'),
(25, 'Horror', 'nongasbiz'),
(26, 'Magazines', 'Buyer_One'),
(27, 'Drama', 'yogesh'),
(28, 'War', 'yogesh'),
(29, 'Book', 'fortoday'),
(30, 'Law', 'jerstling'),
(31, 'Hardware', 'mohit'),
(32, 'vvv', 'vikas'),
(33, 'DVD', 'vikas'),
(34, 'Test DVD', 'vikas'),
(35, 'welcome', 'trinath'),
(36, 'tttttttttttttttttttt', 'trinath'),
(37, 'Computers', 'proflexive'),
(38, 'chetan', 'chetanpatel'),
(39, 'Tables', 'teewanna'),
(40, 'Text Book', 'daleedom'),
(41, 'testtom', 'thomasreitz'),
(42, 'Movies', 'kishore'),
(43, 'Game', 'kishore'),
(44, 'Back to School', 'August2009'),
(45, 'Any Books', 'August2009'),
(46, 'Action Thriller', 'syman'),
(47, 'Software Disk', 'securenext'),
(48, 'aaaa', 'ram'),
(49, 'cds', 'sathish'),
(50, 'hhh', 'ram'),
(51, 'novelties', 'sathish'),
(52, 'sample123', 'sriram85'),
(53, 'test cat', 'proflexive'),
(54, 'Law School Textbook', 'mdenoma'),
(55, 'test category', 'charles'),
(56, 'FROM ASIM', 'asimism'),
(57, 'computer accessories', 'karthik'),
(58, 'Technical Books', 'sateeshchandra'),
(59, 'manoj11000', 'manoj'),
(60, 'Nwe category', 'manoj'),
(61, 'Reunions', 'j2ibeo'),
(62, 'Books2', 'j2ibeo'),
(63, 'ZZ', 'proflexive'),
(64, 'fewrfert', 'srishti'),
(65, 'goutam', 'srishti'),
(66, 'T-Shirt', 'universe'),
(67, 'Speed Boat', 'user2'),
(68, 'byke', 'user2');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE IF NOT EXISTS `customers` (
  `customerid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL DEFAULT '',
  `address` varchar(40) NOT NULL DEFAULT '',
  `city` varchar(20) NOT NULL DEFAULT '',
  `state` varchar(20) DEFAULT NULL,
  `zip` varchar(10) DEFAULT NULL,
  `country` varchar(20) NOT NULL DEFAULT '',
  `username` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`customerid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `name`, `address`, `city`, `state`, `zip`, `country`, `username`) VALUES
(1, 'Buyer One', '7654 On the Street', '', '', '55431', '', 'Buyer_One'),
(3, 'For Today', 'JM', 'Georgia', 'Georgia', '42514', '', 'fortoday'),
(4, 'Perform Better', '201 Watson Road', '', '', '63119', '', 'perform'),
(5, 'Srishti Infotech', 'Vallabh Nagar', '', '', '123456', '', 'srishti'),
(6, 'Srishti Infotech', 'Vallabh Nagar', 'gfdg', 'fgfg', '123456', 'fdgg', 'srishti'),
(7, 'Srishti Infotech', 'Vallabh Nagar', 'fgf', 'fgf', '123456', 'fdgf', 'srishti'),
(8, '', '', '', '', '', '', ''),
(9, 'arun Chandra', 'Hyd', 'Alabama', 'Alabama', '11112', '', 'kirans'),
(10, 'David Leedom', '415 Larkspur Loop', 'Pennsylvania', 'Pennsylvania', '17602', '', 'daleedom'),
(11, 'Tri Vo', '120 Main St', 'New York', 'New York', '11735', '', 'teewanna'),
(12, 'Srishti Infotech', 'Vallabh Nagar', 'Chicago', 'IL 60606', '123456', 'INDIA', 'srishti'),
(13, 'admin admin', 'New Delhi', 'Indiana', 'Indiana', '11009', '', 'hfdhfd'),
(14, 'Ezequiel Santamaria', '3480 Zarthan Ave.', 'Minnesota', 'Minnesota', '55416', '', 'ezequiel'),
(15, 'Caesar Augustus', '10411 York', 'Idaho', 'Idaho', '10001', '', 'August2009'),
(16, 'kailash kailash', 'kailash', 'Minnesota', 'Minnesota', '12345', '', 'kailash'),
(17, 'Tri Vo', '120 Main St', 'New York', 'New York', '11735', 'USA', 'teewanna'),
(18, 'Buyer One', '7654 On the Street', 'Bloomington', 'MN', '55431', 'USA', 'Buyer_One'),
(19, 'syman syman', 'syman st', 'Massachusetts', 'Massachusetts', '02169', '', 'syman'),
(20, 'K Saravana Kumar', '#6', 'New York', 'New York', '11002', '', 'securenext'),
(21, 'ram ram', 'chennai', 'Nebraska', 'Nebraska', '45644', '', 'ram'),
(22, 'Charles Thomas', 'yellow stone lane', 'Alabama', 'Alabama', '34567', 'USA', 'charles'),
(23, 'Proflexive International', '666 Elm Street', '', '', '60606', '', 'proflexive'),
(24, 'Charles Thomas', 'yellow stone lane', 'Alabama', 'Alabama', '34567', '', 'charles'),
(25, 'Sam Gregg', 'later', 'Alabama', 'Alabama', '34453', '', 'Sam'),
(26, 'Michael DeNoma', '875 Summit Avenue', 'St. Louis', 'MN', '55105', 'USA', 'mdenoma'),
(27, 'Carissa Beene', '875 Summit Avenue', 'St. Louis', 'MN', '55105', 'USA', 'cbeene'),
(28, 'Sam Gregg', 'later', 'albama', 'Alabama', '34453', 'USA', 'Sam'),
(29, 'Charles Thomas', 'yellow stone lane', 'fdg', 'Alabama', '34567', 'USA', 'charles'),
(30, 'Carissa Beene', '875 Summit Avenue', 'St. Paul', 'MN', '55105', 'USA', 'cbeene'),
(31, 'Asim Ismail', 'abz', 'New york', 'New Jersey', '38000', 'USA', 'asimism'),
(32, 'Alex Mick', '!23 Lane', 'Glasgow', 'Maryland', '38000', 'USA', 'alex'),
(33, 'Sateesh Chandra', 'Banshankari', 'Bangalore', 'Louisiana', '34567', 'INDIA', 'sateeshchandra'),
(34, 'Perform Better', '201 Watson Road', 'STL', 'MO', '63119', 'USA', 'perform'),
(35, 'Kishore Gupta', '683 Cascade', 'Boise', 'ID', '65432', '', 'kishore'),
(37, 'Ray Me', '10411 York', 'Minneapolis', 'MN', '55431', 'USA', 'rlembong'),
(38, 'ronald tuibeo', '87 banlat road', 'q.c', 'Illinois', '1111', 'philippines', 'j2ibeo'),
(39, 'manoj manoj', 'manoj', 'manoj', 'Alaska', '71130', 'manoj', 'manoj'),
(40, 'Michael DeNoma', '875 Summit Avenue', 'St. Paul', '', '55105', '', 'mdenoma'),
(41, 'Borrower Borrower', 'Borrower', 'Borrower', 'Alabama', '12345', 'India', 'Borrower1');

-- --------------------------------------------------------

--
-- Table structure for table `cust_mebership`
--

DROP TABLE IF EXISTS `cust_mebership`;
CREATE TABLE IF NOT EXISTS `cust_mebership` (
  `membership_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mid` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id` varchar(50) DEFAULT NULL,
  `s_date` date NOT NULL DEFAULT '0000-00-00',
  `e_date` date NOT NULL DEFAULT '0000-00-00',
  `user_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`membership_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `gasvertisement`
--

DROP TABLE IF EXISTS `gasvertisement`;
CREATE TABLE IF NOT EXISTS `gasvertisement` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `Item_Name` varchar(60) DEFAULT NULL,
  `reward` varchar(255) NOT NULL DEFAULT '',
  `reward_qty` varchar(60) DEFAULT NULL,
  `catid` int(10) NOT NULL DEFAULT '0',
  `price2pay` float(10,2) DEFAULT '0.00',
  `price2paydollars` float(10,2) DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(16) NOT NULL DEFAULT '',
  `gas_station` varchar(50) DEFAULT NULL,
  `station` varchar(200) NOT NULL DEFAULT '',
  `exp_date` date NOT NULL DEFAULT '0000-00-00',
  `federal_tax` int(8) NOT NULL DEFAULT '0',
  `state_tax` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `gasvertisement`
--

INSERT INTO `gasvertisement` (`Item_Id`, `Item_Name`, `reward`, `reward_qty`, `catid`, `price2pay`, `price2paydollars`, `description`, `owner`, `gas_station`, `station`, `exp_date`, `federal_tax`, `state_tax`) VALUES
(1, '96 Chevy Cavalier', '', '100', 0, 5000.00, 0.00, 'Buy 1996 Chevy Cavalier, then receive 100 gallons free gas at 666 Elm Street in Chicago, IL 60606.', 'proflexive', '', '2', '0000-00-00', 0, 0),
(2, '2005 Acura', '', '100', 0, 36.00, 0.00, 'Buy the 2005 Acura for $36,000 and receive 100 gallons of gas.', 'proflexive', '2', '2', '0000-00-00', 0, 0),
(3, 'dfdsfds', '', '28', 0, 12.00, 0.00, 'dsfdsfds', 'testing', '', '5', '0000-00-00', 0, 0),
(4, '94 BMW 530i Stn Wagon', '', '100', 0, 5000.00, 0.00, 'If you buy 94 BMW 530i Stn Wagon for $5000, you can receive 100 gallons of gas from your participating gas pumps.', 'proflexive', '', '3', '0000-00-00', 0, 0),
(5, 'Test Advertisement for station at delhi', '', '3', 0, 150.00, 0.00, 'this is test description', 'sanjeev', '', '6', '0000-00-00', 0, 0),
(9, 'Rajtest', 'gallon', '1', 12, 200.00, 0.00, 'test test tetst tetste tsst  trfu uyhtg yut uy guug raj', 'neuronimbus', '', '8', '2022-03-01', 0, 0),
(10, 'Nov 30, 06', 'gallon', '1', 4, 100.00, 0.00, 'This test is on Nov 30, 06', 'proflexive', '2', '3', '2006-12-18', 0, 0),
(11, 'Nov 30, 06', 'gallon', '1', 4, 100.00, 0.00, 'This test is on Nov 30, 06', 'proflexive', '2', '3', '2006-12-18', 0, 0),
(15, 'Test on Dec 12, 2006', 'gallon', '10', 4, 100.00, 0.00, 'Test on Dec 12, 2006. Must dissapear on Test on Dec 13, 2006', 'proflexive', '', '3', '2006-12-12', 0, 0),
(18, 'test', 'dollor', '17', 12, 23.00, 0.00, 'this is the test', 'neuronimbus', '', '8', '2006-01-17', 0, 0),
(19, 'test', 'dollor', '17', 12, 23.00, 0.00, 'this is the test', 'neuronimbus', '', '8', '2006-01-17', 0, 0),
(20, 'test', 'dollor', '17', 12, 23.00, 0.00, 'this is the test', 'neuronimbus', '', '8', '2006-01-17', 0, 0),
(21, 'test', 'dollor', '17', 12, 23.00, 0.00, 'this is the test', 'neuronimbus', '', '8', '2006-01-17', 0, 0),
(22, 'raj', 'dollor', '5', 13, 2332.00, 0.00, 'tets', 'neuronimbus', '', '8', '2005-11-19', 0, 0),
(23, 'testqqqq', 'dollor', '3', 13, 2552.00, 0.00, 'gfgfgfgfgfgfg', 'neuronimbus', '', '8', '2007-04-16', 0, 0),
(24, 'Test', 'gallon', '5', 2, 100.00, 0.00, 'Test', 'proflexive', '22', '2', '2007-05-10', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `author` varchar(30) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `catid` int(10) unsigned DEFAULT NULL,
  `price` float(4,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(16) NOT NULL DEFAULT '',
  `format` varchar(20) DEFAULT NULL,
  `imgName` text NOT NULL,
  `createItemDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(2) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=135 ;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `author`, `title`, `catid`, `price`, `description`, `owner`, `format`, `imgName`, `createItemDate`, `status`) VALUES
(76, 'arnab', 'book1', 29, 2.00, 'book', 'newuser', 'CD', '', '0000-00-00 00:00:00', 'Y'),
(77, 'u_arnab', 'book2', 47, 3.00, 'book2', 'newuser', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(86, 'Universe', 'TIS India', 7, 0.00, 'dfdfdfdfd', 'universe', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(85, 'Author3', 'TIS India', 4, 0.00, 'gfg', 'universe', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(80, 'Author1', 'title1', 1, 0.00, 'test1', 'srishti', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(81, 'Author2', 'Title2', 2, 0.00, 'Test', 'srishti', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(82, 'Author3', 'Title3', 3, 0.00, 'test', 'srishti', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(83, 'Author1', 'Item 1', 4, 0.00, 'test1', 'universe', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(84, 'Author2', 'Nice Product', 1, 0.00, 'test2', 'universe', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(87, 'asas', 'my new blog', 8, 0.00, 'sasasasqa', 'Goutam', 'DVD', '', '0000-00-00 00:00:00', 'N'),
(88, 'Cris', 'Shirt1', 66, 0.00, 'test item', 'universe', 'Others', '', '0000-00-00 00:00:00', 'Y'),
(89, 'Scan disk', 'Pendrive', 57, 0.00, 'test item', 'universe', 'Others', '1054746367_06_20_2013.jpg', '0000-00-00 00:00:00', 'Y'),
(90, 'user', 'Css', 29, 0.00, 'design web', 'user1', 'CD', '', '2013-06-02 00:00:00', 'Y'),
(91, 'AUTHmanoj12:14Jun18', 'manoj12:14Jun18', 46, 0.00, 'manoj12:14Jun18 BY AUTHmanoj12:14Jun18', 'manoj', 'Blu-Ray', '', '0000-00-00 00:00:00', 'Y'),
(92, 'AUTHmanoj12:18Jun18', 'manoj12:18Jun18', 46, 0.00, 'manoj12:14Jun18 BY AUTHmanoj12:14Jun18', 'manoj', 'Blu-Ray', '', '0000-00-00 00:00:00', 'N'),
(93, 'Item Author', 'Item Title', 63, 0.00, 'Description', 'newuser', 'Video Casette', '', '0000-00-00 00:00:00', 'N'),
(95, 'user1', 'Ram', 31, 0.00, 'Ram of a computer.', 'user1', 'Others', '770183322_06_19_2013.jpg', '2013-06-15 00:00:00', 'Y'),
(96, 'Audi', 'Audi R8 Inspired Speed Boat', 67, 0.00, 'Speed Boat', 'user2', 'Others', '884820675_06_20_2013.jpg', '2013-06-20 07:37:49', 'Y'),
(97, 'Koh Lanta speedboat transfer', 'Koh Lanta speedboat transfer', 67, 0.00, 'Koh Lanta speedboat transfer', 'user2', 'Others', '917272002_06_20_2013.jpg', '2013-06-20 07:38:59', 'Y'),
(98, 'Auth 806PM Jun 20', '806PM Jun 20', 24, 0.00, '806PM Jun 20 by Auth 806PM Jun 20 PIC Me Want Sushi 1', 'fortoday', 'Laser Disc', '1211637094_06_21_2013.JPG', '2013-06-21 01:03:44', 'Y'),
(99, 'Admin', 'Create a Board', 12, 0.00, 'wwewew', 'userKrishna', 'DVD', '722846504_06_21_2013.jpg', '2013-06-21 12:49:40', 'Y'),
(100, 'Auth1859Jun24', '1859Jun24', 44, 0.00, '1859Jun24', 'fortoday', 'Laser Disc', '2048435660_06_24_2013.JPG', '2013-06-24 23:55:18', 'Y'),
(101, 'Autr2000Jun24', '2000Jun24', 10, 0.00, '2000Jun24', 'nongasbiz', 'Hard Bound', '897822454_06_25_2013.JPG', '2013-06-25 00:51:25', 'Y'),
(102, 'user2', 'Css', 29, 0.00, 'book', 'user2', 'CD', '1123558265_06_25_2013.png', '2013-06-25 11:50:51', 'N'),
(103, 'Admin', 'test Item', 29, 0.00, 'test product', 'universe', 'CD', '2116692722_06_25_2013.jpg', '2013-06-25 14:54:10', 'Y'),
(104, 'Author1', 'test Item', 45, 0.00, 'test desc', 'universe', 'DVD', '2010955472_06_25_2013.jpg', '2013-06-25 14:58:46', 'Y'),
(105, 'asasas', 'cvvcv', 7, 0.00, 'asasasasa', 'universe', 'Blu-Ray', '141964776_06_25_2013.jpg', '2013-06-25 15:01:55', 'Y'),
(106, 'Universe', 'Nice Product', 13, 0.00, 'test', 'KrishnaSautya', 'DVD', '923334450_06_25_2013.jpg', '2013-06-25 15:11:12', 'Y'),
(107, 'Item Author:1', 'Item Title:1', 29, 0.00, 'Description:', 'itemOwner1', 'CD', '558816547_06_26_2013.jpg', '2013-06-26 07:02:38', 'Y'),
(108, 'Item Author:2', 'Item Title:2', 29, 0.00, 'Description:2', 'itemOwner1', 'CD', '816271289_06_26_2013.png', '2013-06-26 07:04:12', 'Y'),
(109, 'Item Author:3', 'Item Title:3', 29, 0.00, 'Description:3', 'itemOwner1', 'DVD', '288866602_06_26_2013.png', '2013-06-26 07:14:48', 'Y'),
(110, 'kawasaki', 'K13S45M', 68, 0.00, 'It is a nice byke.', 'user2', 'Others', '1057547249_06_26_2013.jpg', '2013-06-26 11:00:56', 'N'),
(111, 'user2', 'Book of Nature', 29, 0.00, 'Book of Nature.', 'user2', 'DVD', '1228243740_06_26_2013.png', '2013-06-26 11:01:56', 'Y'),
(112, 'LG', 'LG Air Conditioner', 11, 0.00, 'LG Air Conditioner.', 'user2', 'Others', '222315979_06_26_2013.jpg', '2013-06-26 11:04:00', 'Y'),
(113, 'Audi', 'audir8-boat', 67, 0.00, 'audir8-boat.', 'itemOwner1', 'Others', '339602905_06_26_2013.jpg', '2013-06-26 12:03:33', 'N'),
(114, 'Audi', 'lanta-speedboat', 67, 0.00, 'lanta-speedboat.', 'itemOwner1', 'Others', '1129724507_06_26_2013.jpg', '2013-06-26 12:04:13', 'N'),
(115, 'Ducati ', '2013 Ducati 1199 Panigale', 68, 0.00, 'While the Ducati 1199 Panigale is getting a number of revisions under the skin for its second year on the market, like an improved chassis and suspension setup (more on that later).', 'itemOwner1', 'Others', '765085573_06_26_2013.jpg', '2013-06-26 12:07:13', 'N'),
(116, 'itemOwner1 ', 'Book of Nature', 29, 0.00, 'Description:1', 'itemOwner1', 'CD', '1869349582_06_26_2013.jpg', '2013-06-26 12:09:51', 'Y'),
(117, 'itemOwner1', 'book2', 29, 0.00, 'Description:2', 'itemOwner1', 'CD', '1327441057_06_26_2013.png', '2013-06-26 12:10:57', 'Y'),
(118, 'itemOwner1', 'book3', 29, 0.00, 'Description:3', 'itemOwner1', 'CD', '733735980_06_26_2013.png', '2013-06-26 12:14:03', 'N'),
(119, 'itemOwner1', 'Book of Science', 29, 0.00, 'Book of Science.', 'itemOwner1', 'CD', '1787182171_06_26_2013.jpg', '2013-06-26 12:28:15', 'Y'),
(120, 'Admin', 's1', 8, 0.00, 'asasas', 'srishti', 'CD', '', '2013-06-26 15:03:39', 'N'),
(121, 'Admin', 's2', 12, 0.00, 'sasas', 'srishti', 'CD', '', '2013-06-26 15:04:25', 'N'),
(122, 'Admin', 'This is the first news template', 12, 0.00, 'sedsdsd', 'test13O', 'Blu-Ray', '1158469593_06_26_2013.jpg', '2013-06-26 15:39:45', 'Y'),
(123, 'Admin', 'This is the fiwewerst news template', 12, 0.00, 'wewewewew', 'test13O', 'CD', '1222660475_06_26_2013.jpg', '2013-06-26 15:39:57', 'Y'),
(124, 'Author1', 'item1', 12, 0.00, 'qwewewe', 'ItemOwner', 'Blu-Ray', '936642053_06_27_2013.jpg', '2013-06-27 07:07:54', 'Y'),
(125, 'Universe', 'sasa', 12, 0.00, 'asasasas', 'ItemOwner', 'Blu-Ray', '758533260_06_27_2013.jpg', '2013-06-27 07:08:11', 'Y'),
(126, 'wewew', '3ewe', 12, 0.00, 'wewewe', 'Borrower13', 'Blu-Ray', '1569610630_06_27_2013.jpg', '2013-06-27 07:45:12', 'Y'),
(127, 'asasa', 'asas', 12, 0.00, 'asasa', 'Borrower13', 'Blu-Ray', '1766723643_06_27_2013.jpg', '2013-06-27 07:46:17', 'Y'),
(128, 'Author 20', 'Item 20', 29, 0.00, 'Description:20', 'itemOwner20', 'CD', '678297683_06_27_2013.png', '2013-06-27 13:58:54', 'Y'),
(129, 'Author 2', 'Item 2', 29, 0.00, 'Description:2', 'itemOwner20', 'CD', '428585246_06_27_2013.jpg', '2013-06-27 13:59:38', 'Y'),
(130, 'Athr_1406Jun28', '1406Jun28', 48, 0.00, '1406Jun28 US CAN Map', 'itemOwner1', 'Laser Disc', '194724115_06_28_2013.gif', '2013-06-28 19:04:08', 'Y'),
(131, 'ATR1637Jun28', '1637Jun28', 68, 0.00, '1637Jun28 with ATR1637Jun28 with PIC Frontier IP', 'LenderJun28', 'Hard Bound', '352070415_06_28_2013.JPG', '2013-06-28 21:36:09', 'Y'),
(132, 'AUTH: yogesh Jul 7, 2013', 'yogesh Jul 7, 2013', 46, 0.00, 'yogesh Jul 7, 2013. AUTH: yogesh Jul 7, 2013. PIC: Me Want Sushi 1', 'yogesh', 'Hard Bound', '1257753506_07_08_2013.JPG', '2013-07-08 03:18:43', 'Y'),
(133, 'AUTH: test Jul 7, 2013', 'test Jul 7, 2013', 24, 0.00, 'test Jul 7, 2013 AUTH: test Jul 7, 2013. PIC: Me Want Sushi 2', 'test', 'Laser Disc', '1006072892_07_08_2013.JPG', '2013-07-08 03:38:25', 'Y'),
(134, 'ATH: BorrowerJun28''s Item Jul ', 'BorrowerJun28''s Item Jul 8, 13', 62, 0.00, 'BorrowerJun28''s Item Jul 8, 13. PIC: T-Mobile Connected', 'BorrowerJun28', 'Others', '1094727723_07_09_2013.JPG', '2013-07-09 00:32:07', 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `item_format`
--

DROP TABLE IF EXISTS `item_format`;
CREATE TABLE IF NOT EXISTS `item_format` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `format` varchar(200) DEFAULT NULL,
  `price` decimal(5,2) DEFAULT '0.00',
  `max_days` int(3) DEFAULT '25',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `item_format`
--

INSERT INTO `item_format` (`id`, `format`, `price`, `max_days`) VALUES
(1, 'CD', 2.00, 25),
(2, 'DVD', 2.00, 25),
(3, 'Blu-Ray', 0.00, 25),
(4, 'Laser Disc', 3.00, 25),
(5, 'Video Casette', 0.00, 25),
(6, 'Others', 3.00, 25),
(7, 'Hard Bound', 43.00, 12);

-- --------------------------------------------------------

--
-- Table structure for table `membership_fee`
--

DROP TABLE IF EXISTS `membership_fee`;
CREATE TABLE IF NOT EXISTS `membership_fee` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `membership_fee` float(10,2) NOT NULL DEFAULT '0.00',
  `rebate_amount` float(10,2) NOT NULL DEFAULT '0.00',
  `period` varchar(60) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(60) NOT NULL DEFAULT '',
  `station` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=67 ;

--
-- Dumping data for table `membership_fee`
--

INSERT INTO `membership_fee` (`Item_Id`, `membership_fee`, `rebate_amount`, `period`, `description`, `owner`, `station`) VALUES
(1, 15.99, 1.50, '1 Month', '', 'newuser', ''),
(2, 12.00, 0.00, '1 Month', '', 'Nitin123', ''),
(3, 15.99, 2.50, '1 Month', '', 'yogesh', ''),
(4, 41.99, 0.00, '1 Month', '', 'perform', ''),
(5, 24.99, 0.50, '1 Month', '', 'fortoday', ''),
(6, 13.99, 0.00, '1 Month', 'no', 'rlembong', ''),
(7, 19.99, 8.00, '1 Month', 'no', 'srishti', ''),
(8, 17.99, 2.50, '1 Month', 'no', 'proflexive', ''),
(9, 4.99, 4.00, '1 Month', 'no', 'nongasbiz', ''),
(10, 168.58, 0.00, '1 Month', 'no', 'Buyer_One', ''),
(11, 15.99, 0.00, '1 Month', '', 'raju', ''),
(12, 4.99, 1.00, '1 Month', '', 'teewanna', ''),
(13, 4.99, 0.00, '1 Month', '', 'rishijethwa', ''),
(14, 4.99, 0.00, '1 Month', '', 'kirans', ''),
(15, 15.99, 0.00, '1 Month', '', 'chetanpatel', ''),
(16, 4.99, 0.00, '1 Month', '', 'emicosoft', ''),
(17, 4.99, 0.50, '1 Month', '', 'daleedom', ''),
(18, 0.00, 0.00, '1 Month', '', 'kailash', ''),
(19, 0.00, 0.00, '1 Month', '', 'kevinadams', ''),
(20, 18.99, 0.00, '1 Month', '', 'thomasreitz', ''),
(21, 4.99, 4.50, '1 Month', '', 'kishore', ''),
(22, 4.99, 0.00, '1 Month', '', 'ezequiel', ''),
(23, 0.00, 0.00, '1 Month', '', 'hfdhfd', ''),
(24, 14.97, 3.00, '1 Month', '', 'August2009', ''),
(25, 18.99, 0.50, '1 Month', '', 'syman', ''),
(26, 7.00, 0.00, '1 Month', '', 'awara', ''),
(27, 0.00, 0.00, '1 Month', '', 'Georgia', ''),
(28, 15.99, 0.50, '1 Month', '', 'securenext', ''),
(29, 7.00, 0.50, '1 Month', '', 'test', ''),
(30, 15.99, 1.00, '1 Month', '', 'sathish', ''),
(31, 128.00, 1.00, '1 Month', '', 'ram', ''),
(32, 7.00, 0.00, '1 Month', '', 'dstephans', ''),
(33, 4.99, 0.00, '1 Month', '', 'dummy', ''),
(34, 7.00, 0.00, '1 Month', '', 'sriram85', ''),
(35, 18.99, 5.00, '1 Month', '', 'Charles', ''),
(36, 23.99, 0.00, '1 Month', '', 'Sam', ''),
(37, 91.00, 1.00, '1 Month', '', 'asimism', ''),
(38, 17.00, 0.00, '1 Month', '', 'alex', ''),
(39, 7.00, 0.50, '1 Month', '', 'karthik', ''),
(40, 18.99, 0.50, '1 Month', '', 'sateeshchandra', ''),
(41, 4.99, 0.00, '1 Month', '', 'faraz', ''),
(42, 18.99, 0.00, '1 Month', '', 'admin', ''),
(43, 0.00, 0.00, '1 Month', '', 'fasfa', ''),
(44, 33.99, 20.00, '1 Month', '', 'manoj', ''),
(45, 4.99, 0.00, '1 Month', '', 'ashok_shah', ''),
(46, 50.99, 4.50, '1 Month', '', 'j2ibeo', ''),
(47, 28.00, 3.50, '1 Month', '', 'user2', ''),
(48, 17.99, 0.00, '1 Month', '', 'test2', ''),
(49, 4.99, 0.50, '1 Month', '', 'userKrishna', ''),
(50, 15.99, 0.00, '1 Month', '', 'Borrower', ''),
(51, 4.99, 0.00, '1 Month', '', 'Lender', ''),
(52, 4.99, 0.00, '1 Month', '', 'user3', ''),
(53, 18.99, 0.50, '1 Month', '', 'KrishnaSautya', ''),
(54, 59.88, 3.00, '1 Month', '', 'itemOwner1', ''),
(55, 19.96, 0.00, '1 Month', '', 'renter1', ''),
(56, 4.99, 0.00, '1 Month', '', 'Borrower1', ''),
(57, 7.00, 0.00, '1 Month', '', 'test13B', ''),
(58, 7.00, 1.00, '1 Month', '', 'test13O', ''),
(59, 15.99, 1.00, '1 Month', '', 'Borrower13', ''),
(60, 14.00, 1.00, '1 Month', '', 'ItemOwner', ''),
(61, 4.99, 0.00, '1 Month', '', 'ItemOwner15', ''),
(62, 4.99, 0.00, '1 Month', '', 'item0123', ''),
(63, 4.99, 1.00, '1 Month', '', 'itemOwner20', ''),
(64, 7.00, 0.00, '1 Month', '', 'Borrower20', ''),
(65, 4.99, 0.50, '1 Month', '', 'LenderJun28', ''),
(66, 7.00, 0.50, '1 Month', '', 'BorrowerJun28', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `orderid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customerid` int(10) unsigned NOT NULL DEFAULT '0',
  `amount` float(6,2) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_status` varchar(20) DEFAULT NULL,
  `ship_name` varchar(40) NOT NULL DEFAULT '',
  `ship_address` varchar(40) NOT NULL DEFAULT '',
  `ship_city` varchar(20) NOT NULL DEFAULT '',
  `ship_state` varchar(20) DEFAULT NULL,
  `ship_zip` varchar(10) DEFAULT NULL,
  `ship_country` varchar(20) NOT NULL DEFAULT '',
  `google_ord_num` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `customerid`, `amount`, `date`, `order_status`, `ship_name`, `ship_address`, `ship_city`, `ship_state`, `ship_zip`, `ship_country`, `google_ord_num`) VALUES
(10, 63, 0.00, '2013-06-18 09:18:41', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(9, 63, 0.00, '2013-06-18 09:18:57', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(19, 64, 0.00, '2013-06-21 12:21:22', 'PARTIAL', 'test test', 'kolkata kolkata', 'kolkata', '19', '70011', 'india', NULL),
(6, 58, 0.00, '2013-06-16 12:16:38', 'PARTIAL', 'Krishna Sautya', 'Kolkata Kolkata', 'Kolkata', '5', '12345', 'India', NULL),
(11, 29, 0.00, '2013-06-19 02:19:26', 'PARTIAL', 'Caesar Augustus', '10411 York ', 'Rome', '17', '10001', 'Italy', NULL),
(17, 63, 0.00, '2013-06-20 07:20:29', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(18, 29, 0.00, '2013-06-21 01:21:18', 'PARTIAL', 'Caesar Augustus', '10411 York ', 'Rome', '17', '10001', 'Italy', NULL),
(14, 63, 0.00, '2013-06-20 07:20:28', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(15, 63, 0.00, '2013-06-20 07:20:59', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(16, 62, 0.00, '2013-06-20 07:20:52', 'PARTIAL', 'user user', 'user user', 'user', '18', '1234', 'user', NULL),
(20, 40, 0.00, '2013-06-21 12:51:49', 'PARTIAL', 'Michael DeNoma', '875 Summit Avenue', 'St. Paul', '', '55105', '', ''),
(21, 66, 0.00, '2013-06-25 00:25:50', 'PARTIAL', 'Borrower1st BorrowerLast', 'Borrower''s Lane ', 'Borrowersville', '5', '94271', 'USA', NULL),
(22, 68, 0.00, '2013-06-25 11:25:35', 'PARTIAL', 'user3 user3', 'user3 user3', 'user3', '8', '11111', '', NULL),
(23, 63, 0.00, '2013-06-25 12:25:54', 'PARTIAL', 'user2 user2', 'user2 user2', 'user2', '3', '1111', 'user2', NULL),
(24, 1, 0.00, '2013-06-25 14:25:58', 'PARTIAL', 'Srishti Infotech', 'Vallabh Nagar Pimpri', 'Pune', '5', '123456', 'India', NULL),
(25, 1, 0.00, '2013-06-25 15:25:27', 'PARTIAL', 'Srishti Infotech', 'Vallabh Nagar Pimpri', 'Pune', '5', '123456', 'India', NULL),
(26, 1, 0.00, '2013-06-25 15:25:04', 'PARTIAL', 'Srishti Infotech', 'Vallabh Nagar Pimpri', 'Pune', '5', '123456', 'India', NULL),
(27, 71, 0.00, '2013-06-26 07:26:16', 'PARTIAL', 'renter1 renter1', 'renter1 ', 'renter1', '1', '11111', 'renter1', NULL),
(28, 71, 0.00, '2013-06-26 07:26:57', 'PARTIAL', 'renter1 renter1', 'renter1 ', 'renter1', '1', '11111', 'renter1', NULL),
(29, 71, 0.00, '2013-06-26 07:26:25', 'PARTIAL', 'renter1 renter1', 'renter1 ', 'renter1', '1', '11111', 'renter1', NULL),
(30, 70, 0.00, '2013-06-26 11:26:49', 'PARTIAL', 'itemOwner1 itemOwner1', 'itemOwner1 itemOwner1', 'itemOwner1', '1', '11111', 'itemOwner1', NULL),
(31, 41, 0.00, '2013-06-26 15:05:04', 'PARTIAL', 'Borrower Borrower', 'Borrower', 'Borrower', 'Alabama', '12345', 'India', ''),
(32, 41, 0.00, '2013-06-26 15:05:42', 'PARTIAL', 'Borrower Borrower', 'Borrower', 'Borrower', 'Alabama', '12345', 'India', ''),
(33, 73, 0.00, '2013-06-26 15:26:45', 'PARTIAL', 'test13 test13', 'test13 test13', 'test13', '16', '12345', 'India', NULL),
(34, 75, 0.00, '2013-06-27 07:27:50', 'PARTIAL', 'Borrower Borrower', 'Borrower ', 'Borrower', '1', '12345', 'India', NULL),
(35, 75, 0.00, '2013-06-27 07:27:53', 'PARTIAL', 'Borrower Borrower', 'Borrower ', 'Borrower', '1', '12345', 'India', NULL),
(36, 76, 0.00, '2013-06-27 07:27:39', 'PARTIAL', 'ItemOwner ItemOwner', 'ItemOwner ', 'ItemOwner', '1', '12345', 'India', NULL),
(37, 76, 0.00, '2013-06-27 07:27:32', 'PARTIAL', 'ItemOwner ItemOwner', 'ItemOwner ', 'ItemOwner', '1', '12345', 'India', NULL),
(38, 80, 0.00, '2013-06-27 14:27:03', 'PARTIAL', 'Borrower20 Borrower20', 'Borrower20 Borrower20', 'Borrower20', '1', '11111', 'Borrower20', NULL),
(39, 66, 0.00, '2013-06-28 19:28:17', 'PARTIAL', 'Borrower1st BorrowerLast', 'Borrower''s Lane ', 'Borrowersville', '5', '94271', 'USA', NULL),
(40, 82, 0.00, '2013-06-28 21:28:49', 'PARTIAL', 'Borrower Jun28', 'BorrowerJun28 Lane ', 'jkkas', '11', '23552', 'USA', NULL),
(41, 82, 0.00, '2013-06-28 22:28:57', 'PARTIAL', 'Borrower Jun28', 'BorrowerJun28 Lane ', 'jkkas', '11', '23552', 'USA', NULL),
(42, 82, 0.00, '2013-07-08 03:08:28', 'PARTIAL', 'Borrower Jun28', 'BorrowerJun28 Lane ', 'jkkas', '11', '23552', 'USA', NULL),
(43, 82, 0.00, '2013-07-08 03:08:46', 'PARTIAL', 'Borrower Jun28', 'BorrowerJun28 Lane ', 'jkkas', '11', '23552', 'USA', NULL),
(44, 34, 0.00, '2013-07-09 00:09:11', 'PARTIAL', 'test test', 'fgfghfhgf ', 'hghhgh', '5', '20001', 'usa', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `orderid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `item_id` int(11) NOT NULL DEFAULT '0',
  `item_price` float(4,2) NOT NULL DEFAULT '0.00',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0',
  `tempId` int(11) NOT NULL,
  `sesionId` varchar(255) NOT NULL,
  `createDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(2) NOT NULL DEFAULT 'N',
  `track` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`orderid`,`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=56 ;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`orderid`, `userId`, `item_id`, `item_price`, `quantity`, `tempId`, `sesionId`, `createDate`, `status`, `track`) VALUES
(21, 63, 96, 0.00, 1, 663404069, '23404a0c80ca5fa6a9075e26f30661a8', '2013-06-20 07:39:22', 'Y', '0'),
(22, 29, 97, 0.00, 1, 379848147, '670d1a9ba1736f6f1738d6dcd45ccc31', '2013-06-20 23:42:51', 'Y', '0'),
(23, 29, 98, 0.00, 1, 1500569833, '670d1a9ba1736f6f1738d6dcd45ccc31', '2013-06-21 01:36:11', 'Y', '1'),
(24, 64, 99, 0.00, 1, 163609779, '7e8ba7819d702330df8cd1b0efbbcd25', '2013-06-21 12:50:03', 'Y', '1'),
(25, 66, 100, 0.00, 1, 2123046585, 'a311a5d24c245eb6e0e70f43426b92b4', '2013-06-25 00:24:55', 'Y', '0'),
(12, 0, 90, 0.00, 2, 248608657, '75a64ca6cba9ec0f530d9722d1019beb', '2013-06-18 07:39:30', 'N', '0'),
(11, 58, 89, 0.00, 1, 719546024, 'da41676bfc65b7e413b86cb87b3226e6', '2013-06-16 12:02:54', 'Y', '1'),
(10, 58, 88, 0.00, 2, 247670769, 'da41676bfc65b7e413b86cb87b3226e6', '2013-06-16 12:02:03', 'Y', '1'),
(17, 29, 91, 0.00, 1, 736297373, 'cbfc534b312e06848835c2f3abae2168', '2013-06-19 02:58:37', 'Y', '0'),
(26, 66, 101, 0.00, 1, 1612476630, 'a311a5d24c245eb6e0e70f43426b92b4', '2013-06-25 00:56:42', 'Y', '0'),
(27, 68, 102, 0.00, 2, 88434002, '70121ba29488a51d69fd1e03bd058638', '2013-06-25 11:53:24', 'Y', '0'),
(28, 63, 96, 0.00, 1, 1658838185, '7d9a1385fe726176189b7f202499c83c', '2013-06-25 12:05:59', 'Y', '0'),
(29, 57, 97, 0.00, 1, 213962741, 'b713b751df329d048c95245cc74782d3', '2013-06-25 14:49:38', 'N', '0'),
(30, 1, 103, 0.00, 1, 405093285, 'b713b751df329d048c95245cc74782d3', '2013-06-25 14:55:30', 'N', '0'),
(31, 1, 104, 0.00, 1, 820244327, 'bc6f837d5769048b52cab221a08074bb', '2013-06-25 14:59:49', 'Y', '0'),
(32, 1, 105, 0.00, 1, 1444381903, '4472cfd7e2104e148e81003047a0f5ea', '2013-06-25 15:02:21', 'Y', '0'),
(33, 1, 106, 0.00, 1, 402132044, '3cac694ed07e58277160793a7709c7fb', '2013-06-25 15:12:58', 'Y', '0'),
(34, 71, 108, 0.00, 1, 1514654873, '9d559a9c7fea001630df4f7cb0b00951', '2013-06-26 07:06:58', 'Y', '0'),
(35, 71, 107, 0.00, 2, 25691777, 'fc39376e10d5e833380fc7d34c4b6367', '2013-06-26 07:07:47', 'Y', '0'),
(36, 71, 109, 0.00, 1, 1501044453, '1b7110100af81ea2a44cdf77c8ba665d', '2013-06-26 07:15:20', 'Y', '0'),
(37, 70, 111, 0.00, 1, 1474497177, '1585e6e63bd55c0a9bf0222c3b700ad7', '2013-06-26 11:02:13', 'Y', '0'),
(38, 70, 112, 0.00, 1, 663065069, '1585e6e63bd55c0a9bf0222c3b700ad7', '2013-06-26 11:04:22', 'Y', '0'),
(39, 0, 116, 0.00, 1, 1237887860, '8de26832cd4460187fd853c148a5efd9', '2013-06-26 12:11:09', 'N', '0'),
(40, 0, 117, 0.00, 1, 24183916, '8de26832cd4460187fd853c148a5efd9', '2013-06-26 12:14:43', 'N', '0'),
(41, 73, 123, 0.00, 1, 27091746, 'aa86d9dbc7419c313e4690fa9b37d29f', '2013-06-26 15:40:28', 'Y', '0'),
(42, 73, 122, 0.00, 1, 2067184227, 'aa86d9dbc7419c313e4690fa9b37d29f', '2013-06-26 15:40:39', 'Y', '0'),
(43, 75, 125, 0.00, 1, 1855482644, '6ce9e564add88977c5995178009e3551', '2013-06-27 07:08:31', 'Y', '0'),
(44, 75, 124, 0.00, 1, 791460679, '6ce9e564add88977c5995178009e3551', '2013-06-27 07:08:43', 'Y', '0'),
(45, 75, 119, 0.00, 1, 1439874658, '4ba24af80917cad9d5c92ee672209dd7', '2013-06-27 07:41:35', 'Y', '0'),
(46, 76, 126, 0.00, 1, 1538715925, 'c291d4341aaf71dfc332c2614b12bf88', '2013-06-27 07:45:24', 'Y', '0'),
(47, 76, 127, 0.00, 1, 2086055591, '88adb4641589a5fc895810ce1dd46d32', '2013-06-27 07:46:27', 'Y', '0'),
(48, 80, 129, 0.00, 1, 1106180804, '744a2a98bfdae9efd622648d6be9e228', '2013-06-27 14:00:48', 'Y', '0'),
(49, 80, 128, 0.00, 1, 360073859, '744a2a98bfdae9efd622648d6be9e228', '2013-06-27 14:00:57', 'Y', '0'),
(50, 66, 130, 0.00, 1, 462975128, '36d842aed97272197c497e51c1687c92', '2013-06-28 19:16:12', 'Y', '0'),
(51, 82, 131, 0.00, 1, 82584980, '8aa3fe6408281ae50305c79339d6ec65', '2013-06-28 21:36:41', 'Y', '0'),
(52, 82, 110, 0.00, 1, 1337529605, '221a2c2dc95e423e83f96a609784417b', '2013-06-28 22:06:52', 'Y', '0'),
(53, 82, 132, 0.00, 1, 2108253153, '4c144a4f11f3153745f44cbed406b21e', '2013-07-08 03:20:24', 'Y', '0'),
(54, 82, 133, 0.00, 1, 1182370979, 'e9f65e7d3da27d2986e618be5a983cce', '2013-07-08 03:40:43', 'Y', '0'),
(55, 34, 134, 0.00, 1, 1248496702, '814ffdcaa4fc800f9715ebbcfca55db3', '2013-07-09 00:37:04', 'Y', '0');

-- --------------------------------------------------------

--
-- Table structure for table `order_sale`
--

DROP TABLE IF EXISTS `order_sale`;
CREATE TABLE IF NOT EXISTS `order_sale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `owner_id` varchar(255) NOT NULL,
  `renter_id` varchar(255) NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `tracking_send` varchar(255) NOT NULL,
  `tracking_return` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `format` varchar(255) NOT NULL,
  `recorded` enum('1','0') NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `order_sale`
--

INSERT INTO `order_sale` (`id`, `order_id`, `item_id`, `category_id`, `owner_id`, `renter_id`, `date_start`, `date_end`, `tracking_send`, `tracking_return`, `quantity`, `author`, `title`, `format`, `recorded`) VALUES
(2, 10, 88, 66, 'universe', 'ksautya10', '2013-06-16', '2013-07-11', '1234', '23456', 2, 'Cris', 'Shirt1', 'Others', '1'),
(3, 11, 89, 57, 'universe', 'ksautya10', '2013-06-16', '2013-07-11', 'T001', 'RT001', 1, 'Scan disk', 'Pendrive', 'Others', '1'),
(4, 16, 90, 29, 'user1', 'user2', '2013-06-18', '2013-07-13', '1234', '', 1, 'user', 'Css', 'CD', '1'),
(5, 15, 90, 29, 'user1', 'user2', '2013-06-18', '2013-07-13', '1234', '', 2, 'user', 'Css', 'CD', '1'),
(6, 23, 98, 24, 'fortoday', 'August2009', '2013-06-21', '2013-07-16', '225806202013', '231106202013', 1, 'Auth 806PM Jun 20', '806PM Jun 20', 'Laser Disc', '1'),
(7, 24, 99, 12, 'userKrishna', 'test2', '2013-06-21', '2013-06-21', 'Seller 1234', 'Renter 4321', 1, 'Admin', 'Create a Board', 'DVD', '1');

-- --------------------------------------------------------

--
-- Table structure for table `order_sale_old`
--

DROP TABLE IF EXISTS `order_sale_old`;
CREATE TABLE IF NOT EXISTS `order_sale_old` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `owner_id` varchar(16) NOT NULL,
  `renter_id` varchar(16) NOT NULL,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `tracking_send` varchar(200) DEFAULT NULL,
  `tracking_return` varchar(200) DEFAULT NULL,
  `quantity` int(3) DEFAULT NULL,
  `author` varchar(200) DEFAULT NULL,
  `title` varchar(200) DEFAULT NULL,
  `format` varchar(100) DEFAULT NULL,
  `recorded` char(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `order_sale_old`
--

INSERT INTO `order_sale_old` (`id`, `item_id`, `category_id`, `owner_id`, `renter_id`, `date_start`, `date_end`, `tracking_send`, `tracking_return`, `quantity`, `author`, `title`, `format`, `recorded`) VALUES
(1, 61, 16, 'manoj', 'j2ibeo', NULL, NULL, '', '', 1, 'ahab', 'xx', 'CD', '1'),
(2, 63, 60, 'manoj', 'j2ibeo', '2010-02-02', '2010-02-02', '555555', '123returntoowner', 1, 'abu', 'one', 'DVD', '1'),
(3, 64, 16, 'manoj', 'j2ibeo', '2010-02-02', '2010-02-02', '555555', '123returntoowner', 1, 'jafar', 'two', 'CD', '1'),
(4, 62, 60, 'manoj', 'j2ibeo', '2010-01-02', '2010-02-02', '555555', '123returntoowner', 1, 'kaofi', 'three', 'CD', '1'),
(5, 60, 16, 'manoj', 'j2ibeo', NULL, NULL, '', '', 1, 'cowie', 'four', 'CD', '1'),
(6, 67, 60, 'manoj', 'j2ibeo', NULL, NULL, '', '', 1, 'max', 'five', 'Others', '1'),
(7, 65, 16, 'manoj', 'j2ibeo', '2010-02-02', '2010-02-08', '777777', 'No tracking #', 1, 'temps', 'six', 'Others', '1'),
(8, 66, 16, 'manoj', 'j2ibeo', '2010-02-02', NULL, '777777', '', 1, 'jackson five', 'seven', 'DVD', '1'),
(9, 57, 61, 'j2ibeo', 'manoj', '2010-02-02', NULL, '22222', ' ', 1, 'jbt', 'the best in the west', 'Others', '1'),
(10, 69, 62, 'manoj', 'j2ibeo', '0000-00-00', '0000-00-00', '', '', 1, 'new beast', '6203- Skin Fungi and Eczema', 'Hard Bound', '1'),
(11, 74, 45, 'j2ibeo', 'manoj', '0000-00-00', '0000-00-00', '', '', 1, 'test', 'Win Server', 'CD', '1'),
(12, 75, 46, 'j2ibeo', 'manoj', '0000-00-00', '0000-00-00', '', '', 1, 'new beast', 'Lawn Bowls', 'CD', '1'),
(13, 55, 1, 'j2ibeo', 'alex', '0000-00-00', '0000-00-00', '', '', 1, 'j2ibeo', 'THe last item', 'Others', '0'),
(14, 56, 1, 'j2ibeo', 'alex', '0000-00-00', '0000-00-00', '', '', 1, 'j2ibeo', 'acceleration due to gravity', 'DVD', '0'),
(15, 71, 44, 'manoj', 'alex', '0000-00-00', '0000-00-00', '', '', 1, 'another test', 'Charter Edit', 'Blu-Ray', '0'),
(16, 70, 24, 'manoj', 'alex', '0000-00-00', '0000-00-00', '', '', 1, 'another test', 'Clinical Information', 'CD', '0');

-- --------------------------------------------------------

--
-- Table structure for table `payouts`
--

DROP TABLE IF EXISTS `payouts`;
CREATE TABLE IF NOT EXISTS `payouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `owner_id` varchar(200) DEFAULT NULL,
  `balance` decimal(7,2) DEFAULT '0.00',
  `credit` decimal(7,2) DEFAULT '0.00',
  `debit` decimal(7,2) DEFAULT '0.00',
  `transaction_date` date DEFAULT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `payouts`
--

INSERT INTO `payouts` (`id`, `owner_id`, `balance`, `credit`, `debit`, `transaction_date`, `description`) VALUES
(1, 'j2ibeo', 0.00, 0.50, 0.00, '2010-02-15', 'Credits earned todate'),
(2, 'manoj', 0.00, 4.50, 0.00, '2010-02-15', 'Credits earned todate'),
(3, 'j2ibeo', 0.00, 1.00, 0.00, '2010-02-15', 'Credits earned todate'),
(4, 'srishti', 0.00, 46.00, 0.00, '2013-06-16', 'Credits earned todate'),
(5, 'universe', 0.00, 24.00, 0.00, '2013-06-16', 'Credits earned todate'),
(6, 'universe', 0.00, 12.00, 0.00, '2013-06-16', 'Credits earned todate'),
(7, 'user1', 0.00, 1.00, 0.00, '2013-06-20', 'Credits earned todate'),
(8, 'fortoday', 0.00, 0.50, 0.00, '2013-06-21', 'Credits earned todate'),
(9, 'userKrishna', 0.00, 0.50, 0.00, '2013-06-21', 'Credits earned todate');

-- --------------------------------------------------------

--
-- Table structure for table `plan`
--

DROP TABLE IF EXISTS `plan`;
CREATE TABLE IF NOT EXISTS `plan` (
  `planID` int(11) NOT NULL AUTO_INCREMENT,
  `items_per_month` tinyint(15) NOT NULL DEFAULT '0',
  `monthly_fee` float(10,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`planID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `plan`
--

INSERT INTO `plan` (`planID`, `items_per_month`, `monthly_fee`) VALUES
(1, 1, 4.99),
(2, 3, 15.99),
(3, 4, 17.99),
(4, 5, 18.99),
(5, 2, 7.00);

-- --------------------------------------------------------

--
-- Table structure for table `portion_for_item_owner`
--

DROP TABLE IF EXISTS `portion_for_item_owner`;
CREATE TABLE IF NOT EXISTS `portion_for_item_owner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dollar_amount` float(10,2) DEFAULT NULL,
  `bumped_up` varchar(10) DEFAULT NULL,
  `penalty_amount` float(10,2) DEFAULT '0.00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `portion_for_item_owner`
--

INSERT INTO `portion_for_item_owner` (`id`, `dollar_amount`, `bumped_up`, `penalty_amount`) VALUES
(1, 0.50, '', 12.00);

-- --------------------------------------------------------

--
-- Table structure for table `sale_result`
--

DROP TABLE IF EXISTS `sale_result`;
CREATE TABLE IF NOT EXISTS `sale_result` (
  `item_id` int(11) DEFAULT NULL,
  `author` varchar(30) DEFAULT NULL,
  `title` varchar(60) DEFAULT NULL,
  `price` float(4,2) DEFAULT NULL,
  `owner` varchar(16) DEFAULT NULL,
  `first_name` varchar(32) DEFAULT NULL,
  `last_name` varchar(32) DEFAULT NULL,
  `address_1` varchar(64) DEFAULT NULL,
  `address_2` varchar(64) NOT NULL DEFAULT '',
  `city` varchar(32) DEFAULT NULL,
  `state` varchar(32) DEFAULT NULL,
  `zip_code` varchar(16) DEFAULT NULL,
  `country` varchar(32) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `site_name` varchar(100) NOT NULL DEFAULT '',
  `site_url` varchar(100) NOT NULL DEFAULT '',
  `admin_email` varchar(100) NOT NULL DEFAULT '',
  `results` int(10) NOT NULL DEFAULT '0',
  `lookRecord` int(11) NOT NULL,
  `dolarValue` double(20,2) NOT NULL,
  `paypal_email` varchar(100) NOT NULL DEFAULT '',
  `additionfee` double(20,2) NOT NULL,
  `postagefee` double(20,2) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signature` varchar(255) NOT NULL,
  `SmtpServer` varchar(255) NOT NULL,
  `SmtpPort` int(11) NOT NULL,
  `SmtpUser` varchar(255) NOT NULL,
  `SmtpPass` varchar(255) NOT NULL,
  `fromSite` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`site_name`, `site_url`, `admin_email`, `results`, `lookRecord`, `dolarValue`, `paypal_email`, `additionfee`, `postagefee`, `username`, `password`, `signature`, `SmtpServer`, `SmtpPort`, `SmtpUser`, `SmtpPass`, `fromSite`) VALUES
('Product Search', 'http://www.universe-tech.com/productsearchphase3/psp3/', 'universesys@gmail.com', 45, 100, 0.00, 'buyer1_1359692810_biz@gmail.com', 0.00, 0.00, 'buyer1_1359692810_biz_api1.gmail.com', '1359692866', 'AoOWQN8pzFu5Y0OCoaeL4-FoR363AcgTL0d4RGNmzNO.amhZyu..I.C.', 'mail.universe-tech.com', 25, 'test@universe-tech.com', '123@admin', 'info@xyzdemo.com');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
CREATE TABLE IF NOT EXISTS `state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`state_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `state_name`) VALUES
(4, 'Delhi');

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
CREATE TABLE IF NOT EXISTS `station` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `st_name` varchar(60) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `add1` varchar(60) NOT NULL DEFAULT '',
  `add2` varchar(60) NOT NULL DEFAULT '',
  `city` varchar(60) NOT NULL DEFAULT '',
  `state` varchar(60) NOT NULL DEFAULT '',
  `zip` varchar(15) NOT NULL DEFAULT '',
  `country` varchar(60) NOT NULL DEFAULT '',
  `owner` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`Item_Id`, `st_name`, `location`, `description`, `add1`, `add2`, `city`, `state`, `zip`, `country`, `owner`) VALUES
(2, 'BP Amoco', '', 'Car Wash, gas stations and garage', '666 Elm Street', 'Number 6', 'Chicago', 'IL', '60606', 'USA', 'proflexive'),
(3, 'QuikCheck', '', 'We sell 87, 89, 92, Diesel and E85.', '123 Main Street', '', 'Minneapolis', '', '55474', '', 'proflexive'),
(4, 'a', '', 'asdfas sdf', 'a', 'a', 'a', '', '', '', 'aaa'),
(8, 'Shell Kinder', '', 'Shell Kinder owned and operated by', '543 Ulm', '', 'Billings', 'MT', '59101', 'USA', 'neuronimbus'),
(9, 'Alimentation Couche-Tard', '', 'Petro Canada', 'Queen Victoria Avenue', '', 'VANCOUVER', 'Canada-British Columbia', 'V7P2V', 'Canada', 'neuronimbus'),
(10, 'Shell St. Louis', '', '', '7626 Watson Road', '', 'St. Louis', 'MO', '63119', 'USA', 'proflexive'),
(11, 'Sinclair Oil', '', 'Sinclair Oil and gas station, garage.', '234W17 5th Avenue', '', 'Los Angeles', 'CA', '90001', 'USA', 'neuronimbus'),
(12, 'Gas 4 Less', '', 'Currently under renovation', 'Penn Ave & 90th Street', '', 'Bloomington', 'MN', '55437', 'USA', 'rlembong'),
(13, '', '', '', '', '', '', '', '', '', 'dhwani');

-- --------------------------------------------------------

--
-- Table structure for table `store_discount`
--

DROP TABLE IF EXISTS `store_discount`;
CREATE TABLE IF NOT EXISTS `store_discount` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `Item_name` varchar(60) NOT NULL DEFAULT '',
  `gallon` varchar(255) NOT NULL DEFAULT '',
  `exp_date` date NOT NULL DEFAULT '0000-00-00',
  `price_gallon` float(10,2) DEFAULT NULL,
  `discount_qty` varchar(60) DEFAULT NULL,
  `min_purchase` float(10,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(16) NOT NULL DEFAULT '',
  `station` varchar(200) NOT NULL DEFAULT '',
  `federal_tax` int(8) NOT NULL DEFAULT '0',
  `state_tax` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `store_discount`
--

INSERT INTO `store_discount` (`Item_Id`, `Item_name`, `gallon`, `exp_date`, `price_gallon`, `discount_qty`, `min_purchase`, `description`, `owner`, `station`, `federal_tax`, `state_tax`) VALUES
(1, 'Joke', '', '0000-00-00', 2.80, '20', 50.00, 'If driver spends $50 in store, he can buy 20 gallons of gas at $2.80', 'proflexive', '2', 0, 0),
(2, 'Test', '87', '2022-11-17', 20.00, '39', 20.00, 'This is test', 'neuronimbus', '8', 0, 0),
(3, 'testraj', 'Diesel', '2007-11-16', 25.00, '1', 25.00, 'this is the test', 'neuronimbus', '8', 0, 0),
(4, 'jkjkjk', '87', '2007-08-14', 333.00, '1', 333.00, 'jkjhkjkjk', 'neuronimbus', '8', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `store_reward`
--

DROP TABLE IF EXISTS `store_reward`;
CREATE TABLE IF NOT EXISTS `store_reward` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `Item_Name` varchar(60) DEFAULT NULL,
  `gallon` varchar(255) NOT NULL DEFAULT '',
  `exp_date` date NOT NULL DEFAULT '0000-00-00',
  `reward_qty` varchar(60) DEFAULT NULL,
  `min_purchase` float(10,2) NOT NULL DEFAULT '0.00',
  `description` varchar(255) DEFAULT NULL,
  `owner` varchar(16) NOT NULL DEFAULT '',
  `station` varchar(200) NOT NULL DEFAULT '',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `store_reward`
--

INSERT INTO `store_reward` (`Item_Id`, `Item_Name`, `gallon`, `exp_date`, `reward_qty`, `min_purchase`, `description`, `owner`, `station`) VALUES
(1, 'buy 4 cup coffee and get 1 gallon free', '', '0000-00-00', '1', 100.00, 'sadfsadffas', 'ruchi', '1'),
(2, 'Free 2 gal', '', '0000-00-00', '2', 50.00, 'If you buy anything in store at least $50, you receive 2 free gallons.', 'proflexive', '2'),
(3, 'Funny', '', '0000-00-00', '2', 50.00, 'If you buy $50 in store, you will receive 2 free gallons.', 'proflexive', '2'),
(4, 'cxvxcvxc', '', '0000-00-00', '1', 12.00, 'xczxc', 'testing', '5'),
(5, 'Test Online store reward', '', '0000-00-00', '9', 1000.00, 'This is for testing by Sanjeev', 'testing', '5'),
(7, 'TestRaj', 'BioDiesel', '2006-11-19', '1', 200.00, 'Test testdfdfd dfd dfdf dfd', 'neuronimbus', '8'),
(9, 'jjjjjjjj', '87', '2006-02-04', '1', 22222.00, 'jjjjjjjj', 'neuronimbus', '8'),
(10, 'hhjjhgjhj', '87', '2007-10-04', '1', 323.00, 'hjhjhjhj', 'neuronimbus', '8'),
(11, 'Min $25', '87', '2007-01-04', '1', 25.00, 'If buyer spends > $25, he receives 1 free gal of 87.', 'proflexive', '3'),
(12, 'Min $25', '87', '2007-01-04', '1', 25.00, 'If buyer spends > $25, he receives 1 free gal of 87.', 'proflexive', '3'),
(13, 'test', '87', '2007-11-16', '1', 350.00, 'dfdfdfd', 'neuronimbus', '8'),
(14, 'Buy <$25, gets 1 gal 87', '87', '2007-01-10', '1', 25.00, 'If you spend more than $25, you will get 1 gal 87.', 'proflexive', '2');

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

DROP TABLE IF EXISTS `taxes`;
CREATE TABLE IF NOT EXISTS `taxes` (
  `Item_Id` int(11) NOT NULL AUTO_INCREMENT,
  `federal_taxes` varchar(255) NOT NULL DEFAULT '',
  `state_taxes` varchar(255) NOT NULL DEFAULT '',
  `station` varchar(255) NOT NULL DEFAULT '',
  `owner` varchar(16) NOT NULL DEFAULT '',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` (`Item_Id`, `federal_taxes`, `state_taxes`, `station`, `owner`) VALUES
(1, '10', '2.5', '8', 'neuronimbus'),
(3, '18.39999999999999857891452847979962825775146484375', '20', '3', 'proflexive'),
(4, '15', '20', '10', 'neuronimbus'),
(5, '5', '5', '8', 'neuronimbus'),
(6, '10', '10', '8', 'neuronimbus'),
(7, '7', '7', '8', 'neuronimbus'),
(8, '17', '10', '8', 'neuronimbus');

-- --------------------------------------------------------

--
-- Table structure for table `type_taxes`
--

DROP TABLE IF EXISTS `type_taxes`;
CREATE TABLE IF NOT EXISTS `type_taxes` (
  `taxes_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL DEFAULT '0',
  `amount` double NOT NULL DEFAULT '0',
  `type_tax` int(11) NOT NULL DEFAULT '0',
  `state` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`taxes_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `type_taxes`
--

INSERT INTO `type_taxes` (`taxes_id`, `item_id`, `amount`, `type_tax`, `state`) VALUES
(14, 40, 5, 1, '0'),
(13, 39, 4, 1, '0'),
(12, 26, 3, 1, '0'),
(11, 25, 2, 1, '0'),
(10, 24, 0, 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `vol_disc`
--

DROP TABLE IF EXISTS `vol_disc`;
CREATE TABLE IF NOT EXISTS `vol_disc` (
  `Item_Id` tinyint(10) NOT NULL AUTO_INCREMENT,
  `gallon` varchar(255) NOT NULL DEFAULT '',
  `price_gallon` float(10,2) NOT NULL DEFAULT '0.00',
  `qty` int(10) unsigned NOT NULL DEFAULT '0',
  `total_price` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) DEFAULT NULL,
  `exp_date` date NOT NULL DEFAULT '0000-00-00',
  `owner` varchar(60) NOT NULL DEFAULT '',
  `station` varchar(200) NOT NULL DEFAULT '',
  `federal_tax` int(8) NOT NULL DEFAULT '0',
  `state_tax` int(8) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Item_Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `vol_disc`
--

INSERT INTO `vol_disc` (`Item_Id`, `gallon`, `price_gallon`, `qty`, `total_price`, `description`, `exp_date`, `owner`, `station`, `federal_tax`, `state_tax`) VALUES
(1, '', 1.99, 30, '', 'If you buy 30 gallons, we''ll give you 1.99 per gallon instead of $2.67.', '0000-00-00', 'proflexive', '2', 0, 0),
(2, '', 2.50, 100, '', 'If you buy 100 gal, you will receive a rebate', '0000-00-00', 'proflexive', '2', 0, 0),
(3, '', 20.00, 30, '', 'xcxcx', '0000-00-00', 'testing', '5', 0, 0),
(11, 'BioDiesel', 20.00, 20, '', 'this is the etst', '0000-00-00', 'neuronimbus', '1', 0, 0),
(12, 'Diesel', 30.00, 20, '', 'dummy', '0000-00-00', 'neuronimbus', '1', 0, 0),
(13, 'E-85', 20.00, 20, '', 'this is the test', '0000-00-00', 'neuronimbus', '1', 0, 0),
(14, 'E-85', 20.00, 20, '', 'this is the test', '2006-12-12', 'neuronimbus', '1', 0, 0),
(15, 'BioDiesel', 1.95, 40, '78', 'edited Jan 10, 07: 40 gal BioDiesel @ $1.95 total $78. Exp Jan 13, 07', '2007-01-13', 'neuronimbus', '8', 0, 0),
(16, 'E-85', 20.00, 200, '', 'this si', '2006-12-05', 'neuronimbus', '15', 0, 0),
(17, 'BioDiesel', 20.00, 20, '400', 'Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text Dummy Text', '2006-12-05', 'neuronimbus', '8', 0, 0),
(18, 'BioDiesel', 25.00, 20, '500', 'Thsis is the test', '0000-00-00', 'neuronimbus', '8', 0, 0),
(21, '87', 2.25, 25, '56.25', 'This offer expires on Dec 7, 2006', '2006-12-07', 'proflexive', '2', 0, 0),
(22, '87', 10.00, 10, '100', 'test''s', '2010-02-19', 'neuronimbus', '8', 0, 0),
(23, 'Diesel', 20.48, 20, '414.14656', 'This is the test', '2023-12-06', 'neuronimbus', '8', 0, 0),
(26, 'E-85', 2.50, 85, '212.5', 'This is a test on Dec 14, 2006 selling E-85 for $2.5/gallon. The total is $212.50. Expiration Date is Dec 12, 2006.', '2006-12-12', 'proflexive', '2', 0, 0),
(28, '93', 3.93, 50, '196.5', '93 octane for sale at $3.93 if you buy 50 gallons.', '2006-12-19', 'proflexive', '3', 0, 0),
(29, '93', 2.93, 30, '87.900000000000005684341886080801486968994140625', 'If you buy 30 gallons of 93, we will lower the price per gallon to $2.93. So the total you pay is $87.9.', '2006-12-20', 'proflexive', '3', 0, 0),
(31, '87', 2.17, 70, '151.900000000000005684341886080801486968994140625', 'If you purchase 70 gallons of Octane 87, the total sale is $151.9 plus taxes.', '2006-12-20', 'proflexive', '3', 0, 0),
(32, '93', 2.93, 30, '87.900000000000005684341886080801486968994140625', 'On Dec 20, 06, we sell 30 gal of Octane 93 for 2.93/gal. The total of $87.90 expires on Dec 22, 06.', '2006-12-22', 'proflexive', '3', 0, 0),
(33, '89', 2.49, 99, '246.510000000000019326762412674725055694580078125', 'Shell St. Louis discounts Octane 89 for $2.49/gal if you buy 99 gal. Total is $246.51 until Dec 22, 06.', '2006-12-22', 'proflexive', '10', 0, 0),
(34, 'E-85', 25.00, 30, '750', 'this is the test', '2007-11-16', 'neuronimbus', '8', 0, 0),
(36, '93', 2.93, 93, '272.490000000000009094947017729282379150390625', 'Octane 93 @ $2.93 for 93 gallons. Expires Dec 27, 06', '2006-12-27', 'proflexive', '2', 0, 0),
(37, '87', 233.00, 3, '699', 'jkjkjkjkjkjkjkjkjkjk', '2022-11-18', 'neuronimbus', '8', 0, 0),
(38, '87', 2.87, 87, '249.68999999999999772626324556767940521240234375', '87 gal of Octane 87 @ $2.87 for total of $249.69. Expires Jan 7. 07', '2007-01-07', 'proflexive', '2', 0, 0),
(39, '87', 2.87, 40, '114.80000000000001', '40 gal of Octane 87 @ $2.87 for total of $114.80. Expires Jan 14. 07', '2007-01-14', 'proflexive', '2', 0, 0),
(40, '89', 2.89, 89, '257.2100000000000363797880709171295166015625', '89 gal of Octane 89 @ $2.89/gal for total $257.21. Expires Jan 09, 07', '2007-01-09', 'proflexive', '3', 0, 0),
(41, '93', 2.93, 93, '272.490000000000009094947017729282379150390625', '93 gal of Octane 93 @ $2.93/gal 4 total $272.49. Expires Jan 13, 07', '2007-01-13', 'proflexive', '10', 0, 0),
(42, '87', 36.00, 21, '756', 'this is the test', '2010-11-18', 'neuronimbus', '9', 0, 0),
(43, 'E-85', 0.85, 85, '72.25', '85 gal E-85 @ $.85 total = $72.25. Expires 8 May 06.', '2007-05-08', 'proflexive', '3', 0, 0),
(44, 'BioDiesel', 2.40, 24, '57.599999999999994315658113919198513031005859375', '24 gal of BioDiesel @ $2.40 total $57.59 expires 2 April 07', '2007-04-02', 'proflexive', '10', 0, 0),
(45, '93', 2.93, 93, '272.490000000000009094947017729282379150390625', '93 gal of Octane 93 @ $2.93 total 272.49 in MN expires Mar 9, 07.', '2007-03-09', 'proflexive', '3', 0, 0),
(46, 'BioDiesel', 30.00, 20, '600', 'this is for gas advere', '2006-01-05', 'neuronimbus', '8', 0, 0),
(47, 'BioDiesel', 30.00, 20, '600', 'this is for gas advere', '2006-01-04', 'neuronimbus', '8', 0, 0),
(48, 'Diesel', 3256.00, 10, '32560', 'vghjggghgghgghghgghggghg', '2007-02-04', 'neuronimbus', '9', 0, 0),
(49, '87', 200.00, 12, '2400', 'tetrtdrffe yet yewty uyutr eu teu etretruie rue rt uytruyet rte r yutr tre truetruerteu rutr etr utr urtr urtr errt utrru rte trpt ruit', '2022-04-05', 'neuronimbus', '11', 0, 0),
(50, '89', 23.00, 20, '460', 'klklklklklkl', '2007-10-15', 'neuronimbus', '8', 0, 0),
(51, '87', 1.27, 87, '110.4899999999999948840923025272786617279052734375', '87 gal of 87 @ $1.27 total is $110.49. Expires 27 Jan 07', '2007-01-27', 'proflexive', '3', 0, 0),
(52, '87', 1.97, 27, '53.18999999999999772626324556767940521240234375', '27 gal @ 1.97 total $53.19. Exp Jan 31, 07', '2007-01-31', 'proflexive', '2', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE IF NOT EXISTS `wishlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` varchar(11) NOT NULL DEFAULT '0',
  `dateline` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`id`, `customer`, `dateline`) VALUES
(4, '', 1252360269),
(5, 'rlembong', 1263076821);

-- --------------------------------------------------------

--
-- Table structure for table `wishlists_items`
--

DROP TABLE IF EXISTS `wishlists_items`;
CREATE TABLE IF NOT EXISTS `wishlists_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer` varchar(11) NOT NULL DEFAULT '0',
  `item` varchar(35) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `wishlists_items`
--

INSERT INTO `wishlists_items` (`id`, `customer`, `item`) VALUES
(10, '', '12'),
(11, 'rlembong', '54');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
