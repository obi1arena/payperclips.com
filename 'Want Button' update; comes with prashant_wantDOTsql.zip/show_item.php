<?
include("includes/_include.php");
?>
<? include("includes/frontHeader.php");
 
	$item_id=$_REQUEST['item_id'];
	 
	$catid=$_REQUEST['catid'];
	
	$vendor=$_REQUEST['vendor'];
	
	if($_REQUEST['type']=='rented')
	{
		$item_details=fetchItemsDetailsRented($item_id);
  	}
	else
	{
		$item_details=fetchItemsDetailsAval($item_id);
  	}		//print_r($item_details);
  ?>
<form name="wntfrm" id="wntfrm" action="show_item.php">
  <table>
    <tr>
      <td><ul>
          <li><b>Author:</b>
            <?=$item_details['author']?>
          <li><b>Description:</b>
            <?=$item_details['description']?>
          <li><b>Format:</b>
            <?=$item_details['format']?>
          </li>
        </ul></td>
    </tr>
  </table>
  <hr />
  <center>
    <img src="pics/small_<?=$item_details['imgName']?>" alt="Add a To My Shopping Cart" border=0 height = 75 width = 135><br/>
    <br />
    <br/>
    <span id="messages" style="display:none;"></span>
    
    <a href="home.php?page=shopping_cart&item_id=<?=$item_details['item_id']?>&catid=<?=$catid;?>&vendor=<?=$vendor;?>" class="button2">Add a To My Shopping Cart
    
    </a>
  </center>
  <br/>
  <? if(isset($_SESSION['username']) && $item_details['owner']==$_SESSION['username']) {?>
  <center>
    <a href="home.php?page=edit_item&item_id=<?=$item_details['item_id']?>&catid=<?=$catid;?>" class="button2">Edit Items </a>
  </center>
  <br/>
  <? }?>
  <center>
    <a href="#" class="button2"><img src="images/add-to-wishlist.gif" alt="Add a To My Wishlist." border=0 height = 50 width = 135></a>
  </center>
  <br />
  <br />
  <center>
    <a href="home.php?page=show_cat&vendor=<?=$_REQUEST['vendor']?>&catid=<?=$catid;?>" class="button2">Continue Shopping</a>
  </center>
</form>
