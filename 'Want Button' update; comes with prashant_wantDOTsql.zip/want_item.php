<?
include("includes/_include.php");
?>
  <? include("includes/frontHeader.php");
 
	
	if($_REQUEST['type']=='rented')
	{
		$item_details=fetchItemsDetailsRented($item_id);
  	}
	else
	{
		$item_details=fetchItemsDetailsAval($item_id);
  	}		//print_r($item_details);
  ?><form name="wntfrm" id="wntfrm" action="show_item.php">
  <table><tr><td><ul><li><b>Item Name:</b> <?php echo $_GET['itemname']; ?></li><li><b>Author:</b> No<li><b>Description:</b> Click the "Want" button to reserve the product that you want".<li><b>Stock:</b> NO</li></ul></td></tr></table><hr />
<table style="margin:0px auto; width:250px;text-align:center;">
<tr>
<td>
<img src="images/noitem.png" alt="Default Images" border=0 height = 75 width = 135 />
</td>
</tr>

<tr>
<td>
<input type="hidden" name="userId" id="userId" value="<?php echo $_SESSION['userId']; ?>"> 
<input type="hidden" name="itemnm" id="itemnm" value="<?php echo $_GET['itemname']; ?>"> 



<?php if(isset($_SESSION['userId'],$_SESSION['username']) && $_SESSION['username']!="" && $_SESSION['userId']!="") { ?>
<input type="button" name="<?php echo $_POST['txt_search']; ?>" value="Want It" onclick="wantthis();" id="wwnnt"/>
<?php } else {?>
<input type="button" name="<?php echo $_POST['txt_search']; ?>" value="Want It" onclick="nologin();" id="wwnnt"/>
<?php } ?>




<br/><br/>
<div id="wantmess" style="display:none;color:green;">You reserved this product successfully!</div>
<div id="nologin" style="display:none;color:green;">Please <a href="home.php?page=login">login here</a> to reserved this product!</div>
</td>
</tr>
</table>


 


 


</form>

<script>

function nologin()
{
$('#nologin').css('display','block');
}

function wantthis()   
{      
   $.ajax({	  
           type: "POST",	  
		   url: "wantdata.php",	  
		   data: $("#wntfrm").serialize(),	  
		   success: function(data)	  
		   {	 
              //alert(data);		   
			  $("#wwnnt").hide();
		      $('#wantmess').css('display','block');
		   }	
		 })   
}

</script>

