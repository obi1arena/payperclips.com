<?

include("includes/_include.php");
?>

  
<? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}

if(isset($_REQUEST['plan']))
{
	echo "<h3>Please select your plan.</h3>";
}
?>

   
<h2>Change Plan</h2>
   <br />
<form action="" method="post" name="frm">
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="13%" align="right">Old Plan</td>
    <td width="6%" align="center">:</td>
    <td width="81%" align="left"><?=$userData['plan']?></td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
  <tr>
    <td align="right">New plan:</td>
    <td align="center">:</td>
    <td align="left"><select name="plan" style="width:200px;">
      <? while($fetRow = mysql_fetch_array($sqlPlan)) {?>
      <option value="<?=$fetRow['items_per_month']?>"><?=$fetRow['items_per_month']?></option>
	  <? }?>
    </select></td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="left">&nbsp;</td>
  </tr>
  <tr>
    <td align="right">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="left"><input name="btnChangePlan" type=submit value="Change plan" class="button2"></td>
  </tr>
</table>
</form>

   <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
</table>

<? include("includes/footer.php");?>
