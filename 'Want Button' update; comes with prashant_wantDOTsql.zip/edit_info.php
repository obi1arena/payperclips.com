<?
include("includes/_include.php");
?>

  <script language="JavaScript" type="text/javascript" src="selectbox2.js">
			
</script>
<style type="text/css">
	pre { text-align: left; }
</style>

<script id="demo" type="text/javascript">
</script>

   <? include("includes/frontHeader.php");?>
   <?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
?>


<script type="text/javascript" src="js/all.js"></script>

<form id="formID" autocomplete="off" method="post" action="">
<div>
<div align="center" style="color:#FF0000"><b><? if(isset($GLOBALS['msg_success'])) { echo $GLOBALS['msg_success']; }
$userDetails=showAllUserDetails($_REQUEST['eId']);
?></b></div>
<input name="_qf__reg_form" type="hidden" value="" />
<table border="0" cellpadding="4" cellspacing="4" class="content">
  <tr>
    <td style="white-space: nowrap; background-color: #CCCCCC;" align="left" valign="top" colspan="3"><b>Edit Account</b></td>
  </tr>
  <tr>
    <td width="397" align="right" valign="top"><span style="color: #ff0000">*</span><b>Username</b></td>
    <td width="191" align="left" valign="top"><input maxlength="30" size="30" name="username" type="text" class="validate[required] text-input"  value="<?=$userDetails['username'];?>" /></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Password</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="password" id="password" type="password" class="validate[required] text-input" value="<?=$userDetails['password'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Email</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="email" type="text" class="validate[required,custom[email]] text-input" value="<?=$userDetails['email'];?>" /></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>First name</b></td>
    <td valign="top" align="left" class="field"><input maxlength="30" size="30" name="firstname" id="firstname" type="text" class="validate[required] text-input" value="<?=$userDetails['first_name'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Last name</b></td>
    <td valign="top" align="left" class="field"><input maxlength="30" size="30" name="lastname" id="lastname" type="text" class="validate[required] text-input" value="<?=$userDetails['last_name'];?>"/></td>
    <td class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Street address</b></td> 
    <td valign="top" align="left"><input maxlength="30" size="30" name="address_1" type="text"class="validate[required] text-input" value="<?=$userDetails['address_1'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Street address</b></td>
    <td valign="top" align="left"><input maxlength="30" size="30" name="address_2" type="text" value="<?=$userDetails['address_2'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>City</b></td>
    <td valign="top" align="left"><input maxlength="15" size="15" name="city" type="text" class="validate[required] text-input" value="<?=$userDetails['city'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>State</b></td>
    <td width="191" class="status"><select name="state" class="validate[required] text-input">
      <option value="">Select a state/province</option>
      <option value="1" <? if($userDetails['state']==1) { ?> selected<? } ?>>Alabama</option>
      <option value="2" <? if($userDetails['state']==2) { ?> selected<? } ?>>Alaska</option>
      <option value="3" <? if($userDetails['state']==3) { ?> selected<? } ?>>Arizona</option>
      <option value="4" <? if($userDetails['state']==4) { ?> selected<? } ?>>Arkansas</option>
      <option value="5" <? if($userDetails['state']==5) { ?> selected<? } ?>>California</option>
      <option value="6" <? if($userDetails['state']==6) { ?> selected<? } ?>>Canada-Alberta</option>
      <option value="7" <? if($userDetails['state']==7) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="8" <? if($userDetails['state']==8) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="9" <? if($userDetails['state']==9) { ?> selected<? } ?>>Canada-British Columbia</option>
      <option value="10" <? if($userDetails['state']==10) { ?> selected<? } ?>>Colorado</option>
      <option value="11" <? if($userDetails['state']==11) { ?> selected<? } ?>>Connecticut</option>
      <option value="12" <? if($userDetails['state']==12) { ?> selected<? } ?>>Delaware</option>
      <option value="13" <? if($userDetails['state']==13) { ?> selected<? } ?>>District of Columbia</option>
      <option value="14" <? if($userDetails['state']==14) { ?> selected<? } ?>>Florida</option>
      <option value="15" <? if($userDetails['state']==15) { ?> selected<? } ?>>Georgia</option>
      <option value="16" <? if($userDetails['state']==16) { ?> selected<? } ?>> Hawaii</option>
      <option value="17" <? if($userDetails['state']==17) { ?> selected<? } ?>>Idaho</option>
      <option value="18" <? if($userDetails['state']==18) { ?> selected<? } ?>>Illinois</option>
      <option value="19" <? if($userDetails['state']==19) { ?> selected<? } ?>>Indiana</option>
      <option value="20" <? if($userDetails['state']==20) { ?> selected<? } ?>>Iowa</option>
      <option value="21" <? if($userDetails['state']==21) { ?> selected<? } ?>>Kansas</option>
      <option value="22" <? if($userDetails['state']==22) { ?> selected<? } ?>>Kentucky</option>
      <option value="23" <? if($userDetails['state']==23) { ?> selected<? } ?>>Louisiana</option>
      <option value="24" <? if($userDetails['state']==24) { ?> selected<? } ?>>Maine</option>
      <option value="25" <? if($userDetails['state']==25) { ?> selected<? } ?>>Maryland</option>
      <option value="26" <? if($userDetails['state']==26) { ?> selected<? } ?>>Massachusetts</option>
      <option value="27" <? if($userDetails['state']==27) { ?> selected<? } ?>>Michigan</option>
      <option value="28" <? if($userDetails['state']==28) { ?> selected<? } ?>>Minnesota</option>
      <option value="29" <? if($userDetails['state']==29) { ?> selected<? } ?>>Mississippi</option>
      <option value="30" <? if($userDetails['state']==30) { ?> selected<? } ?>>Missouri</option>
      <option value="31" <? if($userDetails['state']==31) { ?> selected<? } ?>>Montana</option>
      <option value="32" <? if($userDetails['state']==32) { ?> selected<? } ?>>Nebraska</option>
      <option value="33" <? if($userDetails['state']==33) { ?> selected<? } ?>>Nevada</option>
      <option value="34" <? if($userDetails['state']==34) { ?> selected<? } ?>>Canada-New Brunswick</option>
      <option value="35" <? if($userDetails['state']==35) { ?> selected<? } ?>>New Hampshire</option>
      <option value="36" <? if($userDetails['state']==36) { ?> selected<? } ?>>New Jersey</option>
      <option value="37" <? if($userDetails['state']==37) { ?> selected<? } ?>>New Mexico</option>
      <option value="38" <? if($userDetails['state']==38) { ?> selected<? } ?>>New York</option>
      <option value="39" <? if($userDetails['state']==39) { ?> selected<? } ?>>North Carolina</option>
      <option value="40" <? if($userDetails['state']==40) { ?> selected<? } ?>>North Dakota</option>
      <option value="41" <? if($userDetails['state']==41) { ?> selected<? } ?>>Ohio</option>
      <option value="42" <? if($userDetails['state']==42) { ?> selected<? } ?>>Oklahoma</option>
      <option value="43" <? if($userDetails['state']==43) { ?> selected<? } ?>>Canada-Ontario</option>
      <option value="44" <? if($userDetails['state']==44) { ?> selected<? } ?>>Oregon</option>
      <option value="45" <? if($userDetails['state']==45) { ?> selected<? } ?>>Pennsylvania</option>
      <option value="46" <? if($userDetails['state']==46) { ?> selected<? } ?>>Rhode Island</option>
      <option value="47" <? if($userDetails['state']==47) { ?> selected<? } ?>>South Carolina</option>
      <option value="48" <? if($userDetails['state']==48) { ?> selected<? } ?>>South Dakota</option>
      <option value="49" <? if($userDetails['state']==49) { ?> selected<? } ?>>Tennessee</option>
      <option value="50" <? if($userDetails['state']==50) { ?> selected<? } ?>>Texas</option>
      <option value="51" <? if($userDetails['state']==51) { ?> selected<? } ?>>Utah</option>
      <option value="52" <? if($userDetails['state']==52) { ?> selected<? } ?>>Vermont</option>
      <option value="53" <? if($userDetails['state']==53) { ?> selected<? } ?>>Virginia</option>
      <option value="54" <? if($userDetails['state']==54) { ?> selected<? } ?>>Washington</option>
      <option value="55" <? if($userDetails['state']==55) { ?> selected<? } ?>>Washington DC</option>
      <option value="56" <? if($userDetails['state']==56) { ?> selected<? } ?>>West Virginia</option>
      <option value="57" <? if($userDetails['state']==57) { ?> selected<? } ?>>Wisconsin</option>
      <option value="58" <? if($userDetails['state']==58) { ?> selected<? } ?>>Wyoming</option>
    </select></td>
    <td valign="top" align="left">&nbsp;</td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Zip code</b></td> 	
    <td valign="top" align="left"><input maxlength="5" size="5" name="zip_code" type="text" class="validate[required] text-input" value="<?=$userDetails['zip_code'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Country</b></td>
    <td valign="top" align="left"><input size="15" name="country" type="text"class="validate[required] text-input" value="<?=$userDetails['country'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Monthly Plan(number of items you can
      check out each month)</b></td>
    <td valign="top" align="left"><select name="plan" class="validate[required] text-input">
      <option value="">Select</option>
      <option value="1" <? if($userDetails['plan']==1) { ?> selected<? } ?>>1</option>
      <option value="2" <? if($userDetails['plan']==2) { ?> selected<? } ?>>2</option>
      <option value="3" <? if($userDetails['plan']==3) { ?> selected<? } ?>>3</option>
      <option value="4" <? if($userDetails['plan']==4) { ?> selected<? } ?>>4</option>
      <option value="5" <? if($userDetails['plan']==5) { ?> selected<? } ?>>5</option>
    </select></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Telephone</b></td>
    <td valign="top" align="left"><input id="phone" name="phone" value="<?=$userDetails['telephone'];?>"/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Cardholder Name</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="card_name" type="text"class="validate[required] text-input" value="<?=$userDetails['card_name'];?>"/></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Credit/Debit Card Type</b></td> 	
    <td valign="top" align="left"><select name="card_type" class="validate[required] text-input">
      <option value="">CARD TYPE</option>
      <option value="1" <? if($userDetails['card_type']==1) { ?> selected<? } ?>>Visa</option>
      <option value="2" <? if($userDetails['card_type']==2) { ?> selected<? } ?>>MasterCard</option>
      <option value="3" <? if($userDetails['card_type']==3) { ?> selected<? } ?>>Discover</option>
      <option value="4" <? if($userDetails['card_type']==4) { ?> selected<? } ?>>American Express</option>
      <option value="5" <? if($userDetails['card_type']==5) { ?> selected<? } ?>>Diner's Club</option>
    </select></td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Credit/Debit Card Number</b></td>
    <td valign="top" align="left"><input maxlength="16" size="20" name="card_number" type="text" class="validate[required] text-input" value="<?=$userDetails['card_number'];?>"/>
      &nbsp;Don't put dashes nor spaces</td>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Card Expiration Date</b></td>
    <td valign="top" align="left">
        <?
    $date=explode("-",$userDetails['card_exp_date']);
	$y=$date[0];
	$m=$date[1];
	$d=$date[2];
	$card_exp_date=$m."/".$d."/".$y;
		?>
        <input type="text" name="card_exp_date" id="date" value="<?=$card_exp_date;?>"/>
    <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Card Security Code</b></td>
    <td valign="top" align="left"><input maxlength="4" size="4" name="card_sec" type="text" class="validate[required] text-input" value="<?=$userDetails['card_sec'];?>"/>
      &nbsp;It's the 3 digit on the white stripe at the back of the card or the 4 digit on the upper right corner of the American Express card number</td>
      <td width="672" class="status"></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
    <td valign="top" align="left">---OR---</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Name on Bank Account</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="acct_name" type="text" value="<?=$userDetails['acct_name'];?>"/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Name of Bank</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="bank_name" type="text" value="<?=$userDetails['bank_name'];?>"/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank ABA Number</b></td>
    <td valign="top" align="left"><input maxlength="9" size="12" name="aba_number" type="text" value="<?=$userDetails['aba_number'];?>"/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Example:</b></td>
    <td valign="top" align="left">123456789 (9 digits total length)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank Account Number</b></td>
    <td valign="top" align="left"><input maxlength="13" size="15" name="acct_num" type="text" value="<?=$userDetails['acct_num'];?>"/>
      &nbsp;(Paying Gas Card directly from bank account can save you more money)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Example:</b></td>
    <td valign="top" align="left">1234567890 (8 to 13 digits total length)</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Bank City</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="bank_city" type="text" value="<?=$userDetails['bank_city'];?>"/></td>
  </tr>
  <tr> 	
    <td align="right" valign="top"><b>State</b></td>
    <td valign="top" align="left"><select name="bank_state">
      <option value="">Select a state/province</option>
      <option value="AL">Alabama</option>
      <option value="AK">Alaska</option>
      <option value="AZ">Arizona</option>
      <option value="AR">Arkansas</option>
      <option value="CA">California</option>
      <option value="CO">Colorado</option>
      <option value="CT">Connecticut</option>
      <option value="DE">Delaware</option>
      <option value="FL">Florida</option>
      <option value="GA">Georgia</option>
      <option value="HI">Hawaii</option>
      <option value="ID">Idaho</option>
      <option value="IL">Illinois</option>
      <option value="IN">Indiana</option>
      <option value="IA">Iowa</option>
      <option value="KS">Kansas</option>
      <option value="KY">Kentucky</option>
      <option value="LA">Louisiana</option>
      <option value="ME">Maine</option>
      <option value="MD">Maryland</option>
      <option value="MA">Massachusetts</option>
      <option value="MI">Michigan</option>
      <option value="MN">Minnesota</option>
      <option value="MS">Mississippi</option>
      <option value="MO">Missouri</option>
      <option value="MT">Montana</option>
      <option value="NE">Nebraska</option>
      <option value="NV">Nevada</option>
      <option value="NH">New Hampshire</option>
      <option value="NJ">New Jersey</option>
      <option value="NM">New Mexico</option>
      <option value="NY">New York</option>
      <option value="NC">North Carolina</option>
      <option value="ND">North Dakota</option>
      <option value="OH">Ohio</option>
      <option value="OK">Oklahoma</option>
      <option value="OR">Oregon</option>
      <option value="PA">Pennsylvania</option>
      <option value="PR">Puerto Rico</option>
      <option value="RI">Rhode Island</option>
      <option value="SC">South Carolina</option>
      <option value="SD">South Dakota</option>
      <option value="TN">Tennessee</option>
      <option value="TX">Texas</option>
      <option value="UT">Utah</option>
      <option value="VT">Vermont</option>
      <option value="VA">Virginia</option>
      <option value="WA">Washington</option>
      <option value="DC">Washington DC</option>
      <option value="WV">West Virginia</option>
      <option value="WI">Wisconsin</option>
      <option value="WY">Wyoming</option>
    </select></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
    <td valign="top" align="left">---OR---</td>
  </tr> 	 
  <tr>
    <td align="right" valign="top"><b>PayPal Account</b></td>
    <td valign="top" align="left"><input maxlength="60" size="30" name="paypal_name" type="text" value="<?=$userDetails['paypal_name'];?>">
      &nbsp;Paying with PayPal can save you money by reducing credit card transaction cost</td>
  </tr>
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Gender</b></td>
    <td valign="top" align="left"><input name="gender" value="m" type="radio" id="qf_2616c7" class="validate[required] text-input" <? if($userDetails['gender']=='m') {?> checked<? }?>/>
        <label for="qf_2616c7">Male</label>
      &nbsp;
      <input name="gender" value="f" type="radio" id="qf_97b0a2" class="validate[required] text-input" <? if($userDetails['gender']=='f') {?> checked<? }?>/>
      <label for="qf_97b0a2">Female</label></td>
      <td width="672" class="status"></td>
  </tr> 	
  <tr>
    <td align="right" valign="top"><span style="color: #ff0000">*</span><b>Birthdate</b></td>
    <td valign="top" align="left">
     <?
    $date1=explode("-",$userDetails['dob']);
	$y1=$date1[0];
	$m1=$date1[1];
	$d1=$date1[2];
	$dob=$m1."/".$d1."/".$y1;
		?>
    <input type="text" id="date1" name="dob" value="<?=$dob;?>"/></td>
  </tr>
  <tr>
    <td align="right" valign="top"><b>Note:</b></td>
    <td valign="top" align="left">You must be at least 18 years old to use some of the services</td>
  </tr>
  <tr>
    <td align="right" valign="top"><b></b></td>
     <input type="hidden" id="" name="userid" value="<?=$_REQUEST['eId'];?>"/></td>
    <td valign="top" align="left" class="field"><input id="signupsubmit" name="AlleditUser" type="submit" value="UPDATE" />&nbsp;<input type="button" name="Back" value="Back" onClick="window.location='home.php?page=user_list'" /></td>
  </tr>
  <tr>
    <td></td>
    <td align="left" valign="top">Fields marked * are required</td>
  </tr>
</table>
</div>
</form> 