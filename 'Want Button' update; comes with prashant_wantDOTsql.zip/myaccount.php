<? include("includes/_include.php");
include("includes/frontHeader.php");
?>
<? if(isset($_REQUEST['become_to_super'])) { 

unset($_SESSION['userId']);
unset($_SESSION['username']);
unset($_SESSION['userType']);

$fetch_user_dtl=mysql_fetch_array(mysql_query("SELECT * FROM ".ADMIN." WHERE id='".$_SESSION['pre_userId']."' "));

unset($_SESSION['pre_userId']);

	$_SESSION['userId']=$fetch_user_dtl['id'];
	$_SESSION['username']=$fetch_user_dtl['username'];
	$_SESSION['userType']=$fetch_user_dtl['god'];
	
	header('Location:home.php?page=user_list');


}?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
$rented_items=fetchQntyMonth();
$newMemberFees=newMemberShipPlan();

if(!empty($rented_items['QUANTITY']))
{
	$user_rent_qnty=$rented_items['QUANTITY'];
}
else
{
	$user_rent_qnty=$userData['plan'];
}
$rented_amt=fetchPlan($user_rent_qnty);

?>
  <script type="text/javascript">
  
  function becometosuper()
  {
  document.inputBecometoSuper.submit();
  
  }
  </script>
 <table width="100%" border="0" cellpadding="4" cellspacing="4">
 <?php if(isset($_SESSION['userId'])) {?>
   
	
 

  <tr>
    <td><strong>Monthly Plan(number of items you can check out each month): 
      <?
	  if($rented_items['QUANTITY']>$userData['plan'])
	  {
	  	echo $rented_items['QUANTITY'];
	  }
	  else
	  {
	  	echo $userData['plan'];
      }?>
    </strong></td>
  </tr>
  <? if(isset($_SESSION['pre_userId'])) { ?>
  <tr>
    <td style="font-weight:bold">You are editting items/categories/details for user <?=$_SESSION['username']?>. To return to being <?=$_SESSION['pre_user']?>, <a href="Javascript: void(0)" onclick="return becometosuper()">click here.</a></td>
  </tr>
  <? } ?>
  <tr>
    <td><strong><?php //echo showingFees();?></strong></td>
  </tr>
  <tr>
    <td><strong>A portion for the Item Owner:$
      <?
	  if($rb=='') {
		  echo $rb = '0.00';
	  }
	  else
	  {
		  echo $rb;
	  }
	  ?>
    </strong></td>
  </tr>
  <tr>
    <td><strong>
    
    Membership Fee(As per Plan):$
      
	  <? 
	   if(isset($rented_items['QUANTITY']) && $rented_items['QUANTITY']>0)
	   {
	   		echo number_format($mon_fee=$rented_amt['monthly_fee'],2);
	   }
	   else
	   {
	   		echo $mon_fee='0.00';
	   }
	   ?>
	  <? //=number_format($monthlyPlanCharge['monthly_fee'],2);?>
   <br/>
   
   
   
    </strong></td>
  </tr>
  <tr>
    <td><strong>Net Pay(i. e. Membership Fee - A portion for the Item Owner):$
    <?
      if(isset($rented_items['QUANTITY']) && $rented_items['QUANTITY']>0)
	   {
	   		echo  number_format($netPay = $mon_fee-$rb,2);
	   }
	   else
	   {
	   		echo  number_format($netPay = $rb-$mon_fee,2);
	   }
	 ?>
    </strong></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><a href="home.php?page=myaccount">Go to main site</a></td>
  </tr>
  <tr>
    <td><a href="home.php?page=category">Add a new category</a></td>
  </tr>
  <tr>
    <td><a href="home.php?page=insert_item">Add a new item</a></td>
  </tr>
  <tr>
    <td><a href="home.php?page=updateInfo">Change details</a></td>
  </tr>
  <tr>
    <td><a href="home.php?page=changePlan">Change plan</a></td>
  </tr>
   <tr>
    <td><a href="home.php?page=saleResult">Sale Results</a></td>
  </tr>
   <tr>
    <td><a href="home.php?page=rentedItems">My Shopping Cart</a></td>
  </tr>
  <tr>    <td><a href="home.php?page=wantitems">Requested Items</a></td>  </tr>
<? }?>
<? if($_SESSION['userType']==1) { ?>
<tr>
    <td><a href="home.php?page=Manage_formats">Manage Item Formats</a></td>
  </tr>
   <tr>
    <td><a href="home.php?page=add_plan">Add a Plan</a></td>
  </tr>
   <tr>
    <td><a href="home.php?page=user_list">Add,edit & delete Users</a></td>
  </tr>
   <tr>
    <td><a href="home.php?page=managePayouts">Manage Payouts</a></td>
  </tr>
<? } ?>
</table>
 <form name="inputBecometoSuper" action="" method="post">
  <input type="hidden" name="become_to_super" value="become" />
 </form>