<?php
if($_REQUEST['page']=='home') 
		{ 
		include_once('index.php'); 
		}
		
		else if($_REQUEST['page']=='want_item') 
		{
		include('want_item.php'); 
		}
		else if($_REQUEST['page']=='registration') 
		{
		include('registration.php'); 
		}
		else if($_REQUEST['page']=='login') 
		{
		include('login.php'); 
		}
		else if($_REQUEST['page']=='logout') 
		{
		include('logout.php'); 
		}
		else if($_REQUEST['page']=='myaccount') 
		{
		include('myaccount.php'); 
		}
		else if($_REQUEST['page']=='category') 
		{
		include('category.php'); 
		}
		else if($_REQUEST['page']=='insert_item') 
		{
		include('insert_item.php'); 
		}
		else if($_REQUEST['page']=='edit_account') 
		{
		include('edit_account.php'); 
		}
		else if($_REQUEST['page']=='show_item') 
		{
		include('show_item.php'); 
		}
		else if($_REQUEST['page']=='vendor') 
		{
		include('vendor.php'); 
		}
		else if($_REQUEST['page']=='show_cat') 
		{
		include('show_cat.php'); 
		}
		else if($_REQUEST['page']=='shopping_cart') 
		{
		include('shopping_cart.php'); 
		}
		else if($_REQUEST['page']=='checkout') 
		{
		include('checkout.php'); 
		}
		else if($_REQUEST['page']=='sucess') 
		{
		include('sucess.php'); 
		}
		else if($_REQUEST['page']=='Manage_formats') 
		{
		include('manage_format_form.php'); 
		}
		else if($_REQUEST['page']=='add_plan') 
		{
		include('add_plan.php'); 
		}
		else if($_REQUEST['page']=='user_list') 
		{
		include('user_list.php'); 
		}
		else if($_REQUEST['page']=='edit_info') 
		{
		include('edit_info.php'); 
		}
		else if($_REQUEST['page']=='saleResult') 
		{
		include('sale_result.php'); 
		}
		else if($_REQUEST['page']=='rentedItems') 
		{
		include('rented_items.php'); 
		}
		else if($_REQUEST['page']=='viewShoppingCart') 
		{
		include('viewShoppingCart.php'); 
		}
		else if($_REQUEST['page']=='updateInfo') 
		{
		include('change_password.php'); 
		}
		else if($_REQUEST['page']=='changePlan') 
		{
		include('changePlan.php'); 
		}
		else if($_REQUEST['page']=='managePayouts') 
		{
		include('manage_payouts.php'); 
		}
		else if($_REQUEST['page']=='edit_item') 
		{
		include('edit_item.php'); 
		}
		else if($_REQUEST['page']=='delete_item') 
		{
		include('delete_item.php'); 
		}
		else if($_REQUEST['page']=='wantitems') 
		{
		include('requested_item.php'); 
		}
		
		else 
		{
		include_once('index.php');
		}			
?>
