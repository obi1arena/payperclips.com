<?
include("includes/_include.php");
?>
<? include("includes/frontHeader.php");?>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td>Welcome to PayPerClips</td>
  </tr> 
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<form name = "frmSearch" method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
	<input type="hidden" name="search_mode" value="<?php echo $_POST['search_mode'];?>">
	<input type="hidden" name="txt_alpha" value="<?php echo $_POST['txt_alpha'];?>">
	
  <table width="99%" align="center" border="0" cellpadding="5" cellspacing="1">
    <tr > 
      <td colspan="2">Please choose a vendor:</td>
    </tr>
    <tr> 
      <td colspan="2" align="center"> 
			<table border="0" cellpadding="0" cellspacing="0" width="80%">
				<tr> 
					<td width="25%" align="right">Or search by zip code:</td>
					<td width="75%"><input type="text" name="txt_search" id="txt_search" value="<?php if(isset($_REQUEST['txt_search'])) echo stripslashes($_REQUEST['txt_search']);?>" placeholder="Movies, Games, Actors, Directors">
					<input type="button" value="Search" onClick="search_text()" class="inplogin">
					<input type="button"  value="Show All" onClick="show_all()" class="inplogin"> 
					</td>
				</tr>
				<tr > 
    			  <td colspan="2">&nbsp;</td>
   				 </tr>
			</table>
		</td>
	</tr>
	
    <tr> 
      <td colspan="2" align="center"> 
        <?php
			if(isset($_POST['txt_alpha']))
			{
				 $str = $_POST['txt_alpha'];
			}
			else
			{
				$str = "1";
			}
			DisplayAlphabet($str); 
		?>
      </td>
    </tr>
  </table>
  <br>
	</form>
	<script language="JavaScript">
	function show_all(){
		document.frmSearch.search_mode.value = "";	
		document.frmSearch.txt_search.value="";
		document.frmSearch.txt_alpha.value="";
		document.frmSearch.submit();	
	}
	
	function search_text(){
		//alert(document.frmSearch.search_type.value );
	/*if(document.frmSearch.search_type.value=="")
	{
	alert("Please Select A Search Type");
	return false;
	}*/
	if(document.frmSearch.txt_search.value.search(/\S/)==-1)
	{
	alert("Please Enter Zipcode");
	return false;
	}
		document.frmSearch.search_mode.value = "SEARCH";
		document.frmSearch.submit();
	}
	function search_text1(){
		if(document.frmSearch.faq_id.value=="")
		{
		alert("Please Select A PRODUCT");
		return false;
		}
		document.frmSearch.search_mode.value = "SEARCH_FAQ";
		document.frmSearch.submit();
	}
	function search_alpha(alpha){
		document.frmSearch.search_mode.value = "ALPHA";
		document.frmSearch.txt_search.value = '';
		document.frmSearch.txt_alpha.value = alpha;
		document.frmSearch.submit();
	}
	
	
	</script>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
	<form name="delete_record" action="<?=$_SERVER['PHP_SELF'];?>" method="post">
		<input type="hidden" name="mode" value="">
	<tr align="left" class="TDHEAD_SUB">
	<?php
	  $item_query = mysql_query("select * from items where title = '".$_POST['txt_search']."' and status != 'Y'")or die(mysql_error());
	  $item_result = mysql_fetch_array($item_query);
	?>
	  <td height="23" align="center" valign="top">( <?=mysql_num_rows($item_query)?> ) Matching Vendor/s Beginning with Found on Database</td>
	  </tr>
	<?php if(mysql_num_rows($item_query)==0){?>
	<tr><td height="22" valign="top" align="center">

<!-- No Record Found -->
	
<table style="margin:0px auto; width:250px;text-align:center;">
<?php if($_POST['txt_search'] != '') { ?>
<tr>
<td>
<a href="home.php?page=want_item&itemname=<?php echo $_POST['txt_search']; ?>"> <img src="images/noitem.png" /> </a>
</td>
</tr>
<?php } ?>
<tr>
<td>
<b><a href="home.php?page=want_item&itemname=<?php echo $_POST['txt_search']; ?>"><?php echo $_POST['txt_search']; ?></a></b>
</td>
</tr>
</table>


</td></tr>
	<?php }else{?>
	<?php 
		while($cat_row = mysql_fetch_array($search_rs))
		{
			?>
			<tr onMouseOver="this.bgColor='<?=SCROLL_COLOR;?>'" onMouseOut="this.bgColor=''" <? if($ak%2==0) { ?> style="background:#FBF3F3;" <? } ?>>

<td height="22" align="left" valign="top">
<a href="home.php?page=vendor&userName=<?=$cat_row['username']?>"><?php echo ucfirst(substr(stripslashes($cat_row['first_name']),0,40));?>&nbsp;<?php echo ucfirst(substr(stripslashes($cat_row['last_name']),0,40));?></a>
</td>
			</tr>
<?php	
		$ak++; }//End of While	 
	?>
	<?php }// End of Count?>
	</form>
    </table>
  
    <?
	$showNoRentedItems=showNoRentedItems();
while($itemsDetails=mysql_fetch_array($showNoRentedItems))
{?>

  <div style="width:200px; height:200px; float:left; margin:20px 50px 20px 50px;">   
    <a href="home.php?page=show_item&item_id=<?=$itemsDetails['item_id']?>&vendor=<?=$itemsDetails['owner']?>&catid=<?=$itemsDetails['catid']?>">
    <img src="pics/small_<?=$itemsDetails['imgName']?>" alt="Item Picture">
 
   <p style="margin:5px 0;"> <? //=$itemsDetails['title']?></p></a>

  <p style="margin:5px 0;"><? //=$itemsDetails['author']?></p>
  <p style="margin:5px 0;"><? //=$itemsDetails['owner']?></p>
  
</div>  

<? }?>
  
    <script language="JavaScript">
	function checkAll(){
	var arr = new Array();
	for (var i=0;i<document.delete_record.elements.length;i++)
	{
		var e=document.delete_record.elements[i];
		if ((e.name != 'allbox') && (e.type=='checkbox'))
		{
			e.checked=document.delete_record.allb.checked;
		}
	}
	
	}
	
	function check(id)
	{	
		var ele=document.delete_record.elements["allbox[]"];
		//alert(ele.length);
		var chk=0;
		for(var i=0;i<ele.length;i++)
		{
			if(ele[i].checked==true)
			chk=chk+1;
		}
		if(chk==ele.length)document.delete_record.allb.checked="true";
		else document.delete_record.allb.checked="";
	
	}


	function delete_state()
		{
			var catResp = window.confirm("Are you sure to remove the selected PRODUCT?");
			if( catResp == true )
			{   /*alert();*/
				document.delete_record.mode.value='delete_prod';
				document.delete_record.submit();
			}
		}
	</script>
<script language="javascript">
	function add_prod()
	{
		frm = document.frm_opts;
		frm.mode.value = 'add_prod';
		frm.submit();
	}
	function edit_prod(catId)
	{ 
		frm = document.frm_opts;
		frm.catId.value = catId;
		frm.mode.value = 'edit_prod';
		frm.submit();
	}
</script>
<? include("includes/footer.php");?>