<?
include("includes/_include.php");
?>


  
<? include("includes/frontHeader.php");?>
<?
if(empty($_SESSION['userId']))
{
	header('Location:home.php?page=login&aut');
	exit;
}
?>
 
 <form name="frm_category" action="" method="post" id="formID">
 <table border="0" width="599">
 <? if(isset($GLOBALS['cat_sucesss'])) {?>
  <tr>
    <td width="593"> <?  echo $GLOBALS['cat_sucesss'];?></td>
  </tr>
  <? }?>
  <tr>
    <td><select name="category" size="10">
 <?
 $fetchCategory=fetchCategory();
 while($category=mysql_fetch_array($fetchCategory)) {?>
 <option value="<?=$category['catid'];?>"><?=$category['catname'];?></option>
<?
}
?>
 </select></td>
  </tr>
  <tr>
    <td> <input name="catname" type="text" class="validate[required] text-input" id="catname" size="50" placeholder="Enter Category Name"/>
 
 </td>
  </tr>
  <tr>
    <td> 
 <input name="btn_category" type="submit" value="Add Category" class="button2">
 </td>
  </tr>
</table>


 
 

</form>
<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?page=myaccount" class="button2">Back to administration menu</a></td>
  </tr>
</table>
