<?php ob_start(); session_Start();

print_r($_SESSION);

?>